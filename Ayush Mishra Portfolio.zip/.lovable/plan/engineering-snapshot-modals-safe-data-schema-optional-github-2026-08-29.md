# Engineering Snapshot: modals, safe data schema, optional GitHub & LeetCode stats

Four upgrades to the existing Snapshot section. No redesign, no branding change, no other sections touched.

## 1. Click-through card modals

Every one of the six Snapshot cards becomes clickable (button semantics, keyboard focusable, Enter/Space) and opens a details dialog using the existing shadcn `Dialog`, styled to match the current dark/accent system.

Each modal shows:
- Card title + icon in the header
- A short description line for context
- The full detail list (all chips/items, not the truncated card view)
- A graceful placeholder block ("Not configured yet — this will populate once I add the data / connect the integration") when a field is empty or null

Modals stay on the page, close on Escape/overlay/X, and restore focus to the card.

## 2. Type-safe data schema with runtime checks

`src/data/dashboard.ts` gets a Zod schema (zod is already installed) describing every field, with nullable/optional fields explicitly allowed. The raw data object is parsed with `safeParse` at module load:

- Valid data → typed object exported, types inferred from the schema (single source of truth)
- Invalid or missing data → a safe fallback object is exported instead and a console warning is logged in dev; the UI renders empty states rather than crashing

Components consume helpers like `isEmpty(...)` so a missing array, empty string, or null number always renders the placeholder rather than a broken card.

## 3. Optional GitHub integration

Manual by default. Real stats appear only when configured.

- Config lives in `dashboard.ts`: `integrations.github = { enabled: false, username: "itsanshmishra34" }`
- A server function (`src/lib/dashboard-stats.functions.ts`) fetches public repo count, followers, and top languages from the GitHub API, optionally sending a `GITHUB_TOKEN` secret for higher rate limits. Tokens are read server-side only, never in the browser.
- The client calls it through TanStack Query only when `enabled` is true; otherwise the GitHub card renders the manual/placeholder state
- Any API failure falls back to the placeholder — never a fabricated number and never an error screen

## 4. Optional LeetCode integration

Same pattern, same guarantees.

- Config: `integrations.leetcode = { enabled: false, username: "itsansh30" }`
- Server function queries LeetCode's public GraphQL endpoint for total solved (plus easy/medium/hard) and derives the current streak from the submission calendar
- Disabled or failing → the existing null-safe "stats not configured yet" placeholder stays exactly as it is today

Note on the streak: LeetCode has no official API, so the streak is computed from the public submission calendar. If that endpoint is blocked or changes, the card shows the placeholder instead of a guessed value.

## Technical summary

- New: `src/lib/dashboard-stats.functions.ts` (two `createServerFn` handlers), `src/components/portfolio/DashboardCardDialog.tsx`
- Edited: `src/data/dashboard.ts` (Zod schema + integration config), `src/components/portfolio/Dashboard.tsx` (clickable cards, query wiring, placeholders)
- Optional secret: `GITHUB_TOKEN` (only if you want higher rate limits)
- To go live with real stats you flip `enabled: true` in `dashboard.ts` — nothing else changes
