# GitHub page, LinkedIn page, and real project links

## 1. Project links (honest, no invention)

The only verified repository URL you gave is the Vedavault one, which is already on the Offline AI Tutor project. Instead of inventing URLs for the rest, the portfolio will link projects to real repositories automatically:

- Switch the GitHub account used by the site to `ayush3020` (site config + GitHub data config).
- Fetch your public repositories at runtime, and when a project's slug/title matches a real repository name, show a working GitHub button for it.
- Projects with no matching repository keep the accessible "unavailable" placeholder — nothing fabricated.

If you later paste more repo/live URLs, they drop straight into the project data.

## 2. New GitHub page (`/github`)

A dedicated page listing your public repositories, live from the GitHub API:

- Repository cards: name, description, primary language, stars/forks, last updated.
- Click a repository to open a detail view showing:
  - the rendered README (fetched live, sanitized markdown)
  - the open issues list (title, number, state, labels, date, link to GitHub)
- Loading, empty, error and rate-limit states handled explicitly (no fake data).
- Linked from the footer as "GitHub".
- Own SEO head metadata.

## 3. New LinkedIn page (`/linkedin`)

Built entirely from existing portfolio data, in two parts:

- **Profile view** — LinkedIn-style layout: header (name, headline, location), About, Experience (Syynapse, Matiks, ambassador roles), Education, Certifications, Skills.
- **Copy-ready blocks** — each section also offers a "Copy" button with the exact text to paste into LinkedIn (headline, About, per-role descriptions), so both stay in sync.
- Linked from the footer alongside the existing LinkedIn profile link.
- Own SEO head metadata.

## Technical notes

- New routes `src/routes/github.tsx` and `src/routes/linkedin.tsx` (TanStack Start file routes, each with its own `head()`).
- GitHub calls run through server functions in a `*.functions.ts` module using the existing `src/lib/github.ts` helpers, extended with `fetchReadme` and `fetchIssues`; short-lived caching reuses `src/lib/stats-cache.ts` to avoid rate limits.
- README markdown rendered with a lightweight sanitized renderer; no raw HTML injection.
- `src/data/github.ts` username changed to `ayush3020`; `src/data/site.ts` GitHub link updated to match.
- Project→repo matching lives in a small helper in `src/lib/github.ts`; `ProjectLinks.tsx` consumes a resolved URL and its placeholder behaviour is unchanged.
- Footer gains "GitHub" and "LinkedIn Profile" internal links using router `Link`.
