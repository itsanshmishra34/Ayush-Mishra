# Ayush Mishra — Developer Portfolio

A single-page, premium dark portfolio built with React + TypeScript + Tailwind, using only the information provided. No invented projects, links, stats, or achievements.

## Design direction

- Deep near-black background with subtle layered gradients, one accent color (electric cyan-teal) used sparingly for CTAs, active nav state, and hover glows.
- Typography: Space Grotesk for headings, DM Sans for body (loaded via link tag in the root route head).
- Glassmorphism only on the navbar and a few cards; generous whitespace, rounded corners, soft borders.
- Animated hero backdrop: slow-drifting grid + faint gradient orbs, GPU-cheap, respects `prefers-reduced-motion`.
- All colors as semantic tokens in `src/styles.css` (no hardcoded color classes).

## Sections (one scrolling page at `/`)

1. **Navbar** — sticky glass bar: Home, About, Skills, Projects, Experience, Education, Contact + Resume button. Scroll-spy active indicator, smooth scroll, mobile hamburger drawer.
2. **Hero** — name, "Aspiring Software Engineer", tagline "Building practical solutions with code, curiosity, and consistency.", headline "B.Tech CSE @ LPU | Aspiring Software Engineer", secondary "C++ • Python • SQL • DSA • AI/ML", location, and role chips (Google Student Ambassador, GeeksforGeeks Campus Mantri, Associate Principal at Syynapse). CTAs: View Projects, Download Resume, Contact Me. Fade/slide-in on load.
3. **About** — the provided introduction paragraph, unmodified in meaning.
4. **Skills** — interactive card grid for the 11 listed technologies with hover lift/glow. No percentage bars.
5. **Projects** — VisionMark AI card: title, provided description, tags (Python, OpenCV, AI/ML), GitHub button and Live Demo button. Since no URLs were provided, these render as disabled "Link coming soon" states until you give me the URLs.
6. **Experience** — vertical timeline with scroll-reveal: Syynapse, Google Student Ambassadors (India), GeeksforGeeks, with the exact roles and dates given.
7. **Education** — LPU (B.Tech CSE, Aug 2025 – Jul 2029) and S.V.M. Sultanpur (10th & 12th, PCM, Apr 2021 – Mar 2025) as clean cards.
8. **Certifications** — three compact cards: CSS (Basic), Python (Basic), Certificate of Appreciation – Computer Programming.
9. **Contact** — email button, copy-email with confirmation toast, LinkedIn button, phone, and a contact form.
10. **Footer** — name, short line, quick links.

## Contact form behavior

No backend is set up, so the form will validate input and open the user's mail client pre-filled to itsanshmishra343@gmail.com. If you'd rather have submissions stored/emailed server-side, say so and I'll add Lovable Cloud for that.

## Resume

No resume file was provided. The Download Resume buttons will point to `/resume.pdf`; upload your PDF (or send it) and it works immediately — otherwise I can hide the button.

## Technical notes

- Route: rewrite `src/routes/index.tsx` as the portfolio page with proper `head()` metadata (title, description, og/twitter tags, Person JSON-LD).
- Components split under `src/components/portfolio/` (Navbar, Hero, About, Skills, Projects, Experience, Education, Certifications, Contact, Footer) plus a `SectionReveal` wrapper hook using IntersectionObserver and a `useActiveSection` hook.
- Content lives in a single `src/data/portfolio.ts` file so text and links are easy to edit later.
- Animations via CSS transitions/keyframes and IntersectionObserver — no heavy animation dependency.
- Semantic HTML (`header`/`nav`/`main`/`section`/`footer`), aria labels on icon buttons, keyboard-accessible nav and mobile menu, visible focus rings.
- Custom favicon generated to match the accent mark.
