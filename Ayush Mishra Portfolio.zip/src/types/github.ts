/** Shapes for the public GitHub data shown in the "Coding & Open Source" section. */

export type GithubRepo = {
  id: number;
  name: string;
  description: string | null;
  language: string | null;
  stars: number;
  forks: number;
  updatedAt: string;
  url: string;
  topics: string[];
};

export type GithubLanguageShare = {
  language: string;
  repos: number;
  /** Share of repositories using this language as their primary language (0-100). */
  percent: number;
};

export type GithubProfile = {
  username: string;
  profileUrl: string;
  avatarUrl: string | null;
  name: string | null;
  bio: string | null;
  publicRepos: number | null;
  followers: number | null;
};

export type GithubData = {
  profile: GithubProfile | null;
  repos: GithubRepo[];
  languages: GithubLanguageShare[];
  error: string | null;
};

export type GithubIssue = {
  id: number;
  number: number;
  title: string;
  state: string;
  url: string;
  createdAt: string;
  labels: string[];
  comments: number;
  isPullRequest: boolean;
};

export type GithubReadme = {
  markdown: string | null;
  error: string | null;
};

export type GithubIssuesResult = {
  issues: GithubIssue[];
  error: string | null;
};
