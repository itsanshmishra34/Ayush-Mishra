/** Shapes for the public LeetCode profile data shown in the portfolio. */

export type LeetcodeLanguage = {
  language: string;
  problemsSolved: number;
};

export type LeetcodeProfile = {
  username: string;
  profileUrl: string;
  totalSolved: number | null;
  easy: number | null;
  medium: number | null;
  hard: number | null;
  ranking: number | null;
  contestRating: number | null;
  badges: string[];
  languages: LeetcodeLanguage[];
  error: string | null;
};
