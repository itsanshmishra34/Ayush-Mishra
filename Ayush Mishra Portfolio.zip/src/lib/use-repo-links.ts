import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { GITHUB_USERNAME, fetchGithubProfile, matchRepoUrl } from "@/lib/github";

/**
 * Resolves a real GitHub repository URL for a project by matching its
 * slug/title against the account's actual public repositories.
 * Returns null while loading or when no repository matches — never invents URLs.
 */
export function useRepoUrl(project: { slug: string; title: string }): string | null {
  const fn = useServerFn(fetchGithubProfile);
  const { data } = useQuery({
    queryKey: ["github-repos-all", GITHUB_USERNAME],
    queryFn: () => fn({ data: { username: GITHUB_USERNAME, includeAll: true } }),
    staleTime: 1000 * 60 * 30,
    retry: false,
  });
  if (!data?.repos?.length) return null;
  return matchRepoUrl(project, data.repos);
}
