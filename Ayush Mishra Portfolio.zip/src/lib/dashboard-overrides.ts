/**
 * Dashboard integration overrides.
 *
 * `src/data/dashboard.ts` stays the canonical source of truth. This module
 * lets the settings panel toggle the GitHub/LeetCode `enabled` flags and
 * change usernames at runtime; overrides persist in localStorage and are
 * merged over the file defaults. Clearing overrides restores the file config.
 * To change the defaults for every visitor, edit src/data/dashboard.ts.
 */

import { useEffect, useMemo, useState } from "react";
import { dashboard, type Dashboard } from "@/data/dashboard";

const STORAGE_KEY = "dashboard-integration-overrides";
const CHANGE_EVENT = "dashboard-overrides:change";

export type IntegrationOverrides = {
  github?: { enabled?: boolean; username?: string };
  leetcode?: { enabled?: boolean; username?: string };
};

export type IntegrationKey = keyof Dashboard["integrations"];

function loadOverrides(): IntegrationOverrides {
  if (typeof window === "undefined") return {};
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return {};
    const parsed: unknown = JSON.parse(raw);
    if (typeof parsed !== "object" || parsed === null) return {};
    return parsed as IntegrationOverrides;
  } catch {
    return {};
  }
}

export function saveIntegrationOverrides(next: IntegrationOverrides) {
  try {
    const hasValues = Object.values(next).some(
      (v) => v && (v.enabled !== undefined || (v.username ?? "") !== ""),
    );
    if (hasValues) {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
    } else {
      window.localStorage.removeItem(STORAGE_KEY);
    }
  } catch {
    /* storage unavailable — overrides simply won't persist */
  }
  window.dispatchEvent(new Event(CHANGE_EVENT));
}

export function clearIntegrationOverrides() {
  saveIntegrationOverrides({});
}

export function mergeIntegrations(
  base: Dashboard["integrations"],
  overrides: IntegrationOverrides,
): Dashboard["integrations"] {
  return {
    github: {
      enabled: overrides.github?.enabled ?? base.github.enabled,
      username:
        overrides.github?.username !== undefined
          ? overrides.github.username.trim() || null
          : base.github.username,
    },
    leetcode: {
      enabled: overrides.leetcode?.enabled ?? base.leetcode.enabled,
      username:
        overrides.leetcode?.username !== undefined
          ? overrides.leetcode.username.trim() || null
          : base.leetcode.username,
    },
  };
}

/**
 * Reactive integration config: static dashboard.ts defaults merged with
 * any settings-panel overrides. SSR/initial render uses the file defaults;
 * overrides hydrate on mount to avoid hydration mismatches.
 */
export function useDashboardIntegrations(): {
  integrations: Dashboard["integrations"];
  overrides: IntegrationOverrides;
  hasOverrides: boolean;
} {
  const [overrides, setOverrides] = useState<IntegrationOverrides>({});

  useEffect(() => {
    setOverrides(loadOverrides());
    const onChange = () => setOverrides(loadOverrides());
    window.addEventListener(CHANGE_EVENT, onChange);
    window.addEventListener("storage", onChange);
    return () => {
      window.removeEventListener(CHANGE_EVENT, onChange);
      window.removeEventListener("storage", onChange);
    };
  }, []);

  const integrations = useMemo(
    () => mergeIntegrations(dashboard.integrations, overrides),
    [overrides],
  );

  const hasOverrides =
    overrides.github?.enabled !== undefined ||
    overrides.leetcode?.enabled !== undefined ||
    (overrides.github?.username ?? "") !== "" ||
    (overrides.leetcode?.username ?? "") !== "";

  return { integrations, overrides, hasOverrides };
}
