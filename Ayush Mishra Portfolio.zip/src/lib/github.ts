import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import type {
  GithubData,
  GithubIssue,
  GithubIssuesResult,
  GithubLanguageShare,
  GithubReadme,
  GithubRepo,
} from "@/types/github";

/**
 * Public GitHub data fetcher (server-side).
 *
 * Uses only public REST endpoints — no credentials are required and none are
 * exposed to the browser. An optional server-only `GITHUB_TOKEN` secret simply
 * raises the rate limit. Failures never fabricate data: they return an error
 * string and empty results so the UI can show its fallback.
 */

export const GITHUB_USERNAME = "ayush3020";
export const GITHUB_PROFILE_URL = `https://github.com/${GITHUB_USERNAME}`;

const input = (data: unknown) =>
  z
    .object({
      username: z.string().min(1).default(GITHUB_USERNAME),
      /** Include empty repositories (skipped in the compact homepage panel). */
      includeAll: z.boolean().default(false),
    })
    .parse(data ?? {});

function scoreRepo(repo: GithubRepo): number {
  let score = 0;
  if (repo.description) score += 3;
  if (repo.language) score += 2;
  score += Math.min(repo.stars, 5);
  score += Math.min(repo.forks, 3);
  const days = (Date.now() - new Date(repo.updatedAt).getTime()) / 86_400_000;
  if (days < 30) score += 4;
  else if (days < 180) score += 2;
  else if (days < 365) score += 1;
  return score;
}

/** Ranks repos: recently updated, described, with a recognizable language first. */
export function rankRepos(repos: GithubRepo[], limit = 4): GithubRepo[] {
  return [...repos].sort((a, b) => scoreRepo(b) - scoreRepo(a)).slice(0, limit);
}

function languageShare(repos: GithubRepo[]): GithubLanguageShare[] {
  const counts = new Map<string, number>();
  for (const repo of repos) {
    if (!repo.language) continue;
    counts.set(repo.language, (counts.get(repo.language) ?? 0) + 1);
  }
  const total = [...counts.values()].reduce((sum, n) => sum + n, 0);
  if (total === 0) return [];
  return [...counts.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([language, repos_]) => ({
      language,
      repos: repos_,
      percent: Math.round((repos_ / total) * 100),
    }));
}

export const fetchGithubProfile = createServerFn({ method: "GET" })
  .inputValidator(input)
  .handler(async ({ data }): Promise<GithubData> => {
    const username = data.username;
    const profileUrl = `https://github.com/${username}`;
    const token = process.env["GITHUB_TOKEN"];
    const headers: Record<string, string> = {
      Accept: "application/vnd.github+json",
      "User-Agent": "portfolio",
    };
    if (token) headers["Authorization"] = `Bearer ${token}`;

    const empty: GithubData = { profile: null, repos: [], languages: [], error: null };

    try {
      const [userRes, reposRes] = await Promise.all([
        fetch(`https://api.github.com/users/${encodeURIComponent(username)}`, { headers }),
        fetch(
          `https://api.github.com/users/${encodeURIComponent(username)}/repos?per_page=100&sort=updated&type=owner`,
          { headers },
        ),
      ]);

      if (!userRes.ok) {
        return { ...empty, error: `GitHub API responded ${userRes.status}` };
      }

      const user = (await userRes.json()) as Record<string, unknown>;

      let repos: GithubRepo[] = [];
      if (reposRes.ok) {
        const raw = (await reposRes.json()) as Array<Record<string, unknown>>;
        repos = raw
          .filter(
            (r) =>
              !r["fork"] && !r["archived"] && (data.includeAll || (r["size"] as number) > 0),
          )
          .map((r) => ({
            id: Number(r["id"]),
            name: String(r["name"]),
            description: (r["description"] as string | null) ?? null,
            language: (r["language"] as string | null) ?? null,
            stars: Number(r["stargazers_count"] ?? 0),
            forks: Number(r["forks_count"] ?? 0),
            updatedAt: String(r["pushed_at"] ?? r["updated_at"] ?? ""),
            url: String(r["html_url"]),
            topics: Array.isArray(r["topics"]) ? (r["topics"] as string[]) : [],
          }));
      }

      return {
        profile: {
          username: String(user["login"] ?? username),
          profileUrl: String(user["html_url"] ?? profileUrl),
          avatarUrl: (user["avatar_url"] as string | null) ?? null,
          name: (user["name"] as string | null) ?? null,
          bio: (user["bio"] as string | null) ?? null,
          publicRepos: typeof user["public_repos"] === "number" ? user["public_repos"] : null,
          followers: typeof user["followers"] === "number" ? user["followers"] : null,
        },
        repos,
        languages: languageShare(repos),
        error: null,
      };
    } catch {
      return { ...empty, error: "Could not reach GitHub" };
    }
  });

/**
 * Splits fetched repositories into manually featured ones (see
 * src/data/github.ts) and a ranked archive of the rest. Featured names that
 * do not exist on the account are ignored — nothing is fabricated.
 */
export function curateRepos(
  repos: GithubRepo[],
  featuredNames: string[],
  archiveLimit = 4,
): { featured: GithubRepo[]; archive: GithubRepo[] } {
  const wanted = new Set(featuredNames.map((n) => n.toLowerCase()));
  const featured = repos.filter((r) => wanted.has(r.name.toLowerCase()));
  const rest = repos.filter((r) => !wanted.has(r.name.toLowerCase()));
  return { featured, archive: rankRepos(rest, archiveLimit) };
}

/* ------------------------------------------------------------------
 * Repository detail: README + issues (public endpoints only)
 * ---------------------------------------------------------------- */

function ghHeaders(extra?: Record<string, string>): Record<string, string> {
  const token = process.env["GITHUB_TOKEN"];
  const headers: Record<string, string> = {
    Accept: "application/vnd.github+json",
    "User-Agent": "portfolio",
    ...extra,
  };
  if (token) headers["Authorization"] = `Bearer ${token}`;
  return headers;
}

const repoInput = (data: unknown) =>
  z
    .object({ owner: z.string().min(1), repo: z.string().min(1) })
    .parse(data);

export const fetchRepoReadme = createServerFn({ method: "GET" })
  .inputValidator(repoInput)
  .handler(async ({ data }): Promise<GithubReadme> => {
    try {
      const res = await fetch(
        `https://api.github.com/repos/${encodeURIComponent(data.owner)}/${encodeURIComponent(data.repo)}/readme`,
        { headers: ghHeaders({ Accept: "application/vnd.github.raw" }) },
      );
      if (res.status === 404) return { markdown: null, error: null };
      if (!res.ok) return { markdown: null, error: `GitHub API responded ${res.status}` };
      return { markdown: await res.text(), error: null };
    } catch {
      return { markdown: null, error: "Could not reach GitHub" };
    }
  });

export const fetchRepoIssues = createServerFn({ method: "GET" })
  .inputValidator(repoInput)
  .handler(async ({ data }): Promise<GithubIssuesResult> => {
    try {
      const res = await fetch(
        `https://api.github.com/repos/${encodeURIComponent(data.owner)}/${encodeURIComponent(data.repo)}/issues?state=open&per_page=20&sort=created&direction=desc`,
        { headers: ghHeaders() },
      );
      if (!res.ok) return { issues: [], error: `GitHub API responded ${res.status}` };
      const raw = (await res.json()) as Array<Record<string, unknown>>;
      const issues: GithubIssue[] = raw.map((i) => ({
        id: Number(i["id"]),
        number: Number(i["number"]),
        title: String(i["title"] ?? ""),
        state: String(i["state"] ?? "open"),
        url: String(i["html_url"] ?? ""),
        createdAt: String(i["created_at"] ?? ""),
        labels: Array.isArray(i["labels"])
          ? (i["labels"] as Array<Record<string, unknown>>).map((l) => String(l["name"] ?? ""))
          : [],
        comments: Number(i["comments"] ?? 0),
        isPullRequest: Boolean(i["pull_request"]),
      }));
      return { issues, error: null };
    } catch {
      return { issues: [], error: "Could not reach GitHub" };
    }
  });

/** Normalises a name/slug/title so "VisionMark AI" can match "visionmark-ai". */
function normalizeName(value: string): string {
  return value.toLowerCase().replace(/[^a-z0-9]/g, "");
}

/**
 * Resolves a repository URL for a project from real fetched repositories.
 * Returns null when no repository plausibly matches — nothing is invented.
 */
export function matchRepoUrl(
  project: { slug: string; title: string },
  repos: Array<{ name: string; url: string }>,
): string | null {
  const candidates = [normalizeName(project.slug), normalizeName(project.title)];
  const hit = repos.find((r) => candidates.includes(normalizeName(r.name)));
  return hit ? hit.url : null;
}
