import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import type { LeetcodeProfile } from "@/types/leetcode";

/**
 * Public LeetCode profile fetcher (server-side, no credentials).
 * Any failure returns nulls plus an error string — never fabricated values.
 */

export const LEETCODE_USERNAME = "itsansh30";
export const LEETCODE_PROFILE_URL = `https://leetcode.com/u/${LEETCODE_USERNAME}/`;

const input = (data: unknown) =>
  z.object({ username: z.string().min(1).default(LEETCODE_USERNAME) }).parse(data ?? {});

const QUERY = `
  query publicProfile($username: String!) {
    matchedUser(username: $username) {
      username
      profile { ranking }
      badges { displayName }
      languageProblemCount { languageName problemsSolved }
      submitStats { acSubmissionNum { difficulty count } }
    }
    userContestRanking(username: $username) { rating }
  }
`;

export const fetchLeetcodeProfile = createServerFn({ method: "GET" })
  .inputValidator(input)
  .handler(async ({ data }): Promise<LeetcodeProfile> => {
    const username = data.username;
    const profileUrl = `https://leetcode.com/u/${username}/`;
    const empty: LeetcodeProfile = {
      username,
      profileUrl,
      totalSolved: null,
      easy: null,
      medium: null,
      hard: null,
      ranking: null,
      contestRating: null,
      badges: [],
      languages: [],
      error: null,
    };

    try {
      const res = await fetch("https://leetcode.com/graphql", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Referer: profileUrl,
          "User-Agent": "Mozilla/5.0 portfolio",
        },
        body: JSON.stringify({ query: QUERY, variables: { username } }),
      });

      if (!res.ok) return { ...empty, error: `LeetCode responded ${res.status}` };

      const json = (await res.json()) as {
        data?: {
          matchedUser?: {
            profile?: { ranking?: number | null } | null;
            badges?: Array<{ displayName?: string | null }> | null;
            languageProblemCount?: Array<{
              languageName?: string;
              problemsSolved?: number;
            }> | null;
            submitStats?: { acSubmissionNum?: Array<{ difficulty: string; count: number }> } | null;
          } | null;
          userContestRanking?: { rating?: number | null } | null;
        };
      };

      const user = json.data?.matchedUser;
      if (!user) return { ...empty, error: "LeetCode profile not found" };

      const buckets = user.submitStats?.acSubmissionNum ?? [];
      const pick = (difficulty: string) =>
        buckets.find((b) => b.difficulty === difficulty)?.count ?? null;

      const rating = json.data?.userContestRanking?.rating;

      return {
        ...empty,
        totalSolved: pick("All"),
        easy: pick("Easy"),
        medium: pick("Medium"),
        hard: pick("Hard"),
        ranking: typeof user.profile?.ranking === "number" ? user.profile.ranking : null,
        contestRating: typeof rating === "number" ? Math.round(rating) : null,
        badges: (user.badges ?? [])
          .map((b) => b.displayName)
          .filter((b): b is string => Boolean(b))
          .slice(0, 6),
        languages: (user.languageProblemCount ?? [])
          .filter((l) => l.languageName && typeof l.problemsSolved === "number")
          .sort((a, b) => (b.problemsSolved ?? 0) - (a.problemsSolved ?? 0))
          .slice(0, 5)
          .map((l) => ({ language: l.languageName as string, problemsSolved: l.problemsSolved as number })),
        error: null,
      };
    } catch {
      return { ...empty, error: "Could not reach LeetCode" };
    }
  });
