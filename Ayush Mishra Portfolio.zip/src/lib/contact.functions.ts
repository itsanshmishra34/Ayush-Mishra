import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const contactSchema = z.object({
  name: z.string().trim().min(1, "Name is required").max(100),
  email: z.string().trim().email("Invalid email address").max(255),
  message: z.string().trim().min(1, "Message is required").max(2000),
});

export type ContactResult = {
  ok: boolean;
  /** true when the inquiry was delivered by email, false when only stored. */
  emailed: boolean;
  message: string;
};

const RECIPIENT = "itsanshmishra34@gmail.com";

export const sendContactMessage = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => contactSchema.parse(data))
  .handler(async ({ data }): Promise<ContactResult> => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const apiKey = process.env["RESEND_API_KEY"];
    let emailed = false;

    if (apiKey) {
      try {
        const res = await fetch("https://api.resend.com/emails", {
          method: "POST",
          headers: {
            Authorization: `Bearer ${apiKey}`,
            "content-type": "application/json",
          },
          body: JSON.stringify({
            from: "Portfolio Contact <onboarding@resend.dev>",
            to: [RECIPIENT],
            reply_to: data.email,
            subject: `Portfolio enquiry from ${data.name}`,
            text: `${data.message}\n\n— ${data.name} <${data.email}>`,
          }),
        });
        emailed = res.ok;
        if (!res.ok) {
          console.error("Resend error", res.status, await res.text());
        }
      } catch (error) {
        console.error("Resend request failed", error);
      }
    }

    const { error } = await supabaseAdmin.from("contact_messages").insert({
      name: data.name,
      email: data.email,
      message: data.message,
      emailed,
    });

    if (error) {
      console.error("Failed to store contact message", error);
      if (!emailed) {
        return {
          ok: false,
          emailed: false,
          message: "Something went wrong. Please email me directly instead.",
        };
      }
    }

    return {
      ok: true,
      emailed,
      message: emailed
        ? "Thanks — your message has been sent."
        : "Thanks — your message was received and saved to my inbox.",
    };
  });
