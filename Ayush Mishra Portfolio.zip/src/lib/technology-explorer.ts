/**
 * TECHNOLOGY EXPLORER — DERIVATION LOGIC
 * --------------------------------------
 * Pure functions that derive explorer results from the canonical data
 * sources. No content is duplicated here; everything is computed from:
 *   - src/data/skills.ts       (skill groups)
 *   - src/data/projects.ts     (projects + categories)
 *   - src/data/experience.ts   (experience items)
 *
 * Relationships are ONLY the ones present in that data. A technology with
 * no linked project/experience yields an honest empty state — nothing is
 * fabricated.
 */

import { skillGroups } from "@/data/skills";
import { projects, type Project } from "@/data/projects";
import { experience, type ExperienceItem } from "@/data/experience";

/** The fixed set of selectable technology chips, in display order. */
export const explorerTechnologies = [
  "C++",
  "Python",
  "SQL",
  "DSA",
  "OpenCV",
  "MongoDB",
  "HTML",
  "CSS",
  "Git",
] as const;

export type ExplorerTechnology = (typeof explorerTechnologies)[number];

/**
 * Alias map: a chip label may correspond to a longer canonical name in the
 * underlying data (e.g. the "DSA" chip matches "Data Structures & Algorithms").
 * Matching is case-insensitive.
 */
const TECH_ALIASES: Record<string, string[]> = {
  dsa: ["data structures & algorithms", "dsa"],
};

function namesFor(tech: string): string[] {
  const key = tech.trim().toLowerCase();
  return [key, ...(TECH_ALIASES[key] ?? [])];
}

function matchesName(value: string, tech: string): boolean {
  const v = value.trim().toLowerCase();
  return namesFor(tech).includes(v);
}

export type TechnologyResult = {
  technology: ExplorerTechnology;
  /** Projects whose `technologies` list includes this technology. */
  projects: Project[];
  /** Distinct categories of the matched projects. */
  categories: string[];
  /** Skill-group entries related to this technology. */
  relatedSkills: { group: string; item: string }[];
  /**
   * Experience items linked to this technology via their optional
   * `technologies` field. Empty until real relationships are added to
   * src/data/experience.ts — the UI shows an honest empty state.
   */
  experience: ExperienceItem[];
};

/** Derives everything shown for a selected technology chip. */
export function exploreTechnology(tech: ExplorerTechnology): TechnologyResult {
  const matchedProjects = projects.filter((p) =>
    p.technologies.some((t) => matchesName(t, tech)),
  );

  const categories = [...new Set(matchedProjects.map((p) => p.category))];

  const relatedSkills = skillGroups.flatMap((group) =>
    group.items
      .filter((item) => matchesName(item, tech))
      .map((item) => ({ group: group.category, item })),
  );

  const linkedExperience = experience.filter((item) =>
    (item.technologies ?? []).some((t) => matchesName(t, tech)),
  );

  return {
    technology: tech,
    projects: matchedProjects,
    categories,
    relatedSkills,
    experience: linkedExperience,
  };
}
