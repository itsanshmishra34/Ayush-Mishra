import { defineMcp } from "@lovable.dev/mcp-js";
import getProfileTool from "./tools/get-profile";
import listProjectsTool from "./tools/list-projects";
import getProjectTool from "./tools/get-project";
import getResumeTool from "./tools/get-resume";

export default defineMcp({
  name: "ayush-mishra-portfolio",
  title: "Ayush Mishra Portfolio",
  version: "0.1.0",
  instructions:
    "Read-only tools exposing the public content of Ayush Mishra's software engineering portfolio: profile, projects (including the VisionMark AI case study) and resume data (education, skills, experience, certifications, build log). All data is public and factual — never infer or extend beyond what the tools return.",
  // Cast: tools without an outputSchema are fine at runtime; the SDK's type
  // is stricter than needed under exactOptionalPropertyTypes.
  tools: [getProfileTool, listProjectsTool, getProjectTool, getResumeTool] as never,
});
