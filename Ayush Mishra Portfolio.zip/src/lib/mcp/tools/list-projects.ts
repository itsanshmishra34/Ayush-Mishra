import { defineTool } from "@lovable.dev/mcp-js";
import { projects } from "@/data/projects";

export default defineTool({
  name: "list_projects",
  title: "List projects",
  description:
    "List Ayush Mishra's public portfolio projects with descriptions, technologies, status and any available links.",
  inputSchema: {},
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: () => {
    const items = projects.map((p) => ({
      slug: p.slug,
      title: p.title,
      description: p.shortDescription,
      technologies: p.technologies,
      category: p.category,
      status: p.status,
      year: p.year,
      featured: p.featured,
      highlights: p.highlights ?? [],
      githubUrl: p.githubUrl ?? null,
      liveUrl: p.liveUrl ?? null,
      hasCaseStudy: Boolean(p.caseStudy),
    }));
    return {
      content: [{ type: "text", text: JSON.stringify(items, null, 2) }],
      structuredContent: { projects: items },
    };
  },
});
