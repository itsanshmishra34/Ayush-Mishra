import { defineTool } from "@lovable.dev/mcp-js";
import { profile } from "@/data/portfolio";
import { skillGroups } from "@/data/skills";
import { education } from "@/data/education";
import { certifications } from "@/data/certifications";
import { experience } from "@/data/experience";
import { sortedBuildLog } from "@/data/buildLog";

export default defineTool({
  name: "get_resume",
  title: "Get resume",
  description:
    "Get the public resume data: education, technical skills, experience and leadership roles, certifications and build log entries.",
  inputSchema: {},
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: () => {
    const data = {
      name: profile.name,
      headline: profile.headline,
      location: profile.location,
      resumeUrl: profile.resumeUrl,
      education,
      skills: skillGroups.map((g) => ({ category: g.category, items: [...g.items] })),
      experience: experience.map((e) => ({
        role: e.role,
        organization: e.organization,
        period: e.period,
        description: e.description,
        responsibilities: e.responsibilities,
        skills: e.skills,
      })),
      certifications,
      buildLog: sortedBuildLog(),
    };
    return {
      content: [{ type: "text", text: JSON.stringify(data, null, 2) }],
      structuredContent: data,
    };
  },
});
