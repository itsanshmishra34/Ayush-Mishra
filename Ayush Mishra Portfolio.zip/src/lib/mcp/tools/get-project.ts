import { defineTool, ToolError } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { projects } from "@/data/projects";

export default defineTool({
  name: "get_project",
  title: "Get project",
  description:
    "Get full public details for one project by slug, including its conceptual architecture and case study when available.",
  inputSchema: { slug: z.string().min(1).describe("Project slug, e.g. visionmark-ai") },
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: ({ slug }) => {
    const project = projects.find((p) => p.slug === slug);
    if (!project) {
      throw new ToolError(
        `No project with slug "${slug}". Known slugs: ${projects.map((p) => p.slug).join(", ")}`,
      );
    }
    return {
      content: [{ type: "text", text: JSON.stringify(project, null, 2) }],
      structuredContent: { project },
    };
  },
});
