import { defineTool } from "@lovable.dev/mcp-js";
import { profile } from "@/data/portfolio";

export default defineTool({
  name: "get_profile",
  title: "Get profile",
  description:
    "Get Ayush Mishra's public profile: headline, location, contact links, about statement and current roles.",
  inputSchema: {},
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: () => {
    const data = {
      name: profile.name,
      headline: profile.headline,
      tagline: profile.tagline,
      location: profile.location,
      email: profile.email,
      linkedin: profile.linkedin,
      resumeUrl: profile.resumeUrl,
      about: [profile.aboutStatement, ...profile.aboutParagraphs],
      roles: [...profile.roles],
    };
    return {
      content: [{ type: "text", text: JSON.stringify(data, null, 2) }],
      structuredContent: data,
    };
  },
});
