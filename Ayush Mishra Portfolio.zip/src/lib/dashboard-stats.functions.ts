import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

/**
 * Optional public-stat fetchers for the Engineering Snapshot.
 *
 * These NEVER fabricate data: any failure returns `null` fields so the UI
 * falls back to its placeholder state. No credentials are required, but a
 * server-side `GITHUB_TOKEN` secret (never exposed to the browser) raises
 * the GitHub API rate limit when present.
 */

const usernameInput = (data: unknown) => z.object({ username: z.string().min(1) }).parse(data);

export type GithubStats = {
  publicRepos: number | null;
  followers: number | null;
  topLanguages: string[];
  profileUrl: string | null;
  error: string | null;
};

export type LeetcodeStats = {
  totalSolved: number | null;
  easy: number | null;
  medium: number | null;
  hard: number | null;
  currentStreak: number | null;
  profileUrl: string | null;
  error: string | null;
};

const emptyGithub: GithubStats = {
  publicRepos: null,
  followers: null,
  topLanguages: [],
  profileUrl: null,
  error: null,
};

const emptyLeetcode: LeetcodeStats = {
  totalSolved: null,
  easy: null,
  medium: null,
  hard: null,
  currentStreak: null,
  profileUrl: null,
  error: null,
};

export const fetchGithubStats = createServerFn({ method: "GET" })
  .inputValidator(usernameInput)
  .handler(async ({ data }): Promise<GithubStats> => {
    const token = process.env["GITHUB_TOKEN"];
    const headers: Record<string, string> = {
      Accept: "application/vnd.github+json",
      "User-Agent": "portfolio-dashboard",
    };
    if (token) headers["Authorization"] = `Bearer ${token}`;

    try {
      const [userRes, reposRes] = await Promise.all([
        fetch(`https://api.github.com/users/${encodeURIComponent(data.username)}`, { headers }),
        fetch(
          `https://api.github.com/users/${encodeURIComponent(data.username)}/repos?per_page=100&sort=updated`,
          { headers },
        ),
      ]);

      if (!userRes.ok) {
        return { ...emptyGithub, error: `GitHub API responded ${userRes.status}` };
      }

      const user = (await userRes.json()) as {
        public_repos?: number;
        followers?: number;
        html_url?: string;
      };

      let topLanguages: string[] = [];
      if (reposRes.ok) {
        const repos = (await reposRes.json()) as Array<{ language?: string | null }>;
        const counts = new Map<string, number>();
        for (const repo of repos) {
          if (!repo.language) continue;
          counts.set(repo.language, (counts.get(repo.language) ?? 0) + 1);
        }
        topLanguages = [...counts.entries()]
          .sort((a, b) => b[1] - a[1])
          .slice(0, 5)
          .map(([language]) => language);
      }

      return {
        publicRepos: typeof user.public_repos === "number" ? user.public_repos : null,
        followers: typeof user.followers === "number" ? user.followers : null,
        topLanguages,
        profileUrl: user.html_url ?? `https://github.com/${data.username}`,
        error: null,
      };
    } catch {
      return { ...emptyGithub, error: "Could not reach GitHub" };
    }
  });

const LEETCODE_QUERY = `
  query userStats($username: String!) {
    matchedUser(username: $username) {
      username
      submitStats { acSubmissionNum { difficulty count } }
      submissionCalendar
    }
  }
`;

/** Consecutive days (ending today or yesterday) with at least one submission. */
function computeStreak(calendar: Record<string, number>): number | null {
  const days = new Set<string>();
  for (const [ts, count] of Object.entries(calendar)) {
    if (!count) continue;
    const date = new Date(Number(ts) * 1000);
    days.add(date.toISOString().slice(0, 10));
  }
  if (days.size === 0) return 0;

  const cursor = new Date();
  const today = cursor.toISOString().slice(0, 10);
  if (!days.has(today)) cursor.setUTCDate(cursor.getUTCDate() - 1);

  let streak = 0;
  while (days.has(cursor.toISOString().slice(0, 10))) {
    streak += 1;
    cursor.setUTCDate(cursor.getUTCDate() - 1);
  }
  return streak;
}

export const fetchLeetcodeStats = createServerFn({ method: "GET" })
  .inputValidator(usernameInput)
  .handler(async ({ data }): Promise<LeetcodeStats> => {
    const profileUrl = `https://leetcode.com/u/${data.username}/`;
    try {
      const res = await fetch("https://leetcode.com/graphql", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Referer: profileUrl,
          "User-Agent": "portfolio-dashboard",
        },
        body: JSON.stringify({
          query: LEETCODE_QUERY,
          variables: { username: data.username },
        }),
      });

      if (!res.ok) {
        return { ...emptyLeetcode, profileUrl, error: `LeetCode responded ${res.status}` };
      }

      const json = (await res.json()) as {
        data?: {
          matchedUser?: {
            submitStats?: { acSubmissionNum?: Array<{ difficulty: string; count: number }> };
            submissionCalendar?: string;
          } | null;
        };
      };

      const user = json.data?.matchedUser;
      if (!user) {
        return { ...emptyLeetcode, profileUrl, error: "LeetCode profile not found" };
      }

      const buckets = user.submitStats?.acSubmissionNum ?? [];
      const pick = (difficulty: string) =>
        buckets.find((b) => b.difficulty === difficulty)?.count ?? null;

      let currentStreak: number | null = null;
      if (user.submissionCalendar) {
        try {
          currentStreak = computeStreak(
            JSON.parse(user.submissionCalendar) as Record<string, number>,
          );
        } catch {
          currentStreak = null;
        }
      }

      return {
        totalSolved: pick("All"),
        easy: pick("Easy"),
        medium: pick("Medium"),
        hard: pick("Hard"),
        currentStreak,
        profileUrl,
        error: null,
      };
    } catch {
      return { ...emptyLeetcode, profileUrl, error: "Could not reach LeetCode" };
    }
  });
