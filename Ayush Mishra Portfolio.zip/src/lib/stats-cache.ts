/**
 * Last-known stats cache
 * -----------------------------------------------------------------
 * Persists the most recent successful GitHub / LeetCode payload in
 * localStorage so a failed live request can fall back to real,
 * previously-fetched values instead of an empty or broken card.
 * Nothing here invents data — it only replays what was fetched before.
 */

const PREFIX = "portfolio:stats-cache:";

export type CachedSnapshot<T> = {
  data: T;
  fetchedAt: string;
};

export function readSnapshot<T>(key: string): CachedSnapshot<T> | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(PREFIX + key);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as CachedSnapshot<T>;
    if (!parsed || typeof parsed.fetchedAt !== "string" || parsed.data == null) return null;
    return parsed;
  } catch {
    return null;
  }
}

export function writeSnapshot<T>(key: string, data: T): void {
  if (typeof window === "undefined") return;
  try {
    const payload: CachedSnapshot<T> = { data, fetchedAt: new Date().toISOString() };
    window.localStorage.setItem(PREFIX + key, JSON.stringify(payload));
  } catch {
    /* storage unavailable — live data still renders */
  }
}

export function formatFetchedAt(iso: string): string {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return "earlier";
  return date.toLocaleString(undefined, {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}
