/**
 * BUILD LOG
 * -----------------------------------------------------------------
 * A lightweight, chronological log of what is being built, learned or
 * shipped. Add an entry by appending an object below — the UI renders
 * automatically and shows a clean empty state when the list is empty.
 *
 * Never add speculative or placeholder entries: only real, factual ones.
 */

export type BuildLogCategory = "Building" | "Learning" | "Project" | "Achievement";

export type BuildLogEntry = {
  id: string;
  /** ISO date string, e.g. "2026-08-01". */
  date: string;
  category: BuildLogCategory;
  title: string;
  description: string;
  technologies?: string[];
  link?: { label: string; url: string } | null;
};

export const buildLogCategories: BuildLogCategory[] = [
  "Building",
  "Learning",
  "Project",
  "Achievement",
];

export const buildLog: BuildLogEntry[] = [];

/** Newest first. */
export function sortedBuildLog(entries: BuildLogEntry[] = buildLog): BuildLogEntry[] {
  return [...entries].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
}
