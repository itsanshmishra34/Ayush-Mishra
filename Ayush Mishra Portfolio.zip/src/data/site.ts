// Site-level constants. `lastUpdated` is an intentional, manually set date —
// it is not generated at build time so it never shows a fake changing value.

export const site = {
  /** Production portfolio URL used for sharing and QR codes. */
  url: "https://ayush-codes-portfolio.lovable.app",
  name: "Ayush Mishra",
  title: "Ayush Mishra | Aspiring Software Engineer",
  /** Update this manually whenever the portfolio is meaningfully revised. */
  lastUpdated: "29 Aug 2026",
  links: {
    github: "https://github.com/ayush3020",
    leetcode: "https://leetcode.com/u/itsansh30/",
    linkedin: "https://www.linkedin.com/in/ayush-mishra-12b36a37a/",
    email: "itsanshmishra34@gmail.com",
  },
} as const;
