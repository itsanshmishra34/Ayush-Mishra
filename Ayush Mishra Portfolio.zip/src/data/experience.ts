/**
 * Centralized experience data.
 *
 * Edit this file only — the Experience timeline UI renders entirely from here.
 * Nothing is invented: `description`, `responsibilities` and `skills` are left
 * empty until real, verified content is added. Empty fields simply don't render.
 */

export type ExperienceInput = {
  id: string;
  organization: string;
  /** e.g. "LPU Student Club", "Company", "University Program". */
  organizationType?: string | null;
  role: string;
  /** e.g. "July 2026" */
  startDate: string;
  /** `null` means the role is ongoing → rendered as "Present". */
  endDate: string | null;
  /** High-level bucket, e.g. "Leadership & Community". */
  category?: string | null;
  /** Short overview of the role. Empty string = hidden. */
  description: string;
  /** Real responsibilities only. Empty array = section hidden. */
  responsibilities: string[];
  /** Focus areas / themes for the role. Empty array = section hidden. */
  focus?: string[];
  /** Skills genuinely involved in the role. Empty array = chips hidden. */
  skills: string[];
  /** Optional logo path/URL. `null` = initial-letter marker is used. */
  logo: string | null;
  /** Optional external organization URL. `null` = no link. */
  organizationUrl?: string | null;
  /** Optional proof links — buttons only render when a real URL is set. */
  proofUrl?: string | null;
  certificateUrl?: string | null;
  postUrl?: string | null;
};

export type ExperienceItem = ExperienceInput & {
  /** Derived: "July 2026 – Present". */
  period: string;
  /** Alias of `organization`, kept for existing consumers. */
  company: string;
  /** Alias of `skills`, used by the Technology Explorer. */
  technologies: string[];
};

function build(item: ExperienceInput): ExperienceItem {
  return {
    ...item,
    period: `${item.startDate} – ${item.endDate ?? "Present"}`,
    company: item.organization,
    technologies: item.skills,
  };
}

const items: ExperienceInput[] = [
  {
    id: "syynapse",
    organization: "Syynapse",
    organizationType: "LPU Student Club",
    role: "Associate Principal",
    startDate: "July 2026",
    endDate: null,
    category: "Leadership & Community",
    description:
      "Working as an Associate Principal in Syynapse, an LPU student club, contributing to club activities, collaboration, coordination, and student community engagement.",
    responsibilities: [],
    focus: [
      "Leadership",
      "Team Collaboration",
      "Event Coordination",
      "Community Engagement",
      "Communication",
      "Problem Solving",
    ],
    skills: [],
    logo: null,
    organizationUrl: null,
    proofUrl: null,
    certificateUrl: null,
    postUrl: null,
  },
  {
    id: "google-student-ambassadors",
    organization: "Google Student Ambassadors (India)",
    role: "Campus Ambassador",
    startDate: "July 2026",
    endDate: null,
    description: "",
    responsibilities: [],
    skills: [],
    logo: null,
    proofUrl: null,
    certificateUrl: null,
    postUrl: null,
  },
  {
    id: "matiks",
    organization: "Matiks",
    role: "Point of Contact (POC)",
    startDate: "February 2026",
    endDate: null,
    category: "Event Coordination & Community Operations",
    description:
      "Serving as a Point of Contact (POC) for Matiks, coordinating communication, participant support, and event execution across activities.",
    responsibilities: [
      "Conducted and coordinated multiple events, contributing to successful participation exceeding 3,000+ participants.",
      "Spearheaded on-ground and team coordination to ensure smooth event execution, timely communication, and reliable participant engagement.",
    ],
    focus: ["Event Coordination", "Community Operations", "Communication", "Team Coordination"],
    skills: [],
    logo: null,
    organizationUrl: null,
    proofUrl: null,
    certificateUrl: null,
    postUrl: null,
  },
  {
    id: "geeksforgeeks",
    organization: "GeeksforGeeks",
    role: "Campus Mantri",
    startDate: "June 2026",
    endDate: null,
    description: "",
    responsibilities: [],
    skills: [],
    logo: null,
    proofUrl: null,
    certificateUrl: null,
    postUrl: null,
  },

];

export const experience: ExperienceItem[] = items.map(build);
