/**
 * CENTRAL PROJECT CONFIGURATION
 * -----------------------------
 * Add a new project by appending one object to the `projects` array below.
 * The UI (cards, filters, featured section, detail modal, buttons) is generated
 * automatically from this data — no component changes required.
 *
 * Rules:
 * - Use `null` for any link that does not exist yet. Missing links are hidden.
 * - `image: null` falls back to an abstract visual generated from the category.
 */

export type ProjectStatus = "Completed" | "In Progress" | "Coming Soon" | "Archived";

export type ProjectCategory =
  | "Software Development"
  | "AI / ML"
  | "AI / Computer Vision"
  | "Computer Vision"
  | "Web Development"
  | "Other";

/**
 * Optional CONCEPTUAL architecture flow for a project.
 * Rendered by <ProjectArchitecture /> — reusable for any future project.
 * Describe the conceptual pipeline only; do not imply implementation
 * details that are not documented in the project itself.
 */
export type ArchitectureStep = {
  /** Stable id used for keys and selection. */
  id: string;
  label: string;
  /** Short kind/stage label, e.g. "Input", "Processing", "Output". */
  kind?: string;
  /** One or two sentence conceptual explanation. */
  description: string;
  /** Technologies relevant to this stage (may be empty). */
  technologies?: string[];
  /** Lucide icon key — see ARCHITECTURE_ICONS in ProjectArchitecture.tsx. */
  icon?: string;
};

export type ProjectArchitecture = {
  title?: string;
  /** Shown verbatim so viewers know the diagram is conceptual. */
  note?: string;
  steps: ArchitectureStep[];
};

/**
 * Optional long-form case study. When present the project card opens a
 * full-screen case-study experience instead of the compact detail modal.
 * Every field is optional so future projects can opt into only what they have.
 */
export type CaseStudyTech = {
  name: string;
  /** How this technology relates to the project. Factual only. */
  relation: string;
};

/**
 * Optional engineering decision record. Only add entries backed by real
 * project information — never invent decisions, trade-offs or results.
 */
export type EngineeringDecision = {
  decision: string;
  why: string;
  tradeOff: string;
  result: string;
};

export type CaseStudy = {
  overview: string;
  problem: string;
  /** Conceptual workflow — not a claim of implementation detail. */
  approach: {
    note?: string;
    steps: string[];
    body?: string;
  };
  technologies: CaseStudyTech[];
  /** Optional — rendered only when real decisions are documented. */
  engineeringDecisions?: EngineeringDecision[];
  learnings: string[];
  /** Shown when neither githubUrl nor liveUrl exists. */
  linksNote?: string;
};

export type Project = {
  /** Stable slug used for modal deep-linking and React keys. */
  slug: string;
  title: string;
  shortDescription: string;
  fullDescription?: string | null;
  technologies: string[];
  category: ProjectCategory;
  image?: string | null;
  /** Optional responsive variants (srcSet string) for the project image. */
  imageSrcSet?: string | null;
  /** Optional sizes attribute paired with imageSrcSet. */
  imageSizes?: string | null;
  githubUrl?: string | null;
  liveUrl?: string | null;
  projectUrl?: string | null;
  status: ProjectStatus;
  featured: boolean;
  year: number;
  /** Optional factual bullet points shown in the detail view. */
  highlights?: string[];
  /** Optional conceptual architecture diagram. Omit if not applicable. */
  architecture?: ProjectArchitecture | null;
  /** Optional full case study. Omit for projects without one. */
  caseStudy?: CaseStudy | null;
};


export const projects: Project[] = [
  {
    slug: "visionmark-ai",
    title: "VisionMark AI",
    shortDescription:
      "An AI-powered smart attendance system developed using Python and OpenCV.",
    fullDescription:
      "An AI-powered smart attendance system developed using Python and OpenCV. The system applies computer vision techniques to identify individuals and record attendance, replacing manual roll-call with an automated workflow.",
    technologies: ["Python", "OpenCV", "AI", "Computer Vision"],
    category: "AI / Computer Vision",
    image: "/projects/visionmark.jpg",
    imageSrcSet:
      "/projects/visionmark-480.webp 480w, /projects/visionmark-768.webp 768w, /projects/visionmark-1280.webp 1280w",
    imageSizes: "(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 640px",
    githubUrl: null,
    liveUrl: null,
    projectUrl: null,
    status: "Completed",
    featured: true,
    year: 2026,
    highlights: [
      "Built with Python and the OpenCV computer vision library",
      "Automates attendance marking instead of manual record keeping",
      "Explores practical application of AI in day-to-day workflows",
    ],
    architecture: {
      title: "Architecture",
      note: "Conceptual overview of how the system is intended to flow. It illustrates the pipeline at a high level and is not a claim about every component being implemented.",
      steps: [
        {
          id: "input",
          label: "Input",
          kind: "Source",
          description:
            "The pipeline starts with a visual input — a camera feed or image of the people to be marked present.",
          technologies: ["OpenCV"],
          icon: "camera",
        },
        {
          id: "vision",
          label: "Vision Processing",
          kind: "Processing",
          description:
            "Frames are prepared and analysed using computer vision techniques so that people can be located within the image.",
          technologies: ["Python", "OpenCV", "Computer Vision"],
          icon: "cv",
        },
        {
          id: "identification",
          label: "Identification",
          kind: "Matching",
          description:
            "Detected faces are matched against known individuals to determine who is present.",
          technologies: ["OpenCV", "AI"],
          icon: "face",
        },
        {
          id: "attendance",
          label: "Attendance",
          kind: "Logic",
          description:
            "Identified individuals are turned into attendance entries, replacing manual roll-call.",
          technologies: ["Python"],
          icon: "logic",
        },
        {
          id: "record",
          label: "Record",
          kind: "Output",
          description: "The final output is a recorded attendance result for the session.",
          technologies: [],
          icon: "record",
        },
      ],
    },
    caseStudy: {
      overview:
        "VisionMark AI is an AI-powered smart attendance system developed using Python and OpenCV.",
      problem:
        "Manual attendance processes can be repetitive, time-consuming, and difficult to manage efficiently. Recording who is present by hand takes time away from the session itself and the records still have to be collected and maintained afterwards.",
      approach: {
        note: "This describes the conceptual workflow of the system rather than a claim about every implementation detail.",
        body: "The system is structured as a straightforward vision pipeline: a visual input is processed with computer vision, faces are used to identify individuals, and the result is turned into an attendance record.",
        steps: [
          "Input",
          "Computer Vision",
          "Face Processing",
          "Attendance Identification",
          "Attendance Record",
        ],
      },
      technologies: [
        {
          name: "Python",
          relation:
            "The implementation language for the system — used to tie the vision pipeline and the attendance logic together.",
        },
        {
          name: "OpenCV",
          relation:
            "The computer vision library used to work with camera frames and images inside the pipeline.",
        },
        {
          name: "Computer Vision",
          relation:
            "The field the project draws on: analysing images to locate and work with faces in a frame.",
        },
        {
          name: "AI",
          relation:
            "Applied conceptually to the identification step, where detected faces are matched to known individuals.",
        },
      ],
      learnings: [
        "Fundamentals of computer vision and how images are processed frame by frame.",
        "Practical, hands-on work with the OpenCV library in Python.",
        "Implementing an end-to-end idea in Python rather than isolated scripts.",
        "Breaking a practical, everyday problem down into distinct technical components.",
      ],
      linksNote: "Public repository and live demo are not currently available.",
    },
  },
  {
    slug: "offline-ai-tutor",
    title: "Vedavault — Offline AI Tutor",
    shortDescription:
      "An AI-powered offline tutoring assistant that helps users learn and practice concepts without an internet connection.",
    fullDescription:
      "Vedavault is an AI-powered offline tutoring assistant. It is designed to deliver local, interactive learning support so users can study and practice even when internet connectivity is unavailable.",
    technologies: ["Python", "AI", "LLM"],
    category: "AI / ML",
    image: null,
    githubUrl: "https://github.com/anmol-pandey-2007/Vedavault-AI-Powered-Offline-AI-Tutor",
    liveUrl: null,
    projectUrl: null,
    status: "In Progress",
    featured: false,
    year: 2026,
    highlights: [
      "Designed to run locally without requiring an internet connection",
      "Explores practical use of AI/LLM concepts for interactive learning",
      "Built with Python and AI tooling",
    ],
  },
  {
    slug: "ai-radiology-assistant",
    title: "AI Radiology Assistant",
    shortDescription:
      "A web-based assistant focused on medical-image analysis and radiology support.",
    fullDescription:
      "A web-based assistant focused on medical-image analysis and radiology support, with an interface for submitting and reviewing medical imaging information.",
    technologies: ["Medical Imaging Analysis", "AI", "Web"],
    category: "AI / ML",
    image: null,
    githubUrl: null,
    liveUrl: null,
    projectUrl: null,
    status: "In Progress",
    featured: false,
    year: 2026,
    highlights: [
      "Web-based interface for submitting and reviewing medical imaging information",
      "Focused on medical-image analysis and radiology support",
    ],
  },
  {

    slug: "rfid-door-lock",
    title: "RFID Door Lock – RFID-Based Access Control",
    shortDescription:
      "An RFID-based access control system designed to provide secure and convenient door access. The system uses RFID authentication to identify authorized users and control door access.",
    fullDescription:
      "An RFID-based access control system designed to provide secure and convenient door access. The system reads an RFID card or tag, verifies the user, and controls the door lock through an ESP32 microcontroller and servo motor.",
    technologies: ["RFID", "ESP32", "Servo Motor", "Embedded Systems"],
    category: "Other",
    image: "/projects/rfid-door-lock.jpg",
    githubUrl: null,
    liveUrl: null,
    projectUrl: null,
    status: "Completed",
    featured: false,
    year: 2026,
    highlights: [
      "RFID card/tag authentication for secure access",
      "ESP32 microcontroller driving a servo-based door lock",
      "Focus on security, automation and access control",
    ],
    architecture: {
      title: "Access Flow",
      note: "Conceptual overview of how the RFID access flow is intended to work. It illustrates the pipeline at a high level and is not a claim about every implementation detail.",
      steps: [
        {
          id: "card",
          label: "RFID Card / Tag",
          kind: "Input",
          description: "The user presents an RFID card or tag near the reader to request access.",
          technologies: ["RFID"],
          icon: "input",
        },
        {
          id: "reader",
          label: "RFID Reader",
          kind: "Sensing",
          description: "The reader detects the card and reads its unique identifier.",
          technologies: ["RFID"],
          icon: "camera",
        },
        {
          id: "controller",
          label: "ESP32 Controller",
          kind: "Processing",
          description: "The ESP32 receives the identifier and runs the access-control logic.",
          technologies: ["ESP32", "Embedded Systems"],
          icon: "cv",
        },
        {
          id: "auth",
          label: "Authentication",
          kind: "Verification",
          description: "The identifier is checked against authorized users to grant or deny access.",
          technologies: ["Embedded Systems"],
          icon: "logic",
        },
        {
          id: "lock",
          label: "Door Lock / Servo",
          kind: "Output",
          description: "On successful verification, the servo operates the door lock mechanism.",
          technologies: ["Servo Motor"],
          icon: "record",
        },
      ],
    },
  },
];

/**
 * Optional GitHub integration.
 * Left unconfigured on purpose — the site uses the local `projects` array above.
 * When a username is added AND a server-side fetch is implemented, additional
 * repositories can be merged in. No tokens are ever read in the browser.
 */
export const githubConfig: { username: string | null; enabled: boolean } = {
  username: null,
  enabled: false,
};

/** Filter chips. "All" is prepended by the UI. */
export const projectCategories = [
  "Software Development",
  "AI / ML",
  "Computer Vision",
  "Web Development",
  "Other",
] as const;

export type ProjectFilter = "All" | (typeof projectCategories)[number];

/** Maps a project category onto a filter chip. */
export function matchesFilter(project: Project, filter: ProjectFilter): boolean {
  if (filter === "All") return true;
  if (project.category === filter) return true;
  if (filter === "Computer Vision") return project.category === "AI / Computer Vision";
  if (filter === "AI / ML") return project.category.startsWith("AI /");
  return false;
}
