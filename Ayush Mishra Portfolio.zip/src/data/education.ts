/**
 * EDUCATION DATA
 * Canonical source for the Education section. Add or edit entries here only.
 */

export type EducationItem = {
  institution: string;
  detail: string;
  period: string;
};

export const education: EducationItem[] = [
  {
    institution: "Lovely Professional University",
    detail: "Bachelor of Technology — Computer Science",
    period: "August 2025 – July 2029",
  },
  {
    institution: "S.V.M. Sultanpur",
    detail: "10th & 12th — PCM",
    period: "April 2021 – March 2025",
  },
];
