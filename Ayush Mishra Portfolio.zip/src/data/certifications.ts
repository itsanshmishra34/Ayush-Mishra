/**
 * CERTIFICATIONS DATA
 * Only verified certifications. Issuers/dates are omitted when not confirmed.
 */

export type Certification = {
  name: string;
  issuer?: string | null;
  date?: string | null;
  url?: string | null;
};

export const certifications: Certification[] = [
  { name: "CSS (Basic)" },
  { name: "Python (Basic)" },
  { name: "Certificate of Appreciation — Computer Programming" },
];
