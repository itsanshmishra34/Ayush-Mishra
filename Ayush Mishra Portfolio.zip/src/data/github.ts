/**
 * GITHUB PRESENTATION CONFIG
 * -----------------------------------------------------------------
 * Controls how real GitHub data (fetched in src/lib/github.ts) is
 * presented. No repository metadata is hardcoded here — only curation.
 */

export const githubUsername = "ayush3020";
export const githubProfileUrl = `https://github.com/${githubUsername}`;

/**
 * Repository names to feature. Featured repositories render larger; every
 * other fetched repository goes into the archive list. Names that do not
 * exist on the account are simply ignored.
 */
export const featuredRepositories: string[] = [];

/** How many non-featured repositories to show in the archive list. */
export const archiveLimit = 4;
