/**
 * CENTRAL SKILLS CONFIGURATION
 * ----------------------------
 * Canonical source of skill data. `src/data/portfolio.ts` re-exports
 * `skillGroups` from here so existing imports keep working.
 * Add or edit skills here only — components derive everything from this file.
 */

export type SkillGroup = {
  category: string;
  icon: string;
  items: readonly string[];
};

export const skillGroups: readonly SkillGroup[] = [
  { category: "Programming", icon: "Code2", items: ["C++", "Python"] },
  {
    category: "Core CS",
    icon: "Binary",
    items: ["Data Structures & Algorithms", "Object-Oriented Programming"],
  },
  { category: "Databases", icon: "Database", items: ["SQL", "Relational Databases", "MongoDB"] },
  { category: "AI / Computer Vision", icon: "ScanEye", items: ["OpenCV"] },
  { category: "Web", icon: "Globe", items: ["HTML", "CSS"] },
  { category: "Tools", icon: "GitBranch", items: ["Git", "GitHub"] },
] as const;
