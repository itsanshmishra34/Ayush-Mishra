// Centralised, factual content for the Strengths, Value Proposition and
// Career Direction sections. Nothing here claims achievements or metrics.

export type Strength = {
  id: string;
  title: string;
  description: string;
};

export const strengths: Strength[] = [
  {
    id: "problem-solving",
    title: "Problem Solving",
    description: "Practising Data Structures & Algorithms in C++ to think through problems methodically.",
  },
  {
    id: "technical-learning",
    title: "Technical Learning",
    description: "Building computer science fundamentals across programming, databases and AI/ML.",
  },
  {
    id: "builder-mindset",
    title: "Builder Mindset",
    description: "Learning by building practical projects rather than only reading about them.",
  },
  {
    id: "leadership",
    title: "Leadership",
    description: "Taking on campus leadership roles alongside coursework.",
  },
  {
    id: "communication",
    title: "Communication",
    description: "Explaining technical ideas clearly to peers and non-technical audiences.",
  },
  {
    id: "community",
    title: "Community Engagement",
    description: "Active in student developer communities and campus tech programmes.",
  },
];

export type ValueCard = {
  id: string;
  title: string;
  description: string;
};

export const valueProposition: ValueCard[] = [
  {
    id: "problem-solving",
    title: "Problem Solving",
    description: "Strong focus on DSA and analytical thinking.",
  },
  {
    id: "builder",
    title: "Builder Mindset",
    description: "Learning through practical projects.",
  },
  {
    id: "collaboration",
    title: "Communication & Collaboration",
    description: "Experience through community and leadership activities.",
  },
];

export const careerDirection = {
  statement:
    "My goal is to grow into a strong software engineer by building real-world projects, strengthening my problem-solving skills, and gaining practical industry experience.",
  steps: ["Learn", "Build", "Improve", "Gain Experience", "Software Engineer"],
} as const;

export type ProcessStep = {
  id: string;
  title: string;
  description: string;
};

// A compact, technical description of how work gets done — no motivational filler.
export const buildProcess: ProcessStep[] = [
  {
    id: "understand",
    title: "Understand",
    description: "Understand the problem before writing code.",
  },
  {
    id: "break-down",
    title: "Break Down",
    description: "Break the problem into smaller technical components.",
  },
  {
    id: "build",
    title: "Build",
    description: "Implement, test and iterate.",
  },
  {
    id: "improve",
    title: "Improve",
    description: "Review limitations and improve the solution.",
  },
];
