export const profile = {
  name: "Ayush Mishra",
  headline: "B.Tech CSE @ LPU | Aspiring Software Engineer",
  tagline: "C++ • Python • SQL • DSA • AI/ML",
  heroEyebrow: "Computer Science • Software Development",
  heroHeadline: "Building software. Solving problems. Learning continuously.",
  heroSupport:
    "B.Tech Computer Science student at Lovely Professional University, focused on C++, Python, SQL, DSA, software development, and AI/ML.",
  location: "Sultanpur, Uttar Pradesh, India",
  email: "itsanshmishra34@gmail.com",
  phone: "8052230112",
  linkedin: "https://www.linkedin.com/in/ayush-mishra-12b36a37a",
  resumeUrl: "/resume.pdf",
  aboutStatement: "Computer Science student with a builder's mindset.",
  aboutParagraphs: [
    "I am a Computer Science undergraduate at Lovely Professional University with a strong interest in software development, Python, C++, SQL, Data Structures & Algorithms, and problem solving.",
    "I enjoy building practical software solutions, exploring new technologies, and continuously improving through projects and coding practice.",
    "Alongside technical development, I contribute to student and developer communities through campus initiatives and ambassador programs.",
  ],
  infoBlocks: [
    { label: "Education", value: "LPU • B.Tech CSE • 2025–2029" },
    { label: "Location", value: "Sultanpur, Uttar Pradesh, India" },
    { label: "Current Focus", value: "C++ • DSA • Python • SQL • AI/ML" },
  ],
  roles: [
    "Google Student Ambassador",
    "GeeksforGeeks Campus Mantri",
    "Associate Principal at Syynapse",
  ],
} as const;

// Skills live in src/data/skills.ts (canonical source); re-exported here
// so existing imports keep working.
export { skillGroups } from "@/data/skills";

// Experience data moved to src/data/experience.ts



// Education and certifications live in their own data modules.
export { education } from "@/data/education";
export { certifications } from "@/data/certifications";

export const focusAreas = [
  { index: "01", title: "DSA", description: "Problem solving and algorithmic thinking" },
  {
    index: "02",
    title: "C++",
    description: "Strengthening competitive programming and core programming",
  },
  { index: "03", title: "Python", description: "Software development and AI/ML foundations" },
  {
    index: "04",
    title: "SQL & Databases",
    description: "Building stronger backend and data fundamentals",
  },
] as const;

export const navItems = [
  { id: "home", label: "Home" },
  { id: "about", label: "About" },
  { id: "skills", label: "Skills" },
  { id: "projects", label: "Projects" },
  { id: "explorer", label: "Explorer" },
  { id: "coding", label: "Coding" },
  { id: "experience", label: "Experience" },
  { id: "education", label: "Education" },
  { id: "contact", label: "Contact" },
] as const;
