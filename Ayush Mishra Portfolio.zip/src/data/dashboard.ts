/**
 * Engineering Snapshot — dashboard data (type-safe, runtime-validated).
 *
 * Edit `rawDashboard` below; the UI renders automatically.
 * Every field is validated at module load with Zod. If anything is
 * malformed or missing, a safe fallback is exported instead so the UI
 * degrades to empty states rather than crashing.
 *
 * Problem-solving stats stay `null` unless you set them manually or turn
 * on an integration. Never invent numbers.
 */

import { z } from "zod";

/* ------------------------------------------------------------------ */
/* Schema                                                              */
/* ------------------------------------------------------------------ */

const integrationSchema = z.object({
  /** Real stats are fetched ONLY when this is true. */
  enabled: z.boolean(),
  username: z.string().min(1).nullable(),
});

const dashboardSchema = z.object({
  currentFocus: z.array(z.string().min(1)).default([]),
  currentlyBuilding: z
    .array(z.object({ name: z.string().min(1), detail: z.string().default("") }))
    .default([]),
  problemSolving: z.object({
    /** Manual override — set to a number only if it is real. */
    leetcodeSolved: z.number().int().nonnegative().nullable().default(null),
    /** Manual override — days. */
    currentStreak: z.number().int().nonnegative().nullable().default(null),
    streakUnit: z.string().default("day streak"),
  }),
  technicalInterests: z.array(z.string().min(1)).default([]),
  education: z.object({
    degree: z.string().default(""),
    institution: z.string().default(""),
    period: z.string().default(""),
  }),
  openTo: z.array(z.string().min(1)).default([]),
  integrations: z.object({
    github: integrationSchema,
    leetcode: integrationSchema,
  }),
});

export type Dashboard = z.infer<typeof dashboardSchema>;
export type ProblemSolvingStats = Dashboard["problemSolving"];
export type IntegrationConfig = z.infer<typeof integrationSchema>;

/* ------------------------------------------------------------------ */
/* Data — edit here                                                    */
/* ------------------------------------------------------------------ */

const rawDashboard: unknown = {
  currentFocus: ["C++", "DSA", "Python", "SQL", "AI/ML"],
  currentlyBuilding: [
    { name: "VisionMark AI", detail: "Computer vision system — Python • OpenCV" },
  ],
  problemSolving: {
    leetcodeSolved: null,
    currentStreak: null,
    streakUnit: "day streak",
  },
  technicalInterests: [
    "Software Engineering",
    "Artificial Intelligence",
    "Computer Vision",
    "Databases",
    "Algorithms",
  ],
  education: { degree: "B.Tech CSE", institution: "LPU", period: "2025–2029" },
  openTo: [
    "Software Engineering Internships",
    "Technical Collaborations",
    "Learning Opportunities",
  ],
  integrations: {
    // Flip `enabled` to true to pull live public stats. Off = fully manual.
    github: { enabled: false, username: "itsanshmishra34" },
    leetcode: { enabled: false, username: "itsansh30" },
  },
};

/* ------------------------------------------------------------------ */
/* Safe fallback + parse                                               */
/* ------------------------------------------------------------------ */

const fallbackDashboard: Dashboard = {
  currentFocus: [],
  currentlyBuilding: [],
  problemSolving: { leetcodeSolved: null, currentStreak: null, streakUnit: "day streak" },
  technicalInterests: [],
  education: { degree: "", institution: "", period: "" },
  openTo: [],
  integrations: {
    github: { enabled: false, username: null },
    leetcode: { enabled: false, username: null },
  },
};

function parseDashboard(input: unknown): Dashboard {
  const result = dashboardSchema.safeParse(input);
  if (result.success) return result.data;
  if (import.meta.env.DEV) {
    console.warn(
      "[dashboard] Invalid data in src/data/dashboard.ts — rendering empty states.",
      result.error.flatten(),
    );
  }
  return fallbackDashboard;
}

export const dashboard: Dashboard = parseDashboard(rawDashboard);

/* ------------------------------------------------------------------ */
/* Helpers                                                             */
/* ------------------------------------------------------------------ */

/** True when a value should render the graceful empty state. */
export function isEmpty(value: unknown): boolean {
  if (value === null || value === undefined) return true;
  if (typeof value === "string") return value.trim().length === 0;
  if (Array.isArray(value)) return value.length === 0;
  if (typeof value === "object") return Object.values(value as object).every(isEmpty);
  return false;
}

export function isIntegrationActive(config: IntegrationConfig): boolean {
  return config.enabled && !isEmpty(config.username);
}
