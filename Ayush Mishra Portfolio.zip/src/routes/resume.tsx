import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, Download, Github, Linkedin, Mail, MapPin, Phone } from "lucide-react";
import { profile } from "@/data/portfolio";
import { site } from "@/data/site";
import { education } from "@/data/education";
import { experience } from "@/data/experience";
import { projects } from "@/data/projects";
import { certifications } from "@/data/certifications";
import { skillGroups } from "@/data/skills";

const title = "Resume | Ayush Mishra";
const description =
  "Resume of Ayush Mishra — B.Tech Computer Science student at Lovely Professional University. Education, experience, projects, skills and certifications.";

export const Route = createFileRoute("/resume")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "profile" },
      { property: "og:url", content: "https://ayush-codes-portfolio.lovable.app/resume" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: title },
      { name: "twitter:description", content: description },
    ],
    links: [{ rel: "canonical", href: "https://ayush-codes-portfolio.lovable.app/resume" }],
  }),
  component: ResumePage,
});

function Block({ heading, children }: { heading: string; children: React.ReactNode }) {
  return (
    <section className="grid gap-4 border-t border-border/60 pt-8">
      <h2 className="font-mono text-xs uppercase tracking-[0.22em] text-accent">{heading}</h2>
      <div className="grid gap-5">{children}</div>
    </section>
  );
}

function ResumePage() {
  return (
    <main id="main" tabIndex={-1} className="mx-auto w-full max-w-3xl px-5 py-12 sm:px-8 sm:py-16">
      <div className="mb-10 flex flex-wrap items-center justify-between gap-3 print:hidden">
        <Link
          to="/"
          className="inline-flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        >
          <ArrowLeft className="size-4" aria-hidden="true" />
          Back to portfolio
        </Link>
        <a
          href={profile.resumeUrl}
          download
          className="accent-glow inline-flex items-center gap-2 rounded-full bg-accent px-5 py-2.5 text-sm font-medium text-accent-foreground transition-transform hover:-translate-y-0.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        >
          <Download className="size-4" aria-hidden="true" />
          Download PDF
        </a>
      </div>

      <header className="grid gap-3 pb-8">
        <h1 className="font-display text-3xl font-semibold tracking-tight text-foreground sm:text-4xl">
          {profile.name}
        </h1>
        <p className="text-muted-foreground">{profile.headline}</p>
        <ul className="grid gap-1.5 font-mono text-sm text-muted-foreground sm:grid-cols-2">
          <li className="flex items-center gap-2">
            <Mail className="size-4 text-accent" aria-hidden="true" />
            <a href={`mailto:${profile.email}`} className="hover:text-foreground">
              {profile.email}
            </a>
          </li>
          <li className="flex items-center gap-2">
            <Phone className="size-4 text-accent" aria-hidden="true" />
            <a href={`tel:${profile.phone}`} className="hover:text-foreground">
              {profile.phone}
            </a>
          </li>
          <li className="flex items-center gap-2">
            <MapPin className="size-4 text-accent" aria-hidden="true" />
            {profile.location}
          </li>
          <li className="flex items-center gap-2">
            <Linkedin className="size-4 text-accent" aria-hidden="true" />
            <a href={site.links.linkedin} target="_blank" rel="noreferrer" className="hover:text-foreground">
              LinkedIn
            </a>
          </li>
          <li className="flex items-center gap-2">
            <Github className="size-4 text-accent" aria-hidden="true" />
            <a href={site.links.github} target="_blank" rel="noreferrer" className="hover:text-foreground">
              GitHub
            </a>
          </li>
        </ul>
      </header>

      <div className="grid gap-8">
        <Block heading="Education">
          {education.map((item) => (
            <div key={item.institution} className="grid gap-1">
              <div className="flex flex-wrap items-baseline justify-between gap-2">
                <h3 className="font-medium text-foreground">{item.institution}</h3>
                <span className="font-mono text-xs text-muted-foreground">{item.period}</span>
              </div>
              <p className="text-sm text-muted-foreground">{item.detail}</p>
            </div>
          ))}
        </Block>

        <Block heading="Experience & Leadership">
          {experience.map((item) => (
            <div key={item.id} className="grid gap-1.5">
              <div className="flex flex-wrap items-baseline justify-between gap-2">
                <h3 className="font-medium text-foreground">
                  {item.role} · {item.organization}
                </h3>
                <span className="font-mono text-xs text-muted-foreground">{item.period}</span>
              </div>
              {item.organizationType ? (
                <p className="text-xs text-muted-foreground">{item.organizationType}</p>
              ) : null}
              {item.description ? (
                <p className="text-sm leading-relaxed text-muted-foreground">{item.description}</p>
              ) : null}
              {item.responsibilities.length > 0 ? (
                <ul className="ml-4 list-disc text-sm text-muted-foreground">
                  {item.responsibilities.map((r) => (
                    <li key={r}>{r}</li>
                  ))}
                </ul>
              ) : null}
              {item.focus && item.focus.length > 0 ? (
                <p className="text-sm text-muted-foreground">Focus: {item.focus.join(" · ")}</p>
              ) : null}
            </div>
          ))}
        </Block>

        <Block heading="Projects">
          {projects.map((project) => (
            <div key={project.slug} className="grid gap-1.5">
              <div className="flex flex-wrap items-baseline justify-between gap-2">
                <h3 className="font-medium text-foreground">{project.title}</h3>
                <span className="font-mono text-xs text-muted-foreground">
                  {project.status} · {project.year}
                </span>
              </div>
              <p className="text-sm leading-relaxed text-muted-foreground">
                {project.fullDescription ?? project.shortDescription}
              </p>
              <p className="font-mono text-xs text-muted-foreground">
                {project.technologies.join(" · ")}
              </p>
              {project.githubUrl ? (
                <a
                  href={project.githubUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="text-sm text-accent underline-offset-4 hover:underline"
                >
                  Repository
                </a>
              ) : null}
            </div>
          ))}
        </Block>

        <Block heading="Skills">
          {skillGroups.map((group) => (
            <div key={group.category} className="grid gap-1">
              <h3 className="font-medium text-foreground">{group.category}</h3>
              <p className="text-sm text-muted-foreground">{group.items.join(" · ")}</p>
            </div>
          ))}
        </Block>

        <Block heading="Certifications">
          <ul className="grid gap-1.5 text-sm text-muted-foreground">
            {certifications.map((cert) => (
              <li key={cert.name}>
                {cert.name}
                {cert.issuer ? ` — ${cert.issuer}` : ""}
                {cert.date ? ` (${cert.date})` : ""}
              </li>
            ))}
          </ul>
        </Block>
      </div>
    </main>
  );
}
