import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, Check, Copy, ExternalLink, MapPin } from "lucide-react";
import { profile } from "@/data/portfolio";
import { site } from "@/data/site";
import { education } from "@/data/education";
import { experience } from "@/data/experience";
import { certifications } from "@/data/certifications";
import { skillGroups } from "@/data/skills";

const title = "LinkedIn Profile | Ayush Mishra";
const description =
  "Ayush Mishra's LinkedIn profile view built from the portfolio data — headline, about, experience, education, certifications and skills, with copy-ready text blocks.";
const url = "https://ayush-codes-portfolio.lovable.app/linkedin";

export const Route = createFileRoute("/linkedin")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "profile" },
      { property: "og:url", content: url },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: title },
      { name: "twitter:description", content: description },
    ],
    links: [{ rel: "canonical", href: url }],
  }),
  component: LinkedInPage,
});

function CopyButton({ value, label }: { value: string; label: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <button
      type="button"
      onClick={async () => {
        try {
          await navigator.clipboard.writeText(value);
          setCopied(true);
          window.setTimeout(() => setCopied(false), 2000);
        } catch {
          /* clipboard unavailable — text is still visible on screen */
        }
      }}
      aria-label={`Copy ${label}`}
      className="inline-flex items-center gap-2 rounded-full border border-border px-3.5 py-1.5 font-mono text-[10px] uppercase tracking-[0.16em] text-muted-foreground transition-colors hover:border-accent/40 hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
    >
      {copied ? <Check className="size-3.5" aria-hidden="true" /> : <Copy className="size-3.5" aria-hidden="true" />}
      {copied ? "Copied" : "Copy"}
    </button>
  );
}

function Card({
  heading,
  copyValue,
  children,
}: {
  heading: string;
  copyValue?: string;
  children: React.ReactNode;
}) {
  return (
    <section className="rounded-2xl border border-border bg-surface/60 p-5 sm:p-6">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <h2 className="font-mono text-xs uppercase tracking-[0.22em] text-accent">{heading}</h2>
        {copyValue ? <CopyButton value={copyValue} label={heading} /> : null}
      </div>
      <div className="grid gap-4">{children}</div>
    </section>
  );
}

function LinkedInPage() {
  const aboutText = [profile.aboutStatement, ...profile.aboutParagraphs].join("\n\n");
  const skillsText = skillGroups.flatMap((g) => g.items).join(", ");
  const educationText = education
    .map((e) => `${e.institution} — ${e.detail} (${e.period})`)
    .join("\n");
  const certificationsText = certifications
    .map((c) => [c.name, c.issuer, c.date].filter(Boolean).join(" — "))
    .join("\n");

  return (
    <main id="main" tabIndex={-1} className="mx-auto w-full max-w-3xl px-5 py-12 sm:px-8 sm:py-16">
      <Link
        to="/"
        className="inline-flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
      >
        <ArrowLeft className="size-4" aria-hidden="true" />
        Back to portfolio
      </Link>

      <header className="mt-8 grid gap-3 rounded-2xl border border-border bg-surface/60 p-6">
        <p className="font-mono text-[11px] uppercase tracking-[0.22em] text-accent">
          LinkedIn Profile
        </p>
        <h1 className="font-display text-3xl font-semibold tracking-tight text-foreground sm:text-4xl">
          {profile.name}
        </h1>
        <p className="text-muted-foreground">{profile.headline}</p>
        <p className="inline-flex items-center gap-2 text-sm text-muted-foreground">
          <MapPin className="size-4 text-accent" aria-hidden="true" />
          {profile.location}
        </p>
        <div className="mt-2 flex flex-wrap items-center gap-3">
          <a
            href={site.links.linkedin}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-2 rounded-full bg-accent px-5 py-2.5 text-sm font-medium text-accent-foreground transition-transform hover:-translate-y-0.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          >
            Open on LinkedIn
            <ExternalLink className="size-4" aria-hidden="true" />
          </a>
          <CopyButton value={profile.headline} label="headline" />
        </div>
        <p className="mt-2 text-xs text-muted-foreground">
          Every block below is generated from the same portfolio data, so the two profiles stay
          consistent. Use the copy buttons to paste the exact text into LinkedIn.
        </p>
      </header>

      <div className="mt-6 grid gap-5">
        <Card heading="About" copyValue={aboutText}>
          <p className="text-sm font-medium text-foreground">{profile.aboutStatement}</p>
          {profile.aboutParagraphs.map((para) => (
            <p key={para} className="text-sm leading-relaxed text-muted-foreground">
              {para}
            </p>
          ))}
        </Card>

        <Card heading="Experience">
          {experience.map((item) => {
            const copyValue = [
              `${item.role} · ${item.organization}`,
              item.period,
              item.description,
              ...item.responsibilities.map((r) => `• ${r}`),
            ]
              .filter(Boolean)
              .join("\n");
            return (
              <div key={item.id} className="grid gap-1.5 border-t border-border/60 pt-4 first:border-0 first:pt-0">
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <h3 className="font-medium text-foreground">
                    {item.role} · {item.organization}
                  </h3>
                  <CopyButton value={copyValue} label={`${item.role} at ${item.organization}`} />
                </div>
                <p className="font-mono text-[11px] uppercase tracking-[0.16em] text-muted-foreground">
                  {item.period}
                  {item.organizationType ? ` · ${item.organizationType}` : ""}
                </p>
                {item.description ? (
                  <p className="text-sm leading-relaxed text-muted-foreground">{item.description}</p>
                ) : null}
                {item.responsibilities.length > 0 ? (
                  <ul className="ml-5 list-disc text-sm text-muted-foreground">
                    {item.responsibilities.map((r) => (
                      <li key={r}>{r}</li>
                    ))}
                  </ul>
                ) : null}
              </div>
            );
          })}
        </Card>

        <Card heading="Education" copyValue={educationText}>
          {education.map((item) => (
            <div key={item.institution} className="grid gap-1">
              <h3 className="font-medium text-foreground">{item.institution}</h3>
              <p className="text-sm text-muted-foreground">{item.detail}</p>
              <p className="font-mono text-[11px] uppercase tracking-[0.16em] text-muted-foreground">
                {item.period}
              </p>
            </div>
          ))}
        </Card>

        <Card heading="Certifications" copyValue={certificationsText}>
          <ul className="grid gap-1.5 text-sm text-muted-foreground">
            {certifications.map((cert) => (
              <li key={cert.name}>
                {cert.name}
                {cert.issuer ? ` — ${cert.issuer}` : ""}
                {cert.date ? ` (${cert.date})` : ""}
              </li>
            ))}
          </ul>
        </Card>

        <Card heading="Skills" copyValue={skillsText}>
          {skillGroups.map((group) => (
            <div key={group.category} className="grid gap-1.5">
              <h3 className="font-medium text-foreground">{group.category}</h3>
              <p className="flex flex-wrap gap-2">
                {group.items.map((item) => (
                  <span
                    key={item}
                    className="rounded-full border border-border px-3 py-1 text-xs text-muted-foreground"
                  >
                    {item}
                  </span>
                ))}
              </p>
            </div>
          ))}
        </Card>
      </div>
    </main>
  );
}
