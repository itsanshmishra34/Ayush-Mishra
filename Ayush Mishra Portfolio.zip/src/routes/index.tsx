import { createFileRoute } from "@tanstack/react-router";
import { Toaster } from "@/components/ui/sonner";
import { Navbar } from "@/components/portfolio/Navbar";
import { Hero } from "@/components/portfolio/Hero";
import { About } from "@/components/portfolio/About";
import { Skills } from "@/components/portfolio/Skills";
import { Dashboard } from "@/components/portfolio/Dashboard";
import { Projects } from "@/components/portfolio/Projects";
import { Coding } from "@/components/portfolio/Coding";
import { TechnologyExplorer } from "@/components/portfolio/TechnologyExplorer";
import { Experience } from "@/components/portfolio/Experience";
import { Education } from "@/components/portfolio/Education";
import { Certifications } from "@/components/portfolio/Certifications";
import { Focus } from "@/components/portfolio/Focus";
import { Contact } from "@/components/portfolio/Contact";
import { Footer } from "@/components/portfolio/Footer";
import { EasterEgg } from "@/components/portfolio/EasterEgg";
import { CommandPalette } from "@/components/portfolio/CommandPalette";
import { BuildLog } from "@/components/portfolio/BuildLog";
import { Strengths } from "@/components/portfolio/Strengths";
import { ValueProposition } from "@/components/portfolio/ValueProposition";
import { CareerDirection } from "@/components/portfolio/CareerDirection";
import { HowIBuild } from "@/components/portfolio/HowIBuild";
import { profile } from "@/data/portfolio";

const description =
  "Portfolio of Ayush Mishra, B.Tech Computer Science student at Lovely Professional University, focused on C++, Python, SQL, DSA, software development, and AI/ML.";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Ayush Mishra | Aspiring Software Engineer" },
      { name: "description", content: description },
      { property: "og:title", content: "Ayush Mishra | Aspiring Software Engineer" },
      { property: "og:description", content: description },
      { property: "og:type", content: "profile" },
      { property: "og:url", content: "https://ayush-codes-portfolio.lovable.app/" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: "Ayush Mishra | Aspiring Software Engineer" },
      { name: "twitter:description", content: description },
    ],
    links: [{ rel: "canonical", href: "https://ayush-codes-portfolio.lovable.app/" }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Person",
          name: profile.name,
          jobTitle: "Aspiring Software Engineer",
          email: `mailto:${profile.email}`,
          telephone: profile.phone,
          url: profile.linkedin,
          address: {
            "@type": "PostalAddress",
            addressLocality: "Sultanpur",
            addressRegion: "Uttar Pradesh",
            addressCountry: "IN",
          },
          alumniOf: {
            "@type": "CollegeOrUniversity",
            name: "Lovely Professional University",
          },
          knowsAbout: ["C++", "Python", "SQL", "Data Structures & Algorithms", "AI/ML", "OpenCV"],
        }),
      },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main id="main" tabIndex={-1}>
        <Hero />
        <About />
        <Skills />
        <Dashboard />
        <Projects />
        <TechnologyExplorer />
        <Coding />
        <ValueProposition />
        <HowIBuild />
        <Experience />
        <Education />
        <Certifications />
        <BuildLog />
        <Strengths />
        <Focus />
        <CareerDirection />
        <Contact />
      </main>
      <Footer />
      <EasterEgg />
      <CommandPalette />
      <Toaster />
    </div>
  );
}
