import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { ArrowLeft, ArrowUpRight, CircleDot, GitFork, Star } from "lucide-react";
import {
  GITHUB_PROFILE_URL,
  GITHUB_USERNAME,
  fetchGithubProfile,
  fetchRepoIssues,
  fetchRepoReadme,
} from "@/lib/github";
import { Markdown } from "@/components/portfolio/Markdown";
import { cn } from "@/lib/utils";

const title = "GitHub Repositories | Ayush Mishra";
const description =
  "Live view of Ayush Mishra's public GitHub repositories, including each repository's README and open issues.";
const url = "https://ayush-codes-portfolio.lovable.app/github";

export const Route = createFileRoute("/github")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { property: "og:url", content: url },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: title },
      { name: "twitter:description", content: description },
    ],
    links: [{ rel: "canonical", href: url }],
  }),
  component: GithubPage,
});

function formatDate(iso: string): string {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return "";
  return date.toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}

function RepoDetail({ repo }: { repo: string }) {
  const readmeFn = useServerFn(fetchRepoReadme);
  const issuesFn = useServerFn(fetchRepoIssues);
  const [tab, setTab] = useState<"readme" | "issues">("readme");

  const readme = useQuery({
    queryKey: ["gh-readme", GITHUB_USERNAME, repo],
    queryFn: () => readmeFn({ data: { owner: GITHUB_USERNAME, repo } }),
    staleTime: 1000 * 60 * 10,
    retry: false,
  });
  const issues = useQuery({
    queryKey: ["gh-issues", GITHUB_USERNAME, repo],
    queryFn: () => issuesFn({ data: { owner: GITHUB_USERNAME, repo } }),
    staleTime: 1000 * 60 * 10,
    retry: false,
  });

  const tabClass = (active: boolean) =>
    cn(
      "rounded-full px-4 py-1.5 font-mono text-[11px] uppercase tracking-[0.18em] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
      active
        ? "bg-accent/15 text-accent border border-accent/40"
        : "border border-border text-muted-foreground hover:text-foreground",
    );

  return (
    <div className="mt-5 grid gap-5 border-t border-border/60 pt-5">
      <div className="flex flex-wrap gap-2" role="tablist" aria-label={`${repo} views`}>
        <button
          type="button"
          role="tab"
          aria-selected={tab === "readme"}
          className={tabClass(tab === "readme")}
          onClick={() => setTab("readme")}
        >
          README
        </button>
        <button
          type="button"
          role="tab"
          aria-selected={tab === "issues"}
          className={tabClass(tab === "issues")}
          onClick={() => setTab("issues")}
        >
          Open Issues
        </button>
      </div>

      {tab === "readme" ? (
        readme.isLoading ? (
          <p className="text-sm text-muted-foreground">Loading README…</p>
        ) : readme.data?.error ? (
          <p className="text-sm text-muted-foreground">{readme.data.error}</p>
        ) : readme.data?.markdown ? (
          <Markdown source={readme.data.markdown} />
        ) : (
          <p className="text-sm text-muted-foreground">This repository has no README.</p>
        )
      ) : issues.isLoading ? (
        <p className="text-sm text-muted-foreground">Loading issues…</p>
      ) : issues.data?.error ? (
        <p className="text-sm text-muted-foreground">{issues.data.error}</p>
      ) : issues.data && issues.data.issues.length > 0 ? (
        <ul className="grid gap-3">
          {issues.data.issues.map((issue) => (
            <li
              key={issue.id}
              className="rounded-xl border border-border bg-surface/60 p-4 text-sm"
            >
              <a
                href={issue.url}
                target="_blank"
                rel="noreferrer"
                className="font-medium text-foreground underline-offset-4 hover:text-accent hover:underline"
              >
                #{issue.number} {issue.title}
              </a>
              <p className="mt-1 font-mono text-[11px] uppercase tracking-[0.16em] text-muted-foreground">
                {issue.isPullRequest ? "Pull request" : "Issue"} · {issue.state} ·{" "}
                {formatDate(issue.createdAt)} · {issue.comments} comments
              </p>
              {issue.labels.length > 0 ? (
                <p className="mt-2 flex flex-wrap gap-2">
                  {issue.labels.map((label) => (
                    <span
                      key={label}
                      className="rounded-full border border-border px-2.5 py-0.5 font-mono text-[10px] uppercase tracking-[0.14em] text-muted-foreground"
                    >
                      {label}
                    </span>
                  ))}
                </p>
              ) : null}
            </li>
          ))}
        </ul>
      ) : (
        <p className="text-sm text-muted-foreground">No open issues.</p>
      )}
    </div>
  );
}

function GithubPage() {
  const fn = useServerFn(fetchGithubProfile);
  const [open, setOpen] = useState<string | null>(null);

  const { data, isLoading } = useQuery({
    queryKey: ["github-repos-all", GITHUB_USERNAME],
    queryFn: () => fn({ data: { username: GITHUB_USERNAME, includeAll: true } }),
    staleTime: 1000 * 60 * 30,
    retry: false,
  });

  return (
    <main id="main" tabIndex={-1} className="mx-auto w-full max-w-4xl px-5 py-12 sm:px-8 sm:py-16">
      <Link
        to="/"
        className="inline-flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
      >
        <ArrowLeft className="size-4" aria-hidden="true" />
        Back to portfolio
      </Link>

      <header className="mt-8 grid gap-3 pb-8">
        <p className="font-mono text-[11px] uppercase tracking-[0.22em] text-accent">GitHub</p>
        <h1 className="font-display text-3xl font-semibold tracking-tight text-foreground sm:text-4xl">
          Repositories
        </h1>
        <p className="max-w-2xl text-muted-foreground">
          Public repositories fetched live from GitHub. Open any repository to read its README and
          browse its open issues.
        </p>
        <a
          href={GITHUB_PROFILE_URL}
          target="_blank"
          rel="noreferrer"
          className="inline-flex w-fit items-center gap-2 rounded-full border border-accent/40 bg-accent/10 px-4 py-2 font-mono text-[11px] uppercase tracking-[0.18em] text-accent transition-colors hover:border-accent"
        >
          @{GITHUB_USERNAME}
          <ArrowUpRight className="size-3.5" aria-hidden="true" />
        </a>
      </header>

      {isLoading ? (
        <p className="text-sm text-muted-foreground">Loading repositories…</p>
      ) : data?.error ? (
        <p className="text-sm text-muted-foreground">
          {data.error}. Repository data could not be loaded right now — view the profile on GitHub
          instead.
        </p>
      ) : data && data.repos.length > 0 ? (
        <ul className="grid gap-4">
          {data.repos.map((repo) => {
            const expanded = open === repo.name;
            return (
              <li
                key={repo.id}
                className="rounded-2xl border border-border bg-surface/60 p-5 sm:p-6"
              >
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="grid gap-1.5">
                    <h2 className="font-display text-lg font-semibold text-foreground">
                      {repo.name}
                    </h2>
                    {repo.description ? (
                      <p className="max-w-xl text-sm text-muted-foreground">{repo.description}</p>
                    ) : null}
                    <p className="flex flex-wrap items-center gap-4 font-mono text-[11px] uppercase tracking-[0.16em] text-muted-foreground">
                      {repo.language ? <span>{repo.language}</span> : null}
                      <span className="inline-flex items-center gap-1">
                        <Star className="size-3.5" aria-hidden="true" /> {repo.stars}
                      </span>
                      <span className="inline-flex items-center gap-1">
                        <GitFork className="size-3.5" aria-hidden="true" /> {repo.forks}
                      </span>
                      {repo.updatedAt ? <span>Updated {formatDate(repo.updatedAt)}</span> : null}
                    </p>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <button
                      type="button"
                      onClick={() => setOpen(expanded ? null : repo.name)}
                      aria-expanded={expanded}
                      className="inline-flex items-center gap-2 rounded-full border border-border px-4 py-2 text-sm text-foreground transition-colors hover:border-accent/40 hover:bg-secondary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                    >
                      <CircleDot className="size-4" aria-hidden="true" />
                      {expanded ? "Hide" : "README & Issues"}
                    </button>
                    <a
                      href={repo.url}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex items-center gap-2 rounded-full bg-accent px-4 py-2 text-sm font-medium text-accent-foreground transition-transform hover:-translate-y-0.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                    >
                      Open
                      <ArrowUpRight className="size-4" aria-hidden="true" />
                    </a>
                  </div>
                </div>

                {expanded ? <RepoDetail repo={repo.name} /> : null}
              </li>
            );
          })}
        </ul>
      ) : (
        <p className="text-sm text-muted-foreground">No public repositories found.</p>
      )}
    </main>
  );
}
