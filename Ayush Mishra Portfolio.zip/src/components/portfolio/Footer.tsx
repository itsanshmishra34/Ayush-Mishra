import { BookMarked, Code2, Github, IdCard, Linkedin, Mail } from "lucide-react";
import { Link } from "@tanstack/react-router";


import { profile } from "@/data/portfolio";
import { site } from "@/data/site";
import { SharePortfolio } from "./SharePortfolio";

const links = [
  { label: "GitHub", href: site.links.github, icon: Github },
  { label: "LinkedIn", href: site.links.linkedin, icon: Linkedin },
  { label: "LeetCode", href: site.links.leetcode, icon: Code2 },
  { label: "Email", href: `mailto:${profile.email}`, icon: Mail },
];

export function Footer() {
  return (
    <footer className="border-t border-border/60 py-12">
      <div className="mx-auto flex w-full max-w-6xl flex-col gap-8 px-5 sm:px-8 md:flex-row md:items-end md:justify-between">
        <div>
          <p className="font-display text-lg font-semibold uppercase tracking-tight text-foreground">
            {profile.name}
          </p>
          <p className="mt-1 text-sm text-muted-foreground">Aspiring Software Engineer</p>
          <p className="text-sm text-muted-foreground">B.Tech CSE @ LPU</p>
          <div className="mt-5">
            <SharePortfolio />
          </div>
        </div>

        <div className="flex flex-col gap-4 md:items-end">
          <nav aria-label="Portfolio pages">
            <ul className="flex flex-wrap gap-x-5 gap-y-2 text-sm">
              <li>
                <Link
                  to="/github"
                  className="inline-flex items-center gap-2 text-muted-foreground transition-colors hover:text-accent"
                >
                  <BookMarked className="size-4" aria-hidden="true" />
                  Repositories
                </Link>
              </li>
              <li>
                <Link
                  to="/linkedin"
                  className="inline-flex items-center gap-2 text-muted-foreground transition-colors hover:text-accent"
                >
                  <IdCard className="size-4" aria-hidden="true" />
                  LinkedIn Profile
                </Link>
              </li>
            </ul>
          </nav>
          <nav aria-label="Social">
            <ul className="flex flex-wrap gap-x-5 gap-y-2 text-sm">

              {links.map(({ label, href, icon: Icon }) => (
                <li key={label}>
                  <a
                    href={href}
                    {...(href.startsWith("http") ? { target: "_blank", rel: "noreferrer" } : {})}
                    className="inline-flex items-center gap-2 text-muted-foreground transition-colors hover:text-accent"
                  >
                    <Icon className="size-4" aria-hidden="true" />
                    {label}
                  </a>
                </li>
              ))}
            </ul>
          </nav>

          <p className="font-mono text-[0.65rem] uppercase tracking-[0.22em] text-muted-foreground">
            Last updated · {site.lastUpdated}
          </p>
          <p className="text-xs text-muted-foreground">© 2026 Ayush Mishra</p>
        </div>
      </div>
    </footer>
  );
}
