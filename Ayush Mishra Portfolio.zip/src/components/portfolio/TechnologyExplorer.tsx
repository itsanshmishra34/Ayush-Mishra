import { useMemo, useState } from "react";
import { RotateCcw, FolderGit2, Layers, Boxes, Briefcase } from "lucide-react";
import {
  exploreTechnology,
  explorerTechnologies,
  type ExplorerTechnology,
} from "@/lib/technology-explorer";
import { Section } from "./Section";
import { Reveal } from "./Reveal";

/**
 * Technology Explorer — interactive, data-driven lookup across the
 * portfolio's canonical data sources. Selecting a chip derives projects,
 * categories, related skills, and experience from src/data/{skills,projects,experience}.ts.
 */
export function TechnologyExplorer() {
  const [selected, setSelected] = useState<ExplorerTechnology | null>(null);

  const result = useMemo(
    () => (selected ? exploreTechnology(selected) : null),
    [selected],
  );

  return (
    <Section
      id="explorer"
      eyebrow="Explorer"
      title="Technology Explorer"
      subtitle="Pick a technology to see where it shows up across my projects, skills, and experience — derived live from the portfolio data."
    >
      {/* Selector — horizontally scrollable on mobile */}
      <Reveal>
        <div
          role="tablist"
          aria-label="Select a technology"
          className="-mx-5 flex gap-2 overflow-x-auto px-5 pb-2 sm:mx-0 sm:flex-wrap sm:overflow-visible sm:px-0"
        >
          {explorerTechnologies.map((tech) => (
            <button
              key={tech}
              type="button"
              role="tab"
              aria-selected={selected === tech}
              onClick={() => setSelected(selected === tech ? null : tech)}
              className={`shrink-0 rounded-full border px-4 py-2 font-mono text-xs uppercase tracking-[0.16em] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring ${
                selected === tech
                  ? "border-accent/50 bg-accent/10 text-accent"
                  : "border-border text-muted-foreground hover:border-accent/30 hover:text-foreground"
              }`}
            >
              {tech}
            </button>
          ))}
          {selected ? (
            <button
              type="button"
              onClick={() => setSelected(null)}
              className="inline-flex shrink-0 items-center gap-1.5 rounded-full border border-dashed border-border px-4 py-2 font-mono text-xs uppercase tracking-[0.16em] text-muted-foreground transition-colors hover:border-accent/30 hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            >
              <RotateCcw className="size-3.5" aria-hidden="true" />
              Reset
            </button>
          ) : null}
        </div>
      </Reveal>

      {/* Results */}
      {result ? (
        <div key={result.technology} className="mt-10 animate-rise">
          <p className="font-mono text-xs uppercase tracking-[0.22em] text-muted-foreground">
            <span className="text-accent">{result.technology}</span>
            {" — "}
            {result.projects.length} project{result.projects.length === 1 ? "" : "s"}
          </p>

          <div className="mt-6 grid gap-6 lg:grid-cols-2">
            {/* Projects using it */}
            <ResultPanel icon={FolderGit2} title="Projects using it">
              {result.projects.length > 0 ? (
                <ul className="space-y-4">
                  {result.projects.map((project) => (
                    <li
                      key={project.slug}
                      className="rounded-xl border border-border bg-background/40 p-4"
                    >
                      <div className="flex items-center justify-between gap-3">
                        <p className="font-medium text-foreground">{project.title}</p>
                        <span className="shrink-0 font-mono text-[10px] uppercase tracking-[0.16em] text-muted-foreground">
                          {project.category}
                        </span>
                      </div>
                      <p className="mt-1.5 text-sm text-muted-foreground">
                        {project.shortDescription}
                      </p>
                      <div className="mt-3 flex flex-wrap gap-1.5">
                        {project.technologies.map((t) => (
                          <span
                            key={t}
                            className={`rounded-full border px-2.5 py-1 font-mono text-[10px] uppercase tracking-[0.12em] ${
                              t.toLowerCase() === result.technology.toLowerCase()
                                ? "border-accent/50 bg-accent/10 text-accent"
                                : "border-border text-muted-foreground"
                            }`}
                          >
                            {t}
                          </span>
                        ))}
                      </div>
                    </li>
                  ))}
                </ul>
              ) : (
                <EmptyState label="No projects are linked to this technology yet." />
              )}
            </ResultPanel>

            <div className="grid content-start gap-6">
              {/* Related skills */}
              <ResultPanel icon={Layers} title="Related skills">
                {result.relatedSkills.length > 0 ? (
                  <ul className="flex flex-wrap gap-2">
                    {result.relatedSkills.map(({ group, item }) => (
                      <li
                        key={`${group}-${item}`}
                        className="rounded-full border border-border px-3 py-1.5 text-xs text-foreground"
                      >
                        {item}
                        <span className="ml-2 font-mono text-[10px] uppercase tracking-[0.12em] text-muted-foreground">
                          {group}
                        </span>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <EmptyState label="Not listed as a standalone skill." />
                )}
              </ResultPanel>

              {/* Project categories */}
              <ResultPanel icon={Boxes} title="Project categories">
                {result.categories.length > 0 ? (
                  <ul className="flex flex-wrap gap-2">
                    {result.categories.map((category) => (
                      <li
                        key={category}
                        className="rounded-full border border-accent/30 bg-accent/5 px-3 py-1.5 font-mono text-[11px] uppercase tracking-[0.14em] text-accent"
                      >
                        {category}
                      </li>
                    ))}
                  </ul>
                ) : (
                  <EmptyState label="No project categories linked yet." />
                )}
              </ResultPanel>

              {/* Relevant experience */}
              <ResultPanel icon={Briefcase} title="Relevant experience">
                {result.experience.length > 0 ? (
                  <ul className="space-y-3">
                    {result.experience.map((item) => (
                      <li key={`${item.company}-${item.role}`}>
                        <p className="text-sm font-medium text-foreground">{item.role}</p>
                        <p className="text-xs text-muted-foreground">
                          {item.company} • {item.period}
                        </p>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <EmptyState label="No roles are linked to this technology yet." />
                )}
              </ResultPanel>
            </div>
          </div>
        </div>
      ) : (
        <p className="mt-10 rounded-2xl border border-dashed border-border p-8 text-center text-sm text-muted-foreground">
          Select a technology above to explore how it connects across the portfolio.
        </p>
      )}
    </Section>
  );
}

function ResultPanel({
  icon: Icon,
  title,
  children,
}: {
  icon: typeof FolderGit2;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <section className="rounded-2xl border border-border bg-card/40 p-5 sm:p-6">
      <header className="mb-4 flex items-center gap-2.5">
        <Icon className="size-4 text-accent" aria-hidden="true" />
        <h3 className="font-mono text-xs uppercase tracking-[0.22em] text-muted-foreground">
          {title}
        </h3>
      </header>
      {children}
    </section>
  );
}

function EmptyState({ label }: { label: string }) {
  return <p className="text-sm italic text-muted-foreground/70">{label}</p>;
}
