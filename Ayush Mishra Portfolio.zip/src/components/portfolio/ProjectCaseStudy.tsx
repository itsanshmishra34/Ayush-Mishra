import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { ArrowLeft, ExternalLink, Github, Printer, X } from "lucide-react";
import type { Project } from "@/data/projects";
import { ProjectVisual } from "./ProjectVisual";
import { ProjectArchitecture } from "./ProjectArchitecture";
import { StatusBadge } from "./StatusBadge";
import { cn } from "@/lib/utils";

type Props = {
  project: Project | null;
  open: boolean;
  onClose: () => void;
};

type SectionDef = { id: string; num: string; label: string };

/** Keeps the URL hash in sync so each case-study section is shareable. */
function syncHash(slug: string, sectionId: string) {
  const next = `#case/${slug}/${sectionId}`;
  if (window.location.hash !== next) window.history.replaceState(null, "", next);
}

/**
 * Full-screen, data-driven engineering case study.
 * All content comes from `project.caseStudy` / `project.architecture`
 * in src/data/projects.ts — nothing is hardcoded here.
 */
export function ProjectCaseStudy({ project, open, onClose }: Props) {
  const scrollRef = useRef<HTMLDivElement | null>(null);
  const dialogRef = useRef<HTMLDivElement | null>(null);
  const closeRef = useRef<HTMLButtonElement | null>(null);
  const [progress, setProgress] = useState(0);
  const [activeSection, setActiveSection] = useState<string>("overview");
  const [activeTech, setActiveTech] = useState<string | null>(null);

  const cs = project?.caseStudy ?? null;

  const sections = useMemo<SectionDef[]>(() => {
    if (!cs) return [];
    const list: Array<Omit<SectionDef, "num">> = [
      { id: "overview", label: "Overview" },
      { id: "problem", label: "The Problem" },
      { id: "approach", label: "The Approach" },
      { id: "stack", label: "Tech Stack" },
    ];
    if (project?.architecture && project.architecture.steps.length > 0) {
      list.push({ id: "architecture", label: "Architecture" });
    }
    if (cs.engineeringDecisions && cs.engineeringDecisions.length > 0) {
      list.push({ id: "decisions", label: "Engineering Decisions" });
    }
    list.push({ id: "learnings", label: "What I Learned" });
    list.push({ id: "status", label: "Status" });
    list.push({ id: "links", label: "Links" });
    return list.map((s, i) => ({ ...s, num: String(i + 1).padStart(2, "0") }));
  }, [cs, project]);

  const numOf = (id: string) => sections.find((s) => s.id === id)?.num ?? "";

  useEffect(() => {
    if (!open) return;
    setProgress(0);
    setActiveTech(null);
    setActiveSection(sections[0]?.id ?? "overview");
    const previous = document.activeElement as HTMLElement | null;
    const overflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const t = window.setTimeout(() => closeRef.current?.focus(), 30);

    // Auto-scroll to the hash section. Content mounts asynchronously, so retry
    // across a few frames until the target node exists.
    let frames = 0;
    let raf = 0;
    const scrollToHash = () => {
      const match = /^#case\/[^/]+\/(.+)$/.exec(window.location.hash);
      const target = match?.[1];
      if (!target) return;
      const el = scrollRef.current;
      const node = el?.querySelector<HTMLElement>(`#case-${target}`);
      if (el && node) {
        el.scrollTop = node.offsetTop - 16;
        setActiveSection(target);
        return;
      }
      if (frames++ < 30) raf = window.requestAnimationFrame(scrollToHash);
    };
    scrollToHash();
    const onHashChange = () => {
      frames = 0;
      scrollToHash();
    };
    window.addEventListener("hashchange", onHashChange);
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        e.stopPropagation();
        onClose();
        return;
      }
      if (e.key !== "Tab") return;
      // Focus trap: keep Tab / Shift+Tab inside the case-study dialog.
      const root = dialogRef.current;
      if (!root) return;
      const focusables = Array.from(
        root.querySelectorAll<HTMLElement>(
          'a[href], button:not([disabled]), input, select, textarea, [tabindex]:not([tabindex="-1"])',
        ),
      ).filter((el) => el.offsetParent !== null || el === document.activeElement);
      if (focusables.length === 0) return;
      const first = focusables[0]!;
      const last = focusables[focusables.length - 1]!;
      const current = document.activeElement as HTMLElement | null;
      if (e.shiftKey && (current === first || !root.contains(current))) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && (current === last || !root.contains(current))) {
        e.preventDefault();
        first.focus();
      }
    };
    document.addEventListener("keydown", onKey);
    return () => {
      window.clearTimeout(t);
      window.cancelAnimationFrame(raf);
      window.removeEventListener("hashchange", onHashChange);
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = overflow;
      if (window.location.hash.startsWith("#case/")) {
        window.history.replaceState(null, "", window.location.pathname + window.location.search);
      }
      previous?.focus?.();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  const handleScroll = useCallback(() => {
    const el = scrollRef.current;
    if (!el) return;
    const max = el.scrollHeight - el.clientHeight;
    setProgress(max > 0 ? Math.min(1, el.scrollTop / max) : 1);

    let current = sections[0]?.id ?? "";
    for (const s of sections) {
      const node = el.querySelector<HTMLElement>(`#case-${s.id}`);
      if (node && node.offsetTop - el.scrollTop <= el.clientHeight * 0.35) current = s.id;
    }
    setActiveSection(current);
    if (current && project) syncHash(project.slug, current);
  }, [sections, project]);

  const goTo = (id: string) => {
    const el = scrollRef.current;
    const node = el?.querySelector<HTMLElement>(`#case-${id}`);
    if (!el || !node) return;
    el.scrollTo({ top: node.offsetTop - 16, behavior: "smooth" });
    if (project) syncHash(project.slug, id);
  };

  if (!open || !project || !cs || typeof document === "undefined") return null;

  const hasLinks = Boolean(project.githubUrl || project.liveUrl);

  return createPortal(
    <div
      ref={dialogRef}
      role="dialog"
      aria-modal="true"
      aria-labelledby="case-study-title"
      aria-describedby="case-study-summary"
      data-case-study
      className="fixed inset-0 z-50 bg-background animate-rise"
    >
      <p className="sr-only" id="case-study-summary">
        {`Engineering case study for ${project.title}. Use the section navigation to move between the ${sections.length} sections. Press Escape to return to projects.`}
      </p>
      {/* scroll progress */}
      <div className="absolute inset-x-0 top-0 z-20 h-px bg-border print:hidden">
        <div
          aria-hidden="true"
          className="h-full bg-accent transition-[width] duration-150 ease-out motion-reduce:transition-none"
          style={{ width: `${progress * 100}%` }}
        />
      </div>

      {/* top bar */}
      <header className="print:hidden absolute inset-x-0 top-0 z-10 flex items-center justify-between gap-4 border-b border-border/70 bg-background/85 px-4 py-3 backdrop-blur sm:px-8">
        <button
          type="button"
          onClick={onClose}
          className="inline-flex items-center gap-2 rounded-full border border-border px-4 py-2 text-sm text-foreground transition-colors hover:border-accent/40 hover:bg-secondary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          ref={closeRef}
        >
          <ArrowLeft className="size-4" aria-hidden="true" />
          Back to Projects
        </button>
        <p className="hidden font-mono text-xs uppercase tracking-[0.22em] text-muted-foreground sm:block">
          Case Study
        </p>
        <div className="flex items-center gap-2 print:hidden">
        <button
          type="button"
          onClick={() => window.print()}
          className="inline-flex items-center gap-2 rounded-full border border-border px-3 py-2 text-sm text-foreground transition-colors hover:border-accent/40 hover:bg-secondary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring sm:px-4"
        >
          <Printer className="size-4" aria-hidden="true" />
          <span className="hidden sm:inline">Print / Save as PDF</span>
          <span className="sr-only sm:hidden">Print or save this case study as PDF</span>
        </button>
        <button
          type="button"
          onClick={onClose}
          aria-label="Close case study"
          className="rounded-full border border-border p-2 text-muted-foreground transition-colors hover:border-accent/40 hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        >
          <X className="size-4" aria-hidden="true" />
        </button>
        </div>
      </header>

      <div
        ref={scrollRef}
        onScroll={handleScroll}
        className="h-full overflow-y-auto pt-[62px]"
      >
        <div className="mx-auto grid w-full max-w-6xl gap-10 px-4 pb-24 pt-10 sm:px-8 lg:grid-cols-[200px_minmax(0,1fr)] lg:gap-14">
          {/* section navigation */}
          <nav
            aria-label="Case study sections"
            className="min-w-0 print:hidden lg:sticky lg:top-24 lg:self-start"
          >
            <ul className="flex snap-x gap-2 overflow-x-auto pb-2 lg:flex-col lg:gap-1 lg:overflow-visible lg:pb-0">
              {sections.map((s) => (
                <li key={s.id} className="shrink-0">
                  <button
                    type="button"
                    onClick={() => goTo(s.id)}
                    aria-current={activeSection === s.id ? "true" : undefined}
                    className={cn(
                      "flex w-full items-center gap-2 whitespace-nowrap rounded-full px-3 py-1.5 text-left font-mono text-xs uppercase tracking-[0.16em] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring lg:rounded-none lg:border-l lg:px-3",
                      activeSection === s.id
                        ? "bg-accent/10 text-accent lg:border-accent lg:bg-transparent"
                        : "text-muted-foreground hover:text-foreground lg:border-border",
                    )}
                  >
                    <span className="opacity-60">{s.num}</span>
                    {s.label}
                  </button>
                </li>
              ))}
            </ul>
          </nav>

          <div className="min-w-0">
            {/* hero */}
            <section id="case-overview" className="scroll-mt-24">
              <p className="font-mono text-xs uppercase tracking-[0.22em] text-accent">
                {project.category}
              </p>
              <h1 id="case-study-title" className="mt-3 font-display text-4xl font-semibold tracking-tight text-foreground sm:text-5xl lg:text-6xl">
                {project.title}
              </h1>
              <div className="mt-5 flex flex-wrap items-center gap-3">
                <StatusBadge status={project.status} />
                <span className="font-mono text-xs text-muted-foreground">{project.year}</span>
                <span className="font-mono text-xs text-muted-foreground">
                  {project.technologies.slice(0, 2).join(" + ")}
                </span>
              </div>

              <figure className="mt-8">
                <ProjectVisual project={project} className="aspect-[16/9]" priority />
                <figcaption className="mt-2 font-mono text-[11px] uppercase tracking-[0.16em] text-muted-foreground/70">
                  Conceptual visual — not a product screenshot
                </figcaption>
              </figure>

              <SectionHead num={numOf("overview")} title="Project Overview" />
              <p className="text-lg leading-relaxed text-muted-foreground">{cs.overview}</p>
            </section>

            <section id="case-problem" className="scroll-mt-24">
              <SectionHead num={numOf("problem")} title="The Problem" />
              <p className="text-base leading-relaxed text-muted-foreground">{cs.problem}</p>
            </section>

            <section id="case-approach" className="scroll-mt-24">
              <SectionHead num={numOf("approach")} title="The Approach" />
              {cs.approach.body ? (
                <p className="text-base leading-relaxed text-muted-foreground">
                  {cs.approach.body}
                </p>
              ) : null}
              <ol className="mt-6 grid gap-2">
                {cs.approach.steps.map((step, i) => (
                  <li
                    key={step}
                    className="flex items-center gap-4 rounded-xl border border-border/70 bg-surface/40 px-4 py-3 transition-colors hover:border-accent/40"
                  >
                    <span className="font-mono text-xs text-accent">
                      {String(i + 1).padStart(2, "0")}
                    </span>
                    <span className="text-sm text-foreground">{step}</span>
                  </li>
                ))}
              </ol>
              {cs.approach.note ? (
                <p className="mt-4 font-mono text-[11px] uppercase tracking-[0.14em] text-muted-foreground/70">
                  {cs.approach.note}
                </p>
              ) : null}
            </section>

            <section id="case-stack" className="scroll-mt-24">
              <SectionHead num={numOf("stack")} title="Tech Stack" />
              <div className="grid gap-3 sm:grid-cols-2">
                {cs.technologies.map((tech) => {
                  const isActive = activeTech === tech.name;
                  return (
                    <button
                      key={tech.name}
                      type="button"
                      aria-expanded={isActive}
                      onClick={() => setActiveTech(isActive ? null : tech.name)}
                      className={cn(
                        "rounded-2xl border p-4 text-left transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
                        isActive
                          ? "border-accent/50 bg-accent/5"
                          : "border-border bg-surface/40 hover:border-accent/40",
                      )}
                    >
                      <span className="font-mono text-sm text-foreground">{tech.name}</span>
                      <p
                        className={cn(
                          "overflow-hidden text-sm leading-relaxed text-muted-foreground transition-all duration-300 motion-reduce:transition-none",
                          isActive ? "mt-3 max-h-40 opacity-100" : "max-h-0 opacity-0",
                        )}
                      >
                        {tech.relation}
                      </p>
                      {!isActive ? (
                        <span className="mt-2 block font-mono text-[11px] uppercase tracking-[0.14em] text-muted-foreground/60">
                          Tap to see its role
                        </span>
                      ) : null}
                    </button>
                  );
                })}
              </div>
            </section>

            {project.architecture && project.architecture.steps.length > 0 ? (
              <section id="case-architecture" className="scroll-mt-24">
                <SectionHead num={numOf("architecture")} title="Architecture" />
                <ProjectArchitecture architecture={project.architecture} />
              </section>
            ) : null}

            {cs.engineeringDecisions && cs.engineeringDecisions.length > 0 ? (
              <section id="case-decisions" className="scroll-mt-24">
                <SectionHead num={numOf("decisions")} title="Engineering Decisions" />
                <ul className="grid gap-4">
                  {cs.engineeringDecisions.map((d) => (
                    <li
                      key={d.decision}
                      className="rounded-2xl border border-border bg-surface/40 p-5 sm:p-6"
                    >
                      <p className="font-display text-base font-semibold text-foreground">
                        {d.decision}
                      </p>
                      <dl className="mt-4 grid gap-4 sm:grid-cols-3">
                        {[
                          { label: "Why", value: d.why },
                          { label: "Trade-off", value: d.tradeOff },
                          { label: "Result", value: d.result },
                        ].map((row) => (
                          <div key={row.label}>
                            <dt className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
                              {row.label}
                            </dt>
                            <dd className="mt-1.5 text-sm leading-relaxed text-muted-foreground">
                              {row.value}
                            </dd>
                          </div>
                        ))}
                      </dl>
                    </li>
                  ))}
                </ul>
              </section>
            ) : null}

            <section id="case-learnings" className="scroll-mt-24">
              <SectionHead num={numOf("learnings")} title="What I Learned" />
              <ul className="grid gap-3">
                {cs.learnings.map((item) => (
                  <li
                    key={item}
                    className="flex gap-3 rounded-xl border border-border/60 bg-surface/30 p-4 text-sm leading-relaxed text-muted-foreground"
                  >
                    <span
                      aria-hidden="true"
                      className="mt-2 size-1.5 shrink-0 rounded-full bg-accent"
                    />
                    {item}
                  </li>
                ))}
              </ul>
            </section>

            <section id="case-status" className="scroll-mt-24">
              <SectionHead num={numOf("status")} title="Project Status" />
              <dl className="grid gap-px overflow-hidden rounded-2xl border border-border bg-border sm:grid-cols-3">
                <div className="bg-surface/60 p-5">
                  <dt className="font-mono text-[11px] uppercase tracking-[0.16em] text-muted-foreground">
                    Status
                  </dt>
                  <dd className="mt-2 text-foreground">{project.status}</dd>
                </div>
                <div className="bg-surface/60 p-5">
                  <dt className="font-mono text-[11px] uppercase tracking-[0.16em] text-muted-foreground">
                    Year
                  </dt>
                  <dd className="mt-2 text-foreground">{project.year}</dd>
                </div>
                <div className="bg-surface/60 p-5">
                  <dt className="font-mono text-[11px] uppercase tracking-[0.16em] text-muted-foreground">
                    Technology
                  </dt>
                  <dd className="mt-2 text-foreground">
                    {project.technologies.slice(0, 2).join(" + ")}
                  </dd>
                </div>
              </dl>
            </section>

            <section id="case-links" className="scroll-mt-24">
              <SectionHead num={numOf("links")} title="Project Links" />
              {hasLinks ? (
                <div className="flex flex-wrap gap-3">
                  {project.githubUrl ? (
                    <a
                      href={project.githubUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex items-center gap-2 rounded-full border border-border px-5 py-2.5 text-sm text-foreground transition-colors hover:border-accent/40 hover:bg-secondary"
                    >
                      <Github className="size-4" aria-hidden="true" />
                      GitHub
                    </a>
                  ) : null}
                  {project.liveUrl ? (
                    <a
                      href={project.liveUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex items-center gap-2 rounded-full border border-border px-5 py-2.5 text-sm text-foreground transition-colors hover:border-accent/40 hover:bg-secondary"
                    >
                      <ExternalLink className="size-4" aria-hidden="true" />
                      Live Demo
                    </a>
                  ) : null}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground/80">
                  {cs.linksNote ??
                    "Public repository and live demo are not currently available."}
                </p>
              )}
            </section>

            <div className="mt-16 border-t border-border/70 pt-8 print:hidden">
              <button
                type="button"
                onClick={onClose}
                className="inline-flex items-center gap-2 rounded-full border border-border px-5 py-2.5 text-sm text-foreground transition-colors hover:border-accent/40 hover:bg-secondary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              >
                <ArrowLeft className="size-4" aria-hidden="true" />
                Back to Projects
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>,
    document.body,
  );
}

function SectionHead({ num, title }: { num: string; title: string }) {
  return (
    <div className="mb-5 mt-16 flex items-baseline gap-3 border-b border-border/70 pb-3">
      <span className="font-mono text-xs text-accent">{num}</span>
      <h2 className="font-display text-2xl font-semibold tracking-tight text-foreground sm:text-3xl">
        {title}
      </h2>
    </div>
  );
}
