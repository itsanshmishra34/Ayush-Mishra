import { useCallback, useEffect, useState } from "react";
import { ChevronDown, ExternalLink } from "lucide-react";
import { experience, type ExperienceItem } from "@/data/experience";
import { Section } from "./Section";
import { Reveal } from "./Reveal";
import { ProofDialog, type ProofTarget } from "./ProofDialog";
import { cn } from "@/lib/utils";

const HASH_PREFIX = "#experience/";

function idFromHash(): string | null {
  if (typeof window === "undefined") return null;
  const hash = window.location.hash;
  if (!hash.startsWith(HASH_PREFIX)) return null;
  const id = decodeURIComponent(hash.slice(HASH_PREFIX.length));
  return experience.some((e) => e.id === id) ? id : null;
}

/**
 * Interactive experience timeline. Renders entirely from src/data/experience.ts.
 * Only one role is expanded at a time; empty data fields are hidden rather
 * than filled with placeholder claims.
 */
export function Experience() {
  const [openId, setOpenId] = useState<string | null>(null);
  const [proof, setProof] = useState<ProofTarget | null>(null);

  // Shareable deep links: #experience/<role-id> opens that role directly.
  useEffect(() => {
    const sync = () => {
      const id = idFromHash();
      if (id) {
        setOpenId(id);
        window.setTimeout(() => {
          document.getElementById(`experience-role-${id}`)?.scrollIntoView({
            behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches
              ? "auto"
              : "smooth",
            block: "center",
          });
        }, 80);
      }
    };
    sync();
    window.addEventListener("hashchange", sync);
    return () => window.removeEventListener("hashchange", sync);
  }, []);

  const writeHash = useCallback((next: string | null) => {
    const url = new URL(window.location.href);
    window.history.replaceState(
      null,
      "",
      next ? `${url.pathname}${url.search}${HASH_PREFIX}${encodeURIComponent(next)}` : url.pathname + url.search,
    );
  }, []);

  const toggle = useCallback(
    (id: string) => {
      const next = openId === id ? null : id;
      setOpenId(next);
      writeHash(next);
    },
    [openId, writeHash],
  );

  const collapse = useCallback(
    (id: string) => {
      if (openId !== id) return;
      setOpenId(null);
      writeHash(null);
    },
    [openId, writeHash],
  );

  return (
    <Section id="experience" eyebrow="04 / Experience" title="Experience & Leadership">
      <ol className="relative ml-3 border-l border-border pl-6 sm:pl-8">
        {experience.map((item, i) => (
          <Reveal as="li" key={item.id} delay={i * 100} className="relative pb-6 last:pb-0">
            <Marker item={item} active={openId === item.id} />
            <TimelineCard
              item={item}
              open={openId === item.id}
              onToggle={() => toggle(item.id)}
              onCollapse={() => collapse(item.id)}
              onOpenProof={setProof}
            />
          </Reveal>
        ))}
      </ol>
      <ProofDialog target={proof} onClose={() => setProof(null)} />
    </Section>
  );
}

function Marker({ item, active }: { item: ExperienceItem; active: boolean }) {
  if (item.logo) {
    return (
      <img
        src={item.logo}
        alt=""
        aria-hidden="true"
        width={24}
        height={24}
        loading="lazy"
        decoding="async"
        className="absolute -left-[37px] top-5 size-6 rounded-full border border-border bg-background object-contain sm:-left-[45px]"
      />
    );
  }
  return (
    <span
      aria-hidden="true"
      className={cn(
        "absolute -left-[31px] top-6 size-3 rounded-full border-2 border-accent bg-background transition-shadow sm:-left-[39px]",
        active && "shadow-[0_0_0_4px_hsl(var(--accent)/0.15)]",
      )}
    />
  );
}

function TimelineCard({
  item,
  open,
  onToggle,
  onCollapse,
  onOpenProof,
}: {
  item: ExperienceItem;
  open: boolean;
  onToggle: () => void;
  onCollapse: () => void;
  onOpenProof: (target: ProofTarget) => void;
}) {
  const panelId = `experience-panel-${item.id}`;
  const hasDetails =
    Boolean(item.description) ||
    item.responsibilities.length > 0 ||
    (item.focus ?? []).length > 0 ||
    item.skills.length > 0 ||
    Boolean(item.proofUrl || item.certificateUrl || item.postUrl);

  return (
    <div
      id={`experience-role-${item.id}`}
      onKeyDown={(e) => {
        if (e.key === "Escape" && open) {
          e.stopPropagation();
          onCollapse();
          (e.currentTarget.querySelector("button") as HTMLElement | null)?.focus();
        }
      }}
      className={cn(
        "rounded-2xl border border-border bg-card/40 transition-colors motion-reduce:transition-none",
        open ? "border-accent/40" : "hover:border-accent/25",
      )}
    >
      <button
        type="button"
        onClick={onToggle}
        onKeyDown={(e) => {
          // Enter/Space are native for <button>; keep them explicit and predictable.
          if (e.key === " " || e.key === "Spacebar") {
            e.preventDefault();
            onToggle();
          }
        }}
        aria-expanded={open}
        aria-controls={panelId}
        className="flex w-full items-start justify-between gap-4 rounded-2xl px-4 py-4 text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring sm:px-6 sm:py-5"
      >
        <span className="min-w-0">
          <span className="flex flex-wrap items-center gap-2">
            <span className="font-mono text-xs uppercase tracking-widest text-accent">
              {item.period}
            </span>
            {item.category ? (
              <span className="rounded-full border border-border px-2 py-0.5 text-[10px] uppercase tracking-wider text-muted-foreground">
                {item.category}
              </span>
            ) : null}
          </span>
          <span className="mt-2 block font-display text-lg font-semibold text-foreground sm:text-xl">
            {item.organization}
          </span>
          {item.organizationType ? (
            <span className="block text-sm text-muted-foreground">{item.organizationType}</span>
          ) : null}
          <span className="mt-1 block text-sm font-medium text-foreground/90">{item.role}</span>
        </span>
        <ChevronDown
          aria-hidden="true"
          className={cn(
            "mt-1 size-4 shrink-0 text-muted-foreground transition-transform duration-200 motion-reduce:transition-none",
            open && "rotate-180 text-accent",
          )}
        />
      </button>

      <div
        id={panelId}
        role="region"
        aria-label={`${item.role} at ${item.organization} details`}
        hidden={!open}
        className="grid gap-5 border-t border-border/70 px-4 pb-5 pt-5 motion-safe:animate-rise sm:px-6"
      >
        {!hasDetails ? (
          <p className="text-sm text-muted-foreground">
            Role details haven't been published yet — only verified role information is shown.
          </p>
        ) : (
          <>
            {item.description ? (
              <p className="text-sm leading-relaxed text-muted-foreground">{item.description}</p>
            ) : null}

            {item.responsibilities.length > 0 ? (
              <div>
                <h4 className="font-mono text-xs uppercase tracking-widest text-muted-foreground">
                  Responsibilities
                </h4>
                <ul className="mt-3 space-y-2">
                  {item.responsibilities.map((r) => (
                    <li key={r} className="flex gap-3 text-sm text-muted-foreground">
                      <span aria-hidden="true" className="mt-2 size-1 shrink-0 rounded-full bg-accent" />
                      <span>{r}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ) : null}

            {(item.focus ?? []).length > 0 ? (
              <div>
                <h4 className="font-mono text-xs uppercase tracking-widest text-muted-foreground">
                  Focus Areas
                </h4>
                <ul className="mt-3 flex flex-wrap gap-2">
                  {(item.focus ?? []).map((f) => (
                    <li
                      key={f}
                      className="rounded-full border border-border px-3 py-1 text-xs text-foreground"
                    >
                      {f}
                    </li>
                  ))}
                </ul>
              </div>
            ) : null}

            {item.skills.length > 0 ? (
              <div>
                <h4 className="font-mono text-xs uppercase tracking-widest text-muted-foreground">
                  Skills
                </h4>
                <ul className="mt-3 flex flex-wrap gap-2">
                  {item.skills.map((s) => (
                    <li
                      key={s}
                      className="rounded-full border border-border px-3 py-1 text-xs text-foreground"
                    >
                      {s}
                    </li>
                  ))}
                </ul>
              </div>
            ) : null}

            <ProofLinks item={item} onOpenProof={onOpenProof} />
          </>
        )}
      </div>
    </div>
  );
}

function ProofLinks({
  item,
  onOpenProof,
}: {
  item: ExperienceItem;
  onOpenProof: (target: ProofTarget) => void;
}) {
  const links = [
    { url: item.proofUrl, label: "View Proof" },
    { url: item.certificateUrl, label: "View Certificate" },
    { url: item.postUrl, label: "View Post" },
  ].filter((l): l is { url: string; label: string } => Boolean(l.url));

  if (links.length === 0) return null;

  return (
    <div className="flex flex-wrap gap-2">
      {links.map((l) => (
        <button
          key={l.label}
          type="button"
          onClick={() =>
            onOpenProof({
              label: l.label,
              url: l.url,
              context: `${item.role} · ${item.organization}`,
            })
          }
          className="inline-flex items-center gap-2 rounded-full border border-border px-3 py-1.5 text-xs text-foreground transition-colors hover:border-accent/40 hover:bg-secondary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring motion-reduce:transition-none"
        >
          {l.label}
          <ExternalLink className="size-3" aria-hidden="true" />
        </button>
      ))}
    </div>
  );
}
