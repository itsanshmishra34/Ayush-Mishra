import { useEffect, useRef, useState } from "react";

const TRIGGER = "ayush";

const LINES = [
  "> Access granted.",
  "> Developer mode initialized.",
  ">",
  "> Building > talking.",
  "> Learning > pretending.",
  "> Shipping > someday.",
] as const;

function isTypingTarget(target: EventTarget | null): boolean {
  if (!(target instanceof HTMLElement)) return false;
  return (
    target.isContentEditable ||
    target.closest('input, textarea, select, [contenteditable="true"], form') !== null
  );
}

/**
 * Hidden developer Easter egg: typing "ayush" anywhere on the page
 * (outside form fields) opens a small terminal-style overlay.
 * ESC closes it. No sound, minimal motion, keyboard-safe.
 */
export function EasterEgg() {
  const [open, setOpen] = useState(false);
  const buffer = useRef("");
  const closeRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setOpen(false);
        return;
      }
      // Never interfere with typing in inputs, textareas, or forms.
      if (isTypingTarget(event.target)) return;
      // Ignore modified keys (shortcuts) and non-character keys.
      if (event.metaKey || event.ctrlKey || event.altKey || event.key.length !== 1) return;

      buffer.current = (buffer.current + event.key.toLowerCase()).slice(-TRIGGER.length);
      if (buffer.current === TRIGGER) {
        buffer.current = "";
        setOpen(true);
      }
    };

    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, []);

  // Move focus to the close control when opened so keyboard users can dismiss it.
  useEffect(() => {
    if (open) closeRef.current?.focus();
  }, [open]);

  if (!open) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Developer terminal"
      className="fixed bottom-6 right-6 z-50 w-[min(22rem,calc(100vw-3rem))] animate-rise rounded-xl border border-accent/30 bg-background/95 shadow-2xl shadow-black/50 backdrop-blur-sm"
    >
      <div className="flex items-center justify-between border-b border-border/60 px-4 py-2.5">
        <div className="flex items-center gap-1.5" aria-hidden="true">
          <span className="size-2 rounded-full bg-muted-foreground/40" />
          <span className="size-2 rounded-full bg-muted-foreground/40" />
          <span className="size-2 rounded-full bg-accent/60" />
        </div>
        <span className="font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
          ayush@dev:~
        </span>
        <button
          ref={closeRef}
          type="button"
          onClick={() => setOpen(false)}
          className="rounded border border-border px-1.5 py-0.5 font-mono text-[10px] uppercase tracking-[0.14em] text-muted-foreground transition-colors hover:border-accent/40 hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          aria-label="Close terminal (Escape)"
        >
          esc
        </button>
      </div>
      <div className="px-4 py-3.5 font-mono text-xs leading-relaxed text-muted-foreground">
        {LINES.map((line, i) => (
          <p key={i} className={line.startsWith("> ") ? "text-foreground/90" : ""}>
            {line === ">" ? <span aria-hidden="true">&gt;</span> : line}
          </p>
        ))}
        <p className="mt-1 text-accent">
          &gt; <span className="inline-block h-3.5 w-1.5 translate-y-0.5 animate-pulse bg-accent" aria-hidden="true" />
        </p>
      </div>
    </div>
  );
}
