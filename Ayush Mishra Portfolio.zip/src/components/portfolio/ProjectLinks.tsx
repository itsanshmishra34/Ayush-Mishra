import { ArrowUpRight, ExternalLink, Github } from "lucide-react";
import type { Project } from "@/data/projects";
import { useRepoUrl } from "@/lib/use-repo-links";


const primary =
  "inline-flex items-center gap-2 rounded-full bg-accent px-5 py-2.5 text-sm font-medium text-accent-foreground transition-transform hover:-translate-y-0.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring";
const secondary =
  "inline-flex items-center gap-2 rounded-full border border-border px-5 py-2.5 text-sm text-foreground transition-colors hover:border-accent/40 hover:bg-secondary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring";

type Props = {
  project: Project;
  /** Called when the project has no external project URL. */
  onDetails?: () => void;
  /** In the detail view the "Project Details" action is not needed. */
  showDetailsAction?: boolean;
};

/**
 * Renders project links. Live/project URLs are hidden when missing; GitHub
 * shows a disabled placeholder when no repository is available yet.
 */
export function ProjectLinks({ project, onDetails, showDetailsAction = true }: Props) {
  const matchedRepoUrl = useRepoUrl(project);
  const githubUrl = project.githubUrl ?? matchedRepoUrl;

  return (
    <div className="flex flex-wrap items-center gap-3">
      {project.projectUrl ? (
        <a href={project.projectUrl} target="_blank" rel="noreferrer" className={primary}>
          View Project
          <ArrowUpRight className="size-4 transition-transform duration-300 group-hover:translate-x-0.5" aria-hidden="true" />
        </a>
      ) : showDetailsAction ? (
        <button type="button" onClick={onDetails} className={primary}>
          {project.caseStudy ? "Explore Case Study" : "Project Details"}
          <ArrowUpRight className="size-4 transition-transform duration-300 group-hover:translate-x-0.5" aria-hidden="true" />
        </button>
      ) : null}

      {project.liveUrl ? (
        <a href={project.liveUrl} target="_blank" rel="noreferrer" className={secondary}>
          <ExternalLink className="size-4" aria-hidden="true" />
          Live Demo
        </a>
      ) : null}

      {githubUrl ? (
        <a href={githubUrl} target="_blank" rel="noreferrer" className={secondary}>
          <Github className="size-4" aria-hidden="true" />
          GitHub
        </a>
      ) : (
        <span
          aria-disabled="true"
          className="inline-flex cursor-not-allowed items-center gap-2 rounded-full border border-border px-5 py-2.5 text-sm text-muted-foreground opacity-60"
          title="GitHub repository not available yet"
        >
          <Github className="size-4" aria-hidden="true" />
          GitHub
        </span>
      )}
    </div>
  );
}

