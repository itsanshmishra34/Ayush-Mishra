import { useState, type FormEvent } from "react";
import { Check, Copy, Linkedin, Mail, MapPin, Phone, Send } from "lucide-react";
import { toast } from "sonner";
import { profile } from "@/data/portfolio";
import { sendContactMessage } from "@/lib/contact.functions";
import { Section } from "./Section";
import { Reveal } from "./Reveal";

export function Contact() {
  const [copied, setCopied] = useState(false);
  const [sending, setSending] = useState(false);
  const [status, setStatus] = useState<string | null>(null);
  const [form, setForm] = useState({ name: "", email: "", message: "" });

  const copyEmail = async () => {
    try {
      await navigator.clipboard.writeText(profile.email);
      setCopied(true);
      toast.success("Email copied to clipboard");
      setTimeout(() => setCopied(false), 2000);
    } catch {
      toast.error("Couldn't copy — please copy manually");
    }
  };

  const onSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (sending) return;
    setSending(true);
    setStatus(null);
    try {
      const result = await sendContactMessage({ data: form });
      if (result.ok) {
        toast.success(result.message);
        setStatus(result.message);
        setForm({ name: "", email: "", message: "" });
      } else {
        toast.error(result.message);
        setStatus(result.message);
      }
    } catch (err) {
      console.error("contact submit failed", err);
      const fallback = `Couldn't send right now — please email me at ${profile.email}.`;
      toast.error(fallback);
      setStatus(fallback);
    } finally {
      setSending(false);
    }
  };

  const inputClass =
    "w-full rounded-xl border border-border bg-background/60 px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground/70 focus:border-accent/60 focus:outline-none focus:ring-2 focus:ring-ring/40";

  return (
    <Section id="contact" eyebrow="07 / Contact" title="Let's Build Something Useful.">
      <div className="grid gap-8 lg:grid-cols-[1fr_1.1fr]">
        <Reveal className="grid content-start gap-4">
          <p className="text-base leading-relaxed text-muted-foreground">
            Open to software engineering internships, technical collaborations, and opportunities
            to learn and build.
          </p>

          <div className="flex flex-wrap gap-3">
            <a
              href={`mailto:${profile.email}`}
              className="accent-glow inline-flex items-center gap-2 rounded-full bg-accent px-5 py-3 text-sm font-medium text-accent-foreground transition-transform hover:-translate-y-0.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            >
              <Mail className="size-4" aria-hidden="true" />
              Email me
            </a>
            <a
              href={profile.linkedin}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-2 rounded-full border border-border bg-surface/60 px-5 py-3 text-sm font-medium text-foreground transition-colors hover:bg-secondary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            >
              <Linkedin className="size-4" aria-hidden="true" />
              LinkedIn
            </a>
            <button
              type="button"
              onClick={copyEmail}
              aria-label="Copy email address"
              className="inline-flex items-center gap-2 rounded-full border border-border px-5 py-3 text-sm text-muted-foreground transition-colors hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            >
              {copied ? (
                <Check className="size-4 text-accent" aria-hidden="true" />
              ) : (
                <Copy className="size-4" aria-hidden="true" />
              )}
              {copied ? "Copied" : "Copy email"}
            </button>
          </div>

          <ul className="mt-2 grid gap-2 font-mono text-sm text-muted-foreground">
            <li className="flex items-center gap-2">
              <Mail className="size-4 text-accent" aria-hidden="true" />
              {profile.email}
            </li>
            <li className="flex items-center gap-2">
              <Phone className="size-4 text-accent" aria-hidden="true" />
              <a href={`tel:${profile.phone}`} className="hover:text-foreground">
                {profile.phone}
              </a>
            </li>
            <li className="flex items-center gap-2">
              <MapPin className="size-4 text-accent" aria-hidden="true" />
              {profile.location}
            </li>
          </ul>
        </Reveal>

        <Reveal delay={120}>
          <form onSubmit={onSubmit} className="glass-panel grid gap-4 rounded-3xl p-6 sm:p-8">
            <div className="grid gap-2">
              <label htmlFor="name" className="text-sm text-foreground">
                Name
              </label>
              <input
                id="name"
                required
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                className={inputClass}
                placeholder="Your name"
              />
            </div>
            <div className="grid gap-2">
              <label htmlFor="email" className="text-sm text-foreground">
                Email
              </label>
              <input
                id="email"
                type="email"
                required
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                className={inputClass}
                placeholder="you@example.com"
              />
            </div>
            <div className="grid gap-2">
              <label htmlFor="message" className="text-sm text-foreground">
                Message
              </label>
              <textarea
                id="message"
                required
                rows={5}
                value={form.message}
                onChange={(e) => setForm({ ...form, message: e.target.value })}
                className={`${inputClass} resize-y`}
                placeholder="What would you like to talk about?"
              />
            </div>
            <button
              type="submit"
              disabled={sending}
              className="inline-flex items-center justify-center gap-2 rounded-xl bg-accent px-5 py-3 text-sm font-medium text-accent-foreground transition-transform hover:-translate-y-0.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-60"
            >
              <Send className="size-4" aria-hidden="true" />
              {sending ? "Sending…" : "Send message"}
            </button>
            <p role="status" aria-live="polite" className="min-h-5 text-sm text-muted-foreground">
              {status}
            </p>
            <p className="text-xs text-muted-foreground">
              Prefer email?{" "}
              <a
                href={`mailto:${profile.email}?subject=${encodeURIComponent("Portfolio enquiry")}`}
                className="text-accent underline-offset-4 hover:underline"
              >
                Write to {profile.email}
              </a>
            </p>
          </form>
        </Reveal>
      </div>
    </Section>
  );
}
