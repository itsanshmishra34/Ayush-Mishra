import { buildProcess } from "@/data/growth";
import { Section } from "./Section";
import { Reveal } from "./Reveal";

export function HowIBuild() {
  return (
    <Section
      id="process"
      eyebrow="Process"
      title="How I Build"
      subtitle="The working method I apply to projects and problems."
    >
      <ol className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {buildProcess.map((step, i) => (
          <Reveal as="li" key={step.id} delay={i * 70}>
            <div className="h-full rounded-2xl border border-border bg-surface/60 p-6 transition-colors duration-300 hover:border-accent/50">
              <span className="font-mono text-xs tracking-[0.22em] text-accent">
                {String(i + 1).padStart(2, "0")}
              </span>
              <h3 className="mt-4 font-display text-base font-semibold uppercase tracking-wide text-foreground">
                {step.title}
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                {step.description}
              </p>
            </div>
          </Reveal>
        ))}
      </ol>
    </Section>
  );
}
