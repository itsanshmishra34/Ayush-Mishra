import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowRight,
  Code2,
  Compass,
  Github,
  Download,
  FileText,
  FolderKanban,
  Linkedin,
  Mail,
  Search,
  SlidersHorizontal,
  Sparkles,
  User,
  Briefcase,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { profile } from "@/data/portfolio";
import { projects } from "@/data/projects";
import { skillGroups } from "@/data/skills";
import { experience } from "@/data/experience";
import { site } from "@/data/site";

/** Event the mobile navbar (or anything else) dispatches to open the palette. */
export const OPEN_COMMAND_PALETTE_EVENT = "command-palette:open";

export function openCommandPalette() {
  window.dispatchEvent(new CustomEvent(OPEN_COMMAND_PALETTE_EVENT));
}

type Command = {
  id: string;
  label: string;
  group: string;
  hint?: string;
  keywords: string;
  icon: typeof Compass;
  run: () => void;
};

function scrollToSection(id: string) {
  document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
}

const GROUP_ORDER = ["Navigation", "Actions", "Projects", "Skills", "Experience"];

function buildCommands(): Command[] {
  const nav = (
    [
      ["Home", "home"],
      ["About", "about"],
      ["Skills", "skills"],
      ["Projects", "projects"],
      ["Experience", "experience"],
      ["Education", "education"],
      ["Contact", "contact"],
    ] as const
  ).map(([label, id]) => ({
    id: `nav-${id}`,
    label: `Go to ${label}`,
    group: "Navigation",
    keywords: `go to ${label} section navigate`,
    icon: Compass,
    run: () => scrollToSection(id),
  }));

  const actions: Command[] = [
    {
      id: "action-projects",
      label: "View Projects",
      group: "Actions",
      keywords: "view projects work portfolio",
      icon: FolderKanban,
      run: () => scrollToSection("projects"),
    },
    {
      id: "action-resume",
      label: "Download Resume",
      group: "Actions",
      hint: "PDF",
      keywords: "download resume cv pdf",
      icon: Download,
      run: () => {
        const a = document.createElement("a");
        a.href = profile.resumeUrl;
        a.download = "";
        document.body.appendChild(a);
        a.click();
        a.remove();
      },
    },
    {
      id: "action-linkedin",
      label: "Open LinkedIn",
      group: "Actions",
      keywords: "open linkedin profile social",
      icon: Linkedin,
      run: () => window.open(profile.linkedin, "_blank", "noopener,noreferrer"),
    },
    {
      id: "action-github",
      label: "Open GitHub",
      group: "Actions",
      keywords: "open github repositories code profile",
      icon: Github,
      run: () => window.open(site.links.github, "_blank", "noopener,noreferrer"),
    },
    {
      id: "action-leetcode",
      label: "Open LeetCode",
      group: "Actions",
      keywords: "open leetcode dsa problems profile",
      icon: Code2,
      run: () => window.open(site.links.leetcode, "_blank", "noopener,noreferrer"),
    },
    {
      id: "action-email",
      label: "Send Email",
      group: "Actions",
      hint: profile.email,
      keywords: "send email contact mail",
      icon: Mail,
      run: () => {
        window.location.href = `mailto:${profile.email}`;
      },
    },
    {
      id: "action-search-projects",
      label: "Search Projects",
      group: "Actions",
      keywords: "search projects find",
      icon: Search,
      run: () => scrollToSection("projects"),
    },
    {
      id: "action-filter-technology",
      label: "Filter by Technology",
      group: "Actions",
      hint: "Technology Explorer",
      keywords: "filter technology explorer stack",
      icon: SlidersHorizontal,
      run: () => scrollToSection("explorer"),
    },
    {
      id: "action-filter-category",
      label: "Filter by Category",
      group: "Actions",
      keywords: "filter category projects",
      icon: SlidersHorizontal,
      run: () => scrollToSection("projects"),
    },
  ];

  return [...nav, ...actions];
}

/** Searchable content derived from the centralized data sources. */
function buildSearchResults(): Command[] {
  const projectCommands: Command[] = projects.map((p) => ({
    id: `project-${p.slug}`,
    label: p.title,
    group: "Projects",
    hint: p.category,
    keywords: `${p.title} ${p.technologies.join(" ")} ${p.category} project`,
    icon: FolderKanban,
    run: () => scrollToSection("projects"),
  }));

  const skillCommands: Command[] = skillGroups.flatMap((group) =>
    group.items.map((skill) => ({
      id: `skill-${group.category}-${skill}`,
      label: skill,
      group: "Skills",
      hint: group.category,
      keywords: `${skill} ${group.category} skill technology`,
      icon: Sparkles,
      run: () => scrollToSection("skills"),
    })),
  );

  const experienceCommands: Command[] = experience.map((e, i) => ({
    id: `experience-${i}`,
    label: `${e.role} · ${e.company}`,
    group: "Experience",
    hint: e.period,
    keywords: `${e.role} ${e.company} experience role ${(e.technologies ?? []).join(" ")}`,
    icon: Briefcase,
    run: () => scrollToSection("experience"),
  }));

  return [...projectCommands, ...skillCommands, ...experienceCommands];
}

const SECTION_RESULTS: Command[] = (
  [
    ["Home", "home"],
    ["About", "about"],
    ["Skills", "skills"],
    ["Engineering Snapshot", "snapshot"],
    ["Projects", "projects"],
    ["Technology Explorer", "explorer"],
    ["Experience", "experience"],
    ["Education", "education"],
    ["Certifications", "certifications"],
    ["Contact", "contact"],
  ] as const
).map(([label, id]) => ({
  id: `section-${id}`,
  label: `${label} section`,
  group: "Navigation",
  keywords: `${label} section ${id}`,
  icon: User,
  run: () => scrollToSection(id),
}));

const ALL_COMMANDS = buildCommands();
const SEARCHABLE = [...SECTION_RESULTS, ...buildSearchResults()];

function matches(query: string, cmd: Command): boolean {
  const haystack = `${cmd.label} ${cmd.keywords}`.toLowerCase();
  return query
    .toLowerCase()
    .split(/\s+/)
    .filter(Boolean)
    .every((token) => haystack.includes(token));
}

export function CommandPalette() {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [activeIndex, setActiveIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const listRef = useRef<HTMLUListElement>(null);
  const restoreFocusRef = useRef<HTMLElement | null>(null);

  const openPalette = useCallback(() => {
    restoreFocusRef.current = document.activeElement as HTMLElement | null;
    setQuery("");
    setActiveIndex(0);
    setOpen(true);
  }, []);

  const closePalette = useCallback(() => {
    setOpen(false);
    restoreFocusRef.current?.focus();
  }, []);

  // Global keyboard shortcut: Ctrl+K / Cmd+K, plus the custom open event.
  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        setOpen((v) => {
          if (v) return false;
          restoreFocusRef.current = document.activeElement as HTMLElement | null;
          setQuery("");
          setActiveIndex(0);
          return true;
        });
      }
    };
    window.addEventListener("keydown", onKeyDown);
    window.addEventListener(OPEN_COMMAND_PALETTE_EVENT, openPalette);
    return () => {
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener(OPEN_COMMAND_PALETTE_EVENT, openPalette);
    };
  }, [openPalette]);

  const results = useMemo(() => {
    const trimmed = query.trim();
    if (!trimmed) return ALL_COMMANDS;
    const commandMatches = ALL_COMMANDS.filter((c) => matches(trimmed, c));
    const searchMatches = SEARCHABLE.filter((c) => matches(trimmed, c));
    const seen = new Set(commandMatches.map((c) => c.id));
    return [...commandMatches, ...searchMatches.filter((c) => !seen.has(c.id))];
  }, [query]);

  const grouped = useMemo(() => {
    const groups: { name: string; items: { cmd: Command; index: number }[] }[] = [];
    for (const name of GROUP_ORDER) {
      const items = results
        .map((cmd, index) => ({ cmd, index }))
        .filter(({ cmd }) => cmd.group === name);
      if (items.length > 0) groups.push({ name, items });
    }
    return groups;
  }, [results]);

  useEffect(() => setActiveIndex(0), [query]);

  // Focus the input when opened.
  useEffect(() => {
    if (open) inputRef.current?.focus();
  }, [open]);

  // Keep the active option in view.
  useEffect(() => {
    if (!open) return;
    listRef.current
      ?.querySelector(`[data-index="${activeIndex}"]`)
      ?.scrollIntoView({ block: "nearest" });
  }, [activeIndex, open]);

  const runCommand = useCallback(
    (cmd: Command) => {
      closePalette();
      cmd.run();
    },
    [closePalette],
  );

  if (!open) return null;

  const onInputKeyDown = (event: React.KeyboardEvent) => {
    if (event.key === "ArrowDown") {
      event.preventDefault();
      setActiveIndex((i) => (results.length ? (i + 1) % results.length : 0));
    } else if (event.key === "ArrowUp") {
      event.preventDefault();
      setActiveIndex((i) => (results.length ? (i - 1 + results.length) % results.length : 0));
    } else if (event.key === "Home") {
      event.preventDefault();
      setActiveIndex(0);
    } else if (event.key === "End") {
      event.preventDefault();
      setActiveIndex(Math.max(0, results.length - 1));
    } else if (event.key === "Enter") {
      event.preventDefault();
      const cmd = results[activeIndex];
      if (cmd) runCommand(cmd);
    } else if (event.key === "Escape") {
      event.preventDefault();
      closePalette();
    } else if (event.key === "Tab") {
      // Keep focus trapped inside the palette.
      event.preventDefault();
      inputRef.current?.focus();
    }
  };

  return (
    <div
      className="fixed inset-0 z-[60] flex items-start justify-center px-4 pt-[14vh]"
      role="presentation"
      onClick={closePalette}
    >
      <div className="absolute inset-0 bg-background/70 backdrop-blur-sm" aria-hidden="true" />
      <div
        role="dialog"
        aria-modal="true"
        aria-label="Command palette"
        className="relative w-full max-w-xl animate-rise overflow-hidden rounded-2xl border border-border bg-background shadow-2xl shadow-black/60"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center gap-3 border-b border-border/70 px-4">
          <Search className="size-4 shrink-0 text-muted-foreground" aria-hidden="true" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={onInputKeyDown}
            placeholder="Search projects, skills, sections…"
            aria-label="Search commands"
            aria-expanded="true"
            aria-controls="command-palette-list"
            aria-activedescendant={
              results.length ? `command-option-${activeIndex}` : undefined
            }
            role="combobox"
            className="h-12 w-full bg-transparent text-sm text-foreground outline-none placeholder:text-muted-foreground"
          />
          <kbd className="shrink-0 rounded border border-border px-1.5 py-0.5 font-mono text-[10px] uppercase text-muted-foreground">
            esc
          </kbd>
        </div>

        <p className="sr-only" aria-live="polite">
          {results.length} result{results.length === 1 ? "" : "s"} available
        </p>

        <ul
          id="command-palette-list"
          role="listbox"
          aria-label="Commands"
          ref={listRef}
          className="max-h-[50vh] overflow-y-auto p-2"
        >
          {grouped.map((group) => (
            <li key={group.name} className="mb-1 last:mb-0">
              <p className="px-3 pb-1 pt-2 font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
                {group.name}
              </p>
              <ul>
                {group.items.map(({ cmd, index }) => {
                  const Icon = cmd.icon;
                  const selected = index === activeIndex;
                  return (
                    <li key={cmd.id}>
                      <button
                        type="button"
                        id={`command-option-${index}`}
                        data-index={index}
                        role="option"
                        aria-selected={selected}
                        tabIndex={-1}
                        onClick={() => runCommand(cmd)}
                        onMouseEnter={() => setActiveIndex(index)}
                        className={cn(
                          "flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left text-sm transition-colors focus-visible:outline-none",
                          selected
                            ? "bg-accent/10 text-foreground"
                            : "text-muted-foreground hover:bg-secondary",
                        )}
                      >
                        <Icon
                          className={cn("size-4 shrink-0", selected ? "text-accent" : "text-muted-foreground")}
                          aria-hidden="true"
                        />
                        <span className="flex-1 truncate">{cmd.label}</span>
                        {cmd.hint ? (
                          <span className="truncate font-mono text-[10px] text-muted-foreground/80">
                            {cmd.hint}
                          </span>
                        ) : null}
                        {selected ? (
                          <ArrowRight className="size-3.5 shrink-0 text-accent" aria-hidden="true" />
                        ) : null}
                      </button>
                    </li>
                  );
                })}
              </ul>
            </li>
          ))}
          {results.length === 0 ? (
            <li className="px-3 py-8 text-center text-sm text-muted-foreground">
              No results for “{query}”.
            </li>
          ) : null}
        </ul>

        <div className="flex items-center gap-4 border-t border-border/70 px-4 py-2.5 font-mono text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
          <span className="flex items-center gap-1.5">
            <kbd className="rounded border border-border px-1 py-0.5">↑↓</kbd> navigate
          </span>
          <span className="flex items-center gap-1.5">
            <kbd className="rounded border border-border px-1 py-0.5">↵</kbd> select
          </span>
          <span className="ml-auto hidden items-center gap-1.5 sm:flex">
            <FileText className="size-3" aria-hidden="true" /> {profile.name}
          </span>
        </div>
      </div>
    </div>
  );
}
