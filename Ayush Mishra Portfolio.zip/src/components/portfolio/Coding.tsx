import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { ArrowUpRight, Github, GitFork, RefreshCw, Star, Terminal } from "lucide-react";
import {
  GITHUB_PROFILE_URL,
  GITHUB_USERNAME,
  curateRepos,
  fetchGithubProfile,
} from "@/lib/github";
import { archiveLimit, featuredRepositories } from "@/data/github";
import { cn } from "@/lib/utils";
import { LEETCODE_PROFILE_URL, LEETCODE_USERNAME, fetchLeetcodeProfile } from "@/lib/leetcode";
import { Section } from "./Section";
import {
  formatFetchedAt,
  readSnapshot,
  writeSnapshot,
  type CachedSnapshot,
} from "@/lib/stats-cache";
import { Reveal } from "./Reveal";

const CACHE_MS = 1000 * 60 * 30;

function ProfileButton({ href, children }: { href: string; children: string }) {
  return (
    <a
      href={href}
      target="_blank"
      rel="noreferrer noopener"
      className="inline-flex items-center gap-2 rounded-full border border-accent/40 bg-accent/10 px-4 py-2 font-mono text-[11px] uppercase tracking-[0.18em] text-accent transition-colors hover:border-accent hover:bg-accent/15 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
    >
      {children}
      <ArrowUpRight className="size-3.5" aria-hidden="true" />
    </a>
  );
}

function Panel({
  icon,
  label,
  children,
}: {
  icon: React.ReactNode;
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex h-full flex-col rounded-2xl border border-border bg-surface/60 p-6">
      <p className="flex items-center gap-2.5">
        <span className="inline-flex size-8 items-center justify-center rounded-lg bg-accent/10 text-accent">
          {icon}
        </span>
        <span className="font-mono text-[11px] uppercase tracking-[0.22em] text-muted-foreground">
          {label}
        </span>
      </p>
      <div className="mt-6 flex flex-1 flex-col">{children}</div>
    </div>
  );
}

function StaleNotice({ fetchedAt }: { fetchedAt: string }) {
  return (
    <p
      role="status"
      className="mb-4 rounded-lg border border-border/70 bg-background/50 px-3 py-2 text-[11px] text-muted-foreground"
    >
      Live refresh failed — showing last known data from {formatFetchedAt(fetchedAt)}.
    </p>
  );
}

function RefreshingNote({ show }: { show: boolean }) {
  if (!show) return null;
  return (
    <p className="mb-4 flex items-center gap-2 font-mono text-[11px] uppercase tracking-[0.16em] text-muted-foreground">
      <RefreshCw className="size-3 motion-safe:animate-spin" aria-hidden="true" />
      Refreshing in background
    </p>
  );
}

function RetryButton({ onClick, busy }: { onClick: () => void; busy: boolean }) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={busy}
      className="inline-flex items-center gap-2 rounded-full border border-border bg-background/60 px-4 py-2 font-mono text-[11px] uppercase tracking-[0.18em] text-foreground transition-colors hover:border-accent/60 hover:text-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:opacity-60"
    >
      <RefreshCw
        className={cn("size-3.5", busy && "motion-safe:animate-spin")}
        aria-hidden="true"
      />
      {busy ? "Retrying…" : "Retry"}
    </button>
  );
}

function Skeleton({ className }: { className: string }) {
  return <div className={`animate-pulse rounded-md bg-border/60 ${className}`} aria-hidden="true" />;
}

function LiveAnnouncer({ message }: { message: string }) {
  return (
    <span role="status" aria-live="polite" className="sr-only">
      {message}
    </span>
  );
}


function RepoCard({
  repo,
  featured = false,
}: {
  repo: import("@/types/github").GithubRepo;
  featured?: boolean;
}) {
  return (
    <li
      className={cn(
        "rounded-xl border bg-background/40 transition-colors hover:border-accent/40",
        featured ? "border-accent/40 p-5" : "border-border/70 p-4",
      )}
    >
      <div className="flex items-start justify-between gap-3">
        <p
          className={cn(
            "font-display font-semibold text-foreground",
            featured ? "text-base" : "text-sm",
          )}
        >
          {repo.name}
        </p>
        <span className="flex shrink-0 items-center gap-3 font-mono text-[11px] text-muted-foreground">
          <span className="flex items-center gap-1">
            <Star className="size-3" aria-hidden="true" />
            {repo.stars}
          </span>
          <span className="flex items-center gap-1">
            <GitFork className="size-3" aria-hidden="true" />
            {repo.forks}
          </span>
        </span>
      </div>
      {repo.description ? (
        <p className="mt-1.5 text-sm text-muted-foreground">{repo.description}</p>
      ) : null}
      <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-2 font-mono text-[11px] uppercase tracking-[0.14em] text-muted-foreground">
        {repo.language ? <span className="text-accent">{repo.language}</span> : null}
        {repo.updatedAt ? (
          <span>
            Updated{" "}
            {new Date(repo.updatedAt).toLocaleDateString(undefined, {
              year: "numeric",
              month: "short",
              day: "numeric",
            })}
          </span>
        ) : null}
        <a
          href={repo.url}
          target="_blank"
          rel="noreferrer noopener"
          className="ml-auto inline-flex items-center gap-1 text-foreground transition-colors hover:text-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        >
          View repository
          <ArrowUpRight className="size-3" aria-hidden="true" />
        </a>
      </div>
    </li>
  );
}

function GithubPanel() {
  const fn = useServerFn(fetchGithubProfile);
  const query = useQuery({
    queryKey: ["github-profile", GITHUB_USERNAME],
    queryFn: () => fn({ data: { username: GITHUB_USERNAME } }),
    staleTime: CACHE_MS,
    gcTime: CACHE_MS * 2,
    retry: 1,
  });

  type GithubResult = NonNullable<typeof query.data>;

  const live =
    !query.isError && query.data && !query.data.error && query.data.profile ? query.data : null;

  const [snapshot, setSnapshot] = useState<CachedSnapshot<GithubResult> | null>(null);
  useEffect(() => {
    setSnapshot(readSnapshot<GithubResult>("github"));
  }, []);
  useEffect(() => {
    if (live) writeSnapshot("github", live);
  }, [live]);

  const d = live ?? snapshot?.data ?? null;
  const stale = !live && d !== null;
  const loading = query.isLoading && d === null;
  const failed = !loading && d === null;

  const curated = curateRepos(d?.repos ?? [], featuredRepositories, archiveLimit);
  const featured = curated.featured;
  const archive = curated.archive;

  return (
    <Panel icon={<Github className="size-4" aria-hidden="true" />} label="GitHub">
      <LiveAnnouncer
        message={
          loading
            ? "Loading GitHub profile and repositories."
            : failed
              ? "Live GitHub data could not be loaded. A link to the GitHub profile is available."
              : stale
                ? "Live GitHub refresh failed. Showing last known GitHub data."
                : "GitHub profile and repositories loaded."
        }
      />
      {loading ? (
        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <Skeleton className="size-12 rounded-full" />
            <Skeleton className="h-4 w-32" />
          </div>
          {[0, 1, 2].map((i) => (
            <div key={i} className="space-y-2 rounded-xl border border-border/60 p-4">
              <Skeleton className="h-3.5 w-40" />
              <Skeleton className="h-3 w-full" />
              <Skeleton className="h-3 w-24" />
            </div>
          ))}
        </div>
      ) : failed ? (
        <div className="flex flex-1 flex-col items-start justify-between gap-6">
          <div className="space-y-2">
            <p className="text-sm text-muted-foreground">
              GitHub data is temporarily unavailable.
            </p>
            <p className="text-sm text-muted-foreground">
              My repositories are still public and viewable directly on GitHub.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-3">
            <RetryButton onClick={() => void query.refetch()} busy={query.isFetching} />
            <ProfileButton href={GITHUB_PROFILE_URL}>View GitHub Profile →</ProfileButton>
          </div>
        </div>
      ) : (

        <>
          <RefreshingNote show={query.isFetching && !loading} />
          {stale && snapshot ? <StaleNotice fetchedAt={snapshot.fetchedAt} /> : null}

          <div className="flex items-center gap-3">
            {d!.profile!.avatarUrl ? (
              <img
                src={d!.profile!.avatarUrl}
                alt={`GitHub avatar of ${d!.profile!.username}`}
                width={48}
                height={48}
                loading="lazy"
                decoding="async"
                className="size-12 rounded-full border border-border object-cover"
              />
            ) : null}
            <div>
              <p className="font-display text-base font-semibold text-foreground">
                @{d!.profile!.username}
              </p>
              <p className="font-mono text-[11px] uppercase tracking-[0.16em] text-muted-foreground">
                {d!.profile!.publicRepos ?? d!.repos.length} public repositories
              </p>
            </div>
          </div>

          {d!.languages.length > 0 ? (
            <div className="mt-6">
              <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
                Top languages
              </p>
              <div className="mt-2 flex flex-wrap gap-2">
                {d!.languages.map((l) => (
                  <span
                    key={l.language}
                    className="rounded-full border border-border bg-background/60 px-3 py-1 text-xs text-foreground"
                  >
                    {l.language} · {l.percent}%
                  </span>
                ))}
              </div>
              <p className="mt-2 text-[11px] text-muted-foreground">
                Share of public repositories by primary language — not a proficiency rating.
              </p>
            </div>
          ) : null}

          {featured.length > 0 ? (
            <div className="mt-6">
              <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
                Featured repositories
              </p>
              <ul className="mt-2 space-y-3">
                {featured.map((repo) => (
                  <RepoCard key={repo.id} repo={repo} featured />
                ))}
              </ul>
            </div>
          ) : null}

          {archive.length > 0 ? (
            <div className="mt-6">
              {featured.length > 0 ? (
                <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
                  Repository archive
                </p>
              ) : null}
              <ul className="mt-2 space-y-3">
                {archive.map((repo) => (
                  <RepoCard key={repo.id} repo={repo} />
                ))}
              </ul>
            </div>
          ) : null}


          <div className="mt-6 pt-2">
            <ProfileButton href={d!.profile!.profileUrl}>View GitHub Profile →</ProfileButton>
          </div>
        </>
      )}
    </Panel>
  );
}

function StatBlock({ label, value }: { label: string; value: number }) {
  return (
    <div>
      <dt className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
        {label}
      </dt>
      <dd className="mt-1 font-display text-2xl font-semibold text-accent">{value}</dd>
    </div>
  );
}

function LeetcodePanel() {
  const fn = useServerFn(fetchLeetcodeProfile);
  const query = useQuery({
    queryKey: ["leetcode-profile", LEETCODE_USERNAME],
    queryFn: () => fn({ data: { username: LEETCODE_USERNAME } }),
    staleTime: CACHE_MS,
    gcTime: CACHE_MS * 2,
    retry: 1,
  });

  type LeetcodeResult = NonNullable<typeof query.data>;

  const live =
    !query.isError && query.data && !query.data.error && query.data.totalSolved !== null
      ? query.data
      : null;

  const [snapshot, setSnapshot] = useState<CachedSnapshot<LeetcodeResult> | null>(null);
  useEffect(() => {
    setSnapshot(readSnapshot<LeetcodeResult>("leetcode"));
  }, []);
  useEffect(() => {
    if (live) writeSnapshot("leetcode", live);
  }, [live]);

  const d = live ?? snapshot?.data ?? null;
  const stale = !live && d !== null;
  const loading = query.isLoading && d === null;
  const failed = !loading && d === null;

  return (
    <Panel icon={<Terminal className="size-4" aria-hidden="true" />} label="LeetCode">
      <LiveAnnouncer
        message={
          loading
            ? "Loading LeetCode statistics."
            : failed
              ? "Live LeetCode statistics could not be loaded. Placeholder statistics are shown and a link to the LeetCode profile is available."
              : stale
                ? "Live LeetCode refresh failed. Showing last known LeetCode statistics."
                : "LeetCode statistics loaded."
        }
      />
      {loading ? (
        <div className="space-y-4">
          <Skeleton className="h-4 w-28" />
          <div className="grid grid-cols-2 gap-4">
            {[0, 1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-14 w-full" />
            ))}
          </div>
          <Skeleton className="h-9 w-48 rounded-full" />
        </div>
      ) : failed ? (
        <div className="flex flex-1 flex-col items-start justify-between gap-6">
          <div className="space-y-3">
            <p className="text-sm text-muted-foreground">
              Live LeetCode statistics are currently unavailable, and no previously fetched
              snapshot is stored in this browser.
            </p>
            <dl className="grid grid-cols-2 gap-5 sm:grid-cols-4" aria-label="Placeholder statistics">
              {["Solved", "Easy", "Medium", "Hard"].map((label) => (
                <div key={label}>
                  <dt className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
                    {label}
                  </dt>
                  <dd className="mt-1 font-display text-2xl font-semibold text-muted-foreground/60">
                    —
                  </dd>
                </div>
              ))}
            </dl>
            <p className="text-[11px] text-muted-foreground">
              Current numbers are always available on my LeetCode profile.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-3">
            <RetryButton onClick={() => void query.refetch()} busy={query.isFetching} />
            <ProfileButton href={LEETCODE_PROFILE_URL}>View LeetCode Profile →</ProfileButton>
          </div>
        </div>

      ) : (
        <>
          <RefreshingNote show={query.isFetching && !loading} />
          {stale && snapshot ? <StaleNotice fetchedAt={snapshot.fetchedAt} /> : null}
          <p className="font-mono text-[11px] uppercase tracking-[0.16em] text-muted-foreground">
            @{d!.username}
          </p>
          <dl className="mt-4 grid grid-cols-2 gap-5 sm:grid-cols-4">
            {d!.totalSolved !== null ? (
              <StatBlock label="Solved" value={d!.totalSolved} />
            ) : null}
            {d!.easy !== null ? <StatBlock label="Easy" value={d!.easy} /> : null}
            {d!.medium !== null ? <StatBlock label="Medium" value={d!.medium} /> : null}
            {d!.hard !== null ? <StatBlock label="Hard" value={d!.hard} /> : null}
          </dl>

          {d!.ranking !== null || d!.contestRating !== null ? (
            <dl className="mt-6 flex flex-wrap gap-8">
              {d!.ranking !== null ? (
                <div>
                  <dt className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
                    Global ranking
                  </dt>
                  <dd className="mt-1 text-base text-foreground">
                    #{d!.ranking.toLocaleString()}
                  </dd>
                </div>
              ) : null}
              {d!.contestRating !== null ? (
                <div>
                  <dt className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
                    Contest rating
                  </dt>
                  <dd className="mt-1 text-base text-foreground">{d!.contestRating}</dd>
                </div>
              ) : null}
            </dl>
          ) : null}

          {d!.languages.length > 0 ? (
            <div className="mt-6">
              <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
                Languages used
              </p>
              <div className="mt-2 flex flex-wrap gap-2">
                {d!.languages.map((l) => (
                  <span
                    key={l.language}
                    className="rounded-full border border-border bg-background/60 px-3 py-1 text-xs text-foreground"
                  >
                    {l.language} · {l.problemsSolved}
                  </span>
                ))}
              </div>
            </div>
          ) : null}

          {d!.badges.length > 0 ? (
            <div className="mt-6">
              <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
                Badges
              </p>
              <div className="mt-2 flex flex-wrap gap-2">
                {d!.badges.map((b) => (
                  <span
                    key={b}
                    className="rounded-full border border-accent/30 bg-accent/5 px-3 py-1 text-xs text-accent"
                  >
                    {b}
                  </span>
                ))}
              </div>
            </div>
          ) : null}

          <div className="mt-auto pt-6">
            <ProfileButton href={d!.profileUrl}>View LeetCode Profile →</ProfileButton>
          </div>
        </>
      )}
    </Panel>
  );
}

export function Coding() {
  return (
    <Section
      id="coding"
      eyebrow="05 / Activity"
      title="Coding & Open Source"
      subtitle="Live public activity from my GitHub and LeetCode profiles. Curated portfolio projects stay in the Projects section."
    >
      <div className="grid gap-6 lg:grid-cols-2">
        <Reveal>
          <GithubPanel />
        </Reveal>
        <Reveal delay={90}>
          <LeetcodePanel />
        </Reveal>
      </div>
    </Section>
  );
}
