import { valueProposition } from "@/data/growth";
import { Section } from "./Section";
import { Reveal } from "./Reveal";

export function ValueProposition() {
  return (
    <Section
      id="value"
      eyebrow="Value"
      title="What I Bring"
      subtitle="What I can contribute to a team today."
    >
      <ul className="grid gap-4 md:grid-cols-3">
        {valueProposition.map((item, i) => (
          <Reveal as="li" key={item.id} delay={i * 70}>
            <div className="h-full rounded-2xl border border-border bg-surface/60 p-6 transition-all duration-300 hover:-translate-y-1 hover:border-accent/50">
              <span className="font-mono text-xs tracking-[0.22em] text-accent">
                {String(i + 1).padStart(2, "0")}
              </span>
              <h3 className="mt-4 font-display text-lg font-semibold text-foreground">
                {item.title}
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                {item.description}
              </p>
            </div>
          </Reveal>
        ))}
      </ul>
    </Section>
  );
}
