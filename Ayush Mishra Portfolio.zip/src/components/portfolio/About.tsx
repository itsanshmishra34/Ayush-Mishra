import { profile } from "@/data/portfolio";
import { Section } from "./Section";
import { Reveal } from "./Reveal";

export function About() {
  return (
    <Section id="about" eyebrow="01 / About" title="About Me">
      <div className="grid gap-10 lg:grid-cols-[1fr_1.15fr] lg:gap-16">
        <Reveal>
          <p className="font-display text-2xl font-semibold leading-snug tracking-tight text-foreground sm:text-3xl">
            {profile.aboutStatement}
          </p>
        </Reveal>

        <Reveal delay={100} className="grid gap-5">
          {profile.aboutParagraphs.map((paragraph) => (
            <p key={paragraph} className="text-base leading-relaxed text-muted-foreground">
              {paragraph}
            </p>
          ))}
        </Reveal>
      </div>

      <dl className="mt-12 grid gap-4 sm:grid-cols-3">
        {profile.infoBlocks.map((block, i) => (
          <Reveal key={block.label} delay={i * 80}>
            <div className="h-full rounded-2xl border border-border bg-surface/60 p-5 transition-colors hover:border-accent/40">
              <dt className="font-mono text-xs uppercase tracking-[0.22em] text-accent">
                {block.label}
              </dt>
              <dd className="mt-2 text-sm text-foreground">{block.value}</dd>
            </div>
          </Reveal>
        ))}
      </dl>
    </Section>
  );
}
