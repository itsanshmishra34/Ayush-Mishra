import { Boxes, Brain, Globe, ScanEye, Sparkles } from "lucide-react";
import type { Project } from "@/data/projects";
import { cn } from "@/lib/utils";

const categoryIcon = {
  "AI / Computer Vision": ScanEye,
  "Computer Vision": ScanEye,
  "AI / ML": Brain,
  "Software Development": Boxes,
  "Web Development": Globe,
  Other: Sparkles,
} as const;

type Props = {
  project: Project;
  className?: string;
  priority?: boolean;
};

/** Renders the project image, or an abstract category-based placeholder. */
export function ProjectVisual({ project, className, priority = false }: Props) {
  const Icon = categoryIcon[project.category] ?? Sparkles;

  return (
    <div
      className={cn(
        "relative overflow-hidden rounded-2xl border border-border/70 bg-background",
        className,
      )}
    >
      {project.image ? (
        <img
          src={project.image}
          srcSet={project.imageSrcSet ?? undefined}
          sizes={project.imageSizes ?? undefined}
          fetchPriority={priority ? "high" : "auto"}
          alt={`Abstract ${project.category} visual representing ${project.title}. Not a screenshot of the software.`}
          width={1280}
          height={960}
          loading={priority ? "eager" : "lazy"}
          decoding="async"
          className="size-full object-cover transition-transform duration-700 group-hover:scale-105"
        />
      ) : (
        <div aria-hidden="true" className="absolute inset-0">
          <div className="grid-backdrop absolute inset-0 opacity-60" />
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="relative flex size-32 items-center justify-center rounded-full border border-accent/30 transition-transform duration-500 group-hover:scale-105 sm:size-40">
              <div className="absolute inset-5 rounded-full border border-accent/20" />
              <div className="absolute inset-10 rounded-full border border-accent/10" />
              <div className="absolute inset-0 rounded-full bg-accent/10 blur-2xl" />
              <Icon className="relative size-10 text-accent" />
            </div>
          </div>
          <p className="absolute inset-x-5 bottom-5 font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
            {project.category}
          </p>
        </div>
      )}
    </div>
  );
}
