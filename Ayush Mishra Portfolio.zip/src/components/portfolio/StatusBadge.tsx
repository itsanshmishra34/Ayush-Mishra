import type { ProjectStatus } from "@/data/projects";

const styles: Record<ProjectStatus, string> = {
  Completed: "border-accent/30 bg-accent/10 text-accent",
  "In Progress": "border-border bg-secondary text-foreground",
  "Coming Soon": "border-dashed border-border text-muted-foreground",
  Archived: "border-border/60 text-muted-foreground/80",
};

export function StatusBadge({ status }: { status: ProjectStatus }) {
  return (
    <span
      className={`rounded-full border px-3 py-1 font-mono text-[10px] uppercase tracking-[0.18em] ${styles[status]}`}
    >
      {status}
    </span>
  );
}
