import { Link } from "@tanstack/react-router";
import { ArrowDown, ArrowRight, Code2, Download, FileText, Github, Linkedin, Mail, MapPin } from "lucide-react";
import { profile } from "@/data/portfolio";
import { site } from "@/data/site";


export function Hero() {
  return (
    <section
      id="home"
      aria-label="Introduction"
      className="relative flex min-h-svh items-center overflow-hidden pt-32 pb-20 sm:pt-36"
    >
      <div aria-hidden="true" className="pointer-events-none absolute inset-0">
        <div className="grid-backdrop absolute inset-0" />
        <div className="animate-orb absolute -top-32 left-1/4 size-[28rem] rounded-full bg-accent/10 blur-3xl" />
        <div
          className="animate-orb absolute -right-24 top-24 size-[22rem] rounded-full bg-chart-2/10 blur-3xl"
          style={{ animationDelay: "-6s" }}
        />
      </div>

      <div className="relative mx-auto w-full max-w-6xl px-5 sm:px-8">
        <p
          className="animate-rise inline-flex items-center gap-2 rounded-full border border-border bg-surface/60 px-4 py-1.5 font-mono text-[11px] uppercase tracking-[0.22em] text-muted-foreground sm:text-xs"
          style={{ animationDelay: "40ms" }}
        >
          <span className="size-1.5 rounded-full bg-accent" />
          {profile.heroEyebrow}
        </p>

        <h1
          className="animate-rise mt-7 font-display text-4xl font-semibold uppercase leading-[1.05] tracking-tight sm:text-6xl lg:text-7xl"
          style={{ animationDelay: "120ms" }}
        >
          {profile.name}
        </h1>

        <p
          className="animate-rise mt-5 max-w-3xl bg-gradient-to-r from-foreground to-accent bg-clip-text font-display text-2xl font-medium leading-tight tracking-tight text-transparent sm:text-4xl lg:text-5xl"
          style={{ animationDelay: "180ms" }}
        >
          {profile.heroHeadline}
        </p>

        <p
          className="animate-rise mt-6 max-w-2xl text-base leading-relaxed text-muted-foreground sm:text-lg"
          style={{ animationDelay: "240ms" }}
        >
          {profile.heroSupport}
        </p>

        <p
          className="animate-rise mt-4 font-mono text-[11px] uppercase tracking-[0.22em] text-muted-foreground sm:text-xs"
          style={{ animationDelay: "270ms" }}
        >
          B.Tech CSE @ LPU · 2025–2029 · {profile.tagline}
        </p>


        <div
          className="animate-rise mt-9 flex flex-wrap items-center gap-3"
          style={{ animationDelay: "300ms" }}
        >
          <a
            href="#projects"
            className="accent-glow inline-flex items-center gap-2 rounded-full bg-accent px-6 py-3 text-sm font-medium text-accent-foreground transition-transform hover:-translate-y-0.5 active:translate-y-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          >
            View Projects
            <ArrowRight className="size-4" aria-hidden="true" />
          </a>
          <Link
            to="/resume"
            className="inline-flex items-center gap-2 rounded-full border border-border bg-surface/60 px-6 py-3 text-sm font-medium text-foreground transition-colors hover:bg-secondary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          >
            <FileText className="size-4" aria-hidden="true" />
            View Resume
          </Link>
          <a
            href={profile.resumeUrl}
            download
            className="inline-flex items-center gap-2 rounded-full border border-border bg-surface/60 px-6 py-3 text-sm font-medium text-foreground transition-colors hover:bg-secondary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          >
            <Download className="size-4" aria-hidden="true" />
            Download Resume
          </a>

        </div>

        <div
          className="animate-rise mt-8 flex flex-wrap items-center gap-x-5 gap-y-3 text-sm"
          style={{ animationDelay: "360ms" }}
        >
          <a
            href={site.links.github}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-2 text-muted-foreground transition-colors hover:text-accent"
          >
            <Github className="size-4" aria-hidden="true" />
            GitHub
          </a>
          <a
            href={profile.linkedin}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-2 text-muted-foreground transition-colors hover:text-accent"
          >
            <Linkedin className="size-4" aria-hidden="true" />
            LinkedIn
          </a>
          <a
            href={site.links.leetcode}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-2 text-muted-foreground transition-colors hover:text-accent"
          >
            <Code2 className="size-4" aria-hidden="true" />
            LeetCode
          </a>
          <a
            href={`mailto:${profile.email}`}
            className="inline-flex items-center gap-2 text-muted-foreground transition-colors hover:text-accent"
          >
            <Mail className="size-4" aria-hidden="true" />
            Email
          </a>
          <span className="inline-flex items-center gap-2 text-muted-foreground">
            <MapPin className="size-4" aria-hidden="true" />
            {profile.location}
          </span>
        </div>

        <a
          href="#about"
          className="animate-rise mt-14 inline-flex items-center gap-2 font-mono text-xs uppercase tracking-[0.22em] text-muted-foreground transition-colors hover:text-accent"
          style={{ animationDelay: "440ms" }}
        >
          <ArrowDown className="size-4 animate-bounce" aria-hidden="true" />
          Scroll
        </a>
      </div>
    </section>
  );
}
