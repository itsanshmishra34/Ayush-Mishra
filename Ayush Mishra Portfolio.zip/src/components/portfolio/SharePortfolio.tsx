import { useEffect, useRef, useState } from "react";
import { Check, Copy, QrCode, Share2, X } from "lucide-react";
import { site } from "@/data/site";

/**
 * Small share surface: QR code to the production URL, copy link, and the
 * Web Share API when the browser supports it.
 */
export function SharePortfolio() {
  const [open, setOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const [qr, setQr] = useState<string | null>(null);
  const [canShare, setCanShare] = useState(false);
  const dialogRef = useRef<HTMLDivElement>(null);
  const triggerRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    setCanShare(typeof navigator !== "undefined" && typeof navigator.share === "function");
  }, []);

  useEffect(() => {
    if (!open || qr) return;
    let cancelled = false;
    void import("qrcode").then(async (mod) => {
      const dataUrl = await mod.default.toDataURL(site.url, {
        width: 512,
        margin: 1,
        color: { dark: "#0b0f14", light: "#ffffff" },
      });
      if (!cancelled) setQr(dataUrl);
    });
    return () => {
      cancelled = true;
    };
  }, [open, qr]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    document.addEventListener("keydown", onKey);
    dialogRef.current?.focus();
    return () => document.removeEventListener("keydown", onKey);
  }, [open]);

  useEffect(() => {
    if (!open) triggerRef.current?.focus({ preventScroll: true });
  }, [open]);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(site.url);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2000);
    } catch {
      setCopied(false);
    }
  };

  const share = async () => {
    try {
      await navigator.share({ title: site.title, url: site.url });
    } catch {
      /* user dismissed the share sheet */
    }
  };

  return (
    <>
      <button
        ref={triggerRef}
        type="button"
        onClick={() => setOpen(true)}
        className="inline-flex items-center gap-2 rounded-full border border-border px-4 py-2 text-xs font-medium uppercase tracking-[0.16em] text-muted-foreground transition-colors hover:border-accent/60 hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
      >
        <QrCode className="size-4" aria-hidden="true" />
        Share my portfolio
      </button>

      {open ? (
        <div
          className="fixed inset-0 z-[60] flex items-center justify-center bg-background/80 p-4 backdrop-blur-sm"
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) setOpen(false);
          }}
        >
          <div
            ref={dialogRef}
            role="dialog"
            aria-modal="true"
            aria-labelledby="share-title"
            tabIndex={-1}
            className="w-full max-w-sm rounded-2xl border border-border bg-surface p-6 shadow-2xl focus:outline-none"
          >
            <div className="flex items-start justify-between gap-4">
              <div>
                <p className="font-mono text-[0.65rem] uppercase tracking-[0.28em] text-accent">
                  Share
                </p>
                <h2
                  id="share-title"
                  className="mt-2 font-display text-lg font-semibold text-foreground"
                >
                  Share my portfolio
                </h2>
              </div>
              <button
                type="button"
                onClick={() => setOpen(false)}
                aria-label="Close share dialog"
                className="rounded-full border border-border p-2 text-muted-foreground transition-colors hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              >
                <X className="size-4" aria-hidden="true" />
              </button>
            </div>

            <div className="mt-6 flex justify-center">
              {qr ? (
                <img
                  src={qr}
                  alt={`QR code linking to ${site.url}`}
                  className="size-44 rounded-xl border border-border bg-white p-2"
                  width={176}
                  height={176}
                  loading="lazy"
                  decoding="async"
                />
              ) : (
                <div
                  className="size-44 animate-pulse rounded-xl border border-border bg-muted/20"
                  aria-hidden="true"
                />
              )}
            </div>

            <p className="mt-4 break-all text-center font-mono text-xs text-muted-foreground">
              {site.url}
            </p>

            <div className="mt-6 flex flex-col gap-2">
              <button
                type="button"
                onClick={copy}
                className="inline-flex items-center justify-center gap-2 rounded-full bg-accent px-4 py-2.5 text-sm font-medium text-accent-foreground transition-opacity hover:opacity-90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              >
                {copied ? (
                  <Check className="size-4" aria-hidden="true" />
                ) : (
                  <Copy className="size-4" aria-hidden="true" />
                )}
                {copied ? "Link copied." : "Copy link"}
              </button>
              {canShare ? (
                <button
                  type="button"
                  onClick={share}
                  className="inline-flex items-center justify-center gap-2 rounded-full border border-border px-4 py-2.5 text-sm text-foreground transition-colors hover:border-accent/60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                >
                  <Share2 className="size-4" aria-hidden="true" />
                  Share…
                </button>
              ) : null}
            </div>

            <p aria-live="polite" className="sr-only">
              {copied ? "Link copied." : ""}
            </p>
          </div>
        </div>
      ) : null}
    </>
  );
}
