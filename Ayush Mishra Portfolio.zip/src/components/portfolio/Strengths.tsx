import { strengths } from "@/data/growth";
import { Section } from "./Section";
import { Reveal } from "./Reveal";

export function Strengths() {
  return (
    <Section
      id="strengths"
      eyebrow="Strengths"
      title="How I Work"
      subtitle="Qualities I am deliberately developing as an engineer."
    >
      <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {strengths.map((item, i) => (
          <Reveal as="li" key={item.id} delay={i * 60}>
            <div className="h-full rounded-2xl border border-border bg-surface/60 p-6 transition-colors duration-300 hover:border-accent/50">
              <h3 className="font-display text-base font-semibold text-foreground">{item.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                {item.description}
              </p>
            </div>
          </Reveal>
        ))}
      </ul>
    </Section>
  );
}
