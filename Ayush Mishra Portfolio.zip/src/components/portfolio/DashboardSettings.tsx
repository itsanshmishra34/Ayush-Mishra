import { useEffect, useState } from "react";
import { Github, RotateCcw, Settings2 } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { dashboard } from "@/data/dashboard";
import {
  clearIntegrationOverrides,
  saveIntegrationOverrides,
  useDashboardIntegrations,
  type IntegrationKey,
  type IntegrationOverrides,
} from "@/lib/dashboard-overrides";
import { cn } from "@/lib/utils";

/**
 * Small settings panel for the Engineering Snapshot integrations.
 * Edits apply live and persist in this browser via localStorage overrides;
 * the canonical defaults still live in src/data/dashboard.ts.
 */
export function DashboardSettings() {
  const [open, setOpen] = useState(false);
  const { integrations, overrides, hasOverrides } = useDashboardIntegrations();

  // Local form state, synced from the effective config whenever opened.
  const [form, setForm] = useState(integrations);
  useEffect(() => {
    if (open) setForm(integrations);
  }, [open, integrations]);

  const update = (key: IntegrationKey, patch: { enabled?: boolean; username?: string }) => {
    setForm((prev) => ({ ...prev, [key]: { ...prev[key], ...patch } }));
  };

  const apply = () => {
    const next: IntegrationOverrides = {};
    for (const key of ["github", "leetcode"] as const) {
      const base = dashboard.integrations[key];
      const current = form[key];
      const entry: { enabled?: boolean; username?: string } = {};
      if (current.enabled !== base.enabled) entry.enabled = current.enabled;
      if ((current.username ?? "") !== (base.username ?? "")) {
        entry.username = current.username ?? "";
      }
      if (entry.enabled !== undefined || entry.username !== undefined) next[key] = entry;
    }
    saveIntegrationOverrides(next);
    setOpen(false);
  };

  const reset = () => {
    clearIntegrationOverrides();
    setForm(dashboard.integrations);
    setOpen(false);
  };

  const rows: { key: IntegrationKey; label: string; placeholder: string; icon: typeof Github }[] = [
    { key: "github", label: "GitHub", placeholder: "e.g. octocat", icon: Github },
    { key: "leetcode", label: "LeetCode", placeholder: "e.g. your-handle", icon: Settings2 },
  ];

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        aria-label="Dashboard integration settings"
        className="inline-flex size-9 items-center justify-center rounded-full border border-border text-muted-foreground transition-colors hover:border-accent/40 hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
      >
        <Settings2 className="size-4" aria-hidden="true" />
      </button>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-md border-border bg-surface">
          <DialogHeader>
            <div className="flex items-center gap-3">
              <span className="inline-flex size-9 items-center justify-center rounded-lg bg-accent/10 text-accent">
                <Settings2 className="size-4" aria-hidden="true" />
              </span>
              <DialogTitle className="font-display text-xl text-foreground">
                Integration Settings
              </DialogTitle>
            </div>
            <DialogDescription className="pt-1 text-left text-sm text-muted-foreground">
              Toggle live GitHub / LeetCode stats and set the usernames they query. Changes apply
              instantly and persist in this browser. To change the defaults for everyone, edit{" "}
              <code className="rounded bg-background/70 px-1.5 py-0.5 font-mono text-xs text-accent">
                src/data/dashboard.ts
              </code>
              .
            </DialogDescription>
          </DialogHeader>

          <div className="mt-2 space-y-4">
            {rows.map(({ key, label, placeholder }) => {
              const value = form[key];
              return (
                <div key={key} className="rounded-xl border border-border bg-background/50 p-4">
                  <div className="flex items-center justify-between gap-3">
                    <label
                      htmlFor={`settings-${key}-username`}
                      className="font-mono text-xs uppercase tracking-[0.2em] text-muted-foreground"
                    >
                      {label}
                    </label>
                    <button
                      type="button"
                      role="switch"
                      aria-checked={value.enabled}
                      aria-label={`Enable ${label} integration`}
                      onClick={() => update(key, { enabled: !value.enabled })}
                      className={cn(
                        "relative h-6 w-11 shrink-0 rounded-full border transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
                        value.enabled
                          ? "border-accent/50 bg-accent/30"
                          : "border-border bg-secondary",
                      )}
                    >
                      <span
                        aria-hidden="true"
                        className={cn(
                          "absolute top-1/2 size-4 -translate-y-1/2 rounded-full transition-all",
                          value.enabled ? "left-[calc(100%-1.25rem)] bg-accent" : "left-1 bg-muted-foreground/60",
                        )}
                      />
                    </button>
                  </div>
                  <input
                    id={`settings-${key}-username`}
                    type="text"
                    value={value.username ?? ""}
                    onChange={(e) => update(key, { username: e.target.value })}
                    placeholder={placeholder}
                    autoComplete="off"
                    spellCheck={false}
                    className="mt-3 h-10 w-full rounded-lg border border-border bg-background px-3 font-mono text-sm text-foreground outline-none transition-colors placeholder:text-muted-foreground/60 focus:border-accent/50 focus-visible:ring-1 focus-visible:ring-ring"
                  />
                  <p className="mt-2 text-xs text-muted-foreground">
                    {value.enabled
                      ? value.username?.trim()
                        ? `Live stats will be fetched for ${value.username.trim()}.`
                        : "Enabled — add a username to activate live stats."
                      : "Off — the dashboard stays fully manual."}
                  </p>
                </div>
              );
            })}

            <div className="flex items-center justify-between gap-3 pt-1">
              <button
                type="button"
                onClick={reset}
                disabled={!hasOverrides}
                className="inline-flex items-center gap-1.5 rounded-full border border-dashed border-border px-4 py-2 text-xs font-medium text-muted-foreground transition-colors hover:border-accent/30 hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-40"
              >
                <RotateCcw className="size-3.5" aria-hidden="true" />
                Reset to defaults
              </button>
              <button
                type="button"
                onClick={apply}
                className="rounded-full bg-accent px-5 py-2 text-sm font-medium text-accent-foreground transition-colors hover:bg-accent/90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              >
                Apply
              </button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
