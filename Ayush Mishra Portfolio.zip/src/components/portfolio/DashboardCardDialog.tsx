import type { LucideIcon } from "lucide-react";
import type { ReactNode } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

export function EmptyState({ children }: { children: ReactNode }) {
  return (
    <div className="rounded-xl border border-dashed border-border bg-background/50 p-4">
      <p className="text-sm text-muted-foreground">{children}</p>
    </div>
  );
}

export function DashboardCardDialog({
  open,
  onOpenChange,
  icon: Icon,
  label,
  description,
  children,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  icon: LucideIcon;
  label: string;
  description: string;
  children: ReactNode;
}) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg border-border bg-surface">
        <DialogHeader>
          <div className="flex items-center gap-3">
            <span className="inline-flex size-9 items-center justify-center rounded-lg bg-accent/10 text-accent">
              <Icon className="size-4" aria-hidden="true" />
            </span>
            <DialogTitle className="font-display text-xl text-foreground">{label}</DialogTitle>
          </div>
          <DialogDescription className="pt-1 text-left text-sm text-muted-foreground">
            {description}
          </DialogDescription>
        </DialogHeader>
        <div className="mt-2 space-y-4">{children}</div>
      </DialogContent>
    </Dialog>
  );
}
