import type { ReactNode } from "react";
import { cn } from "@/lib/utils";
import { Reveal } from "./Reveal";

type SectionProps = {
  id: string;
  eyebrow: string;
  title: string;
  subtitle?: string;
  children: ReactNode;
  className?: string;
};

export function Section({ id, eyebrow, title, subtitle, children, className }: SectionProps) {
  return (
    <section
      id={id}
      aria-labelledby={`${id}-heading`}
      className={cn("scroll-mt-24 border-t border-border/60 py-20 sm:py-28", className)}
    >
      <div className="mx-auto w-full max-w-6xl px-5 sm:px-8">
        <Reveal className="mb-12">
          <p className="font-mono text-xs uppercase tracking-[0.28em] text-accent">{eyebrow}</p>
          <h2
            id={`${id}-heading`}
            className="mt-3 font-display text-3xl font-semibold tracking-tight text-foreground sm:text-4xl"
          >
            {title}
          </h2>
          {subtitle ? (
            <p className="mt-3 max-w-2xl text-base text-muted-foreground">{subtitle}</p>
          ) : null}
        </Reveal>
        {children}
      </div>
    </section>
  );
}
