import { focusAreas } from "@/data/portfolio";
import { Section } from "./Section";
import { Reveal } from "./Reveal";

export function Focus() {
  return (
    <Section
      id="focus"
      eyebrow="06 / Growth"
      title="Currently Building Myself"
      subtitle="Areas I am actively practising and strengthening."
    >
      <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {focusAreas.map((area, i) => (
          <Reveal as="li" key={area.index} delay={i * 70}>
            <div className="group h-full rounded-2xl border border-border bg-surface/60 p-6 transition-all duration-300 hover:-translate-y-1 hover:border-accent/50">
              <span className="font-mono text-xs tracking-[0.22em] text-accent">{area.index}</span>
              <h3 className="mt-4 font-display text-lg font-semibold text-foreground">
                {area.title}
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                {area.description}
              </p>
            </div>
          </Reveal>
        ))}
      </ul>
    </Section>
  );
}
