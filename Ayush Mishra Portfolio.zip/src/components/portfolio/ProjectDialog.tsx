import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import type { Project } from "@/data/projects";
import { ProjectVisual } from "./ProjectVisual";
import { ProjectArchitecture } from "./ProjectArchitecture";
import { ProjectLinks } from "./ProjectLinks";
import { StatusBadge } from "./StatusBadge";

type Props = {
  project: Project | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
};

export function ProjectDialog({ project, open, onOpenChange }: Props) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] max-w-3xl overflow-y-auto border-border bg-surface">
        {project ? (
          <>
            <DialogHeader className="text-left">
              <p className="font-mono text-xs uppercase tracking-[0.22em] text-accent">
                {project.category}
              </p>
              <DialogTitle className="font-display text-3xl font-semibold tracking-tight text-foreground">
                {project.title}
              </DialogTitle>
              <DialogDescription className="text-base leading-relaxed text-muted-foreground">
                {project.fullDescription ?? project.shortDescription}
              </DialogDescription>
            </DialogHeader>

            <ProjectVisual project={project} className="aspect-[16/10]" />

            <div className="flex flex-wrap items-center gap-3">
              <StatusBadge status={project.status} />
              <span className="font-mono text-xs text-muted-foreground">{project.year}</span>
            </div>

            <div>
              <h4 className="font-mono text-xs uppercase tracking-[0.22em] text-muted-foreground">
                Technologies
              </h4>
              <ul className="mt-3 flex flex-wrap gap-2">
                {project.technologies.map((tech) => (
                  <li
                    key={tech}
                    className="rounded-full border border-accent/25 bg-accent/10 px-3 py-1 font-mono text-xs text-accent"
                  >
                    {tech}
                  </li>
                ))}
              </ul>
            </div>

            {project.highlights && project.highlights.length > 0 ? (
              <div>
                <h4 className="font-mono text-xs uppercase tracking-[0.22em] text-muted-foreground">
                  Key highlights
                </h4>
                <ul className="mt-3 space-y-2">
                  {project.highlights.map((item) => (
                    <li
                      key={item}
                      className="flex gap-3 text-sm leading-relaxed text-muted-foreground"
                    >
                      <span aria-hidden="true" className="mt-2 size-1.5 shrink-0 rounded-full bg-accent" />
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            ) : null}

            {project.architecture && project.architecture.steps.length > 0 ? (
              <ProjectArchitecture architecture={project.architecture} />
            ) : null}

            <ProjectLinks project={project} showDetailsAction={false} />
          </>
        ) : null}
      </DialogContent>
    </Dialog>
  );
}
