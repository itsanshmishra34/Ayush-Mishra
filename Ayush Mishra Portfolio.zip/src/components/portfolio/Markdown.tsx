import { Fragment, type ReactNode } from "react";

/**
 * Minimal, dependency-free markdown renderer for README content.
 * It renders React elements only — raw HTML in the source is never
 * injected into the DOM, so untrusted repository content stays inert.
 */

function inline(text: string, keyPrefix: string): ReactNode[] {
  const nodes: ReactNode[] = [];
  const pattern =
    /(`[^`]+`)|(\*\*[^*]+\*\*)|(\*[^*]+\*)|(!?\[[^\]]*\]\([^)\s]+\))|(https?:\/\/[^\s)]+)/g;
  let last = 0;
  let match: RegExpExecArray | null;
  let i = 0;
  while ((match = pattern.exec(text)) !== null) {
    if (match.index > last) nodes.push(text.slice(last, match.index));
    const token = match[0];
    const key = `${keyPrefix}-${i++}`;
    if (token.startsWith("`")) {
      nodes.push(
        <code key={key} className="rounded bg-secondary px-1.5 py-0.5 font-mono text-[0.85em]">
          {token.slice(1, -1)}
        </code>,
      );
    } else if (token.startsWith("**")) {
      nodes.push(
        <strong key={key} className="font-semibold text-foreground">
          {token.slice(2, -2)}
        </strong>,
      );
    } else if (token.startsWith("*")) {
      nodes.push(<em key={key}>{token.slice(1, -1)}</em>);
    } else if (token.startsWith("![")) {
      const label = token.slice(2, token.indexOf("]"));
      nodes.push(
        <span key={key} className="font-mono text-xs text-muted-foreground">
          {label || "image"}
        </span>,
      );
    } else if (token.startsWith("[")) {
      const label = token.slice(1, token.indexOf("]"));
      const href = token.slice(token.indexOf("](") + 2, -1);
      nodes.push(
        <a
          key={key}
          href={href}
          target="_blank"
          rel="noreferrer nofollow ugc"
          className="text-accent underline-offset-4 hover:underline"
        >
          {label || href}
        </a>,
      );
    } else {
      nodes.push(
        <a
          key={key}
          href={token}
          target="_blank"
          rel="noreferrer nofollow ugc"
          className="break-all text-accent underline-offset-4 hover:underline"
        >
          {token}
        </a>,
      );
    }
    last = match.index + token.length;
  }
  if (last < text.length) nodes.push(text.slice(last));
  return nodes;
}

export function Markdown({ source }: { source: string }) {
  const lines = source.replace(/\r\n/g, "\n").split("\n");
  const blocks: ReactNode[] = [];
  let list: string[] = [];
  let code: string[] | null = null;
  let paragraph: string[] = [];
  let key = 0;

  const flushList = () => {
    if (list.length === 0) return;
    const items = list;
    list = [];
    blocks.push(
      <ul key={`ul-${key++}`} className="ml-5 list-disc space-y-1.5 text-sm text-muted-foreground">
        {items.map((item, idx) => (
          <li key={idx}>{inline(item, `li-${key}-${idx}`)}</li>
        ))}
      </ul>,
    );
  };

  const flushParagraph = () => {
    if (paragraph.length === 0) return;
    const text = paragraph.join(" ");
    paragraph = [];
    blocks.push(
      <p key={`p-${key++}`} className="text-sm leading-relaxed text-muted-foreground">
        {inline(text, `p-${key}`)}
      </p>,
    );
  };

  for (const raw of lines) {
    const line = raw.trimEnd();

    if (line.trimStart().startsWith("```")) {
      if (code === null) {
        flushParagraph();
        flushList();
        code = [];
      } else {
        blocks.push(
          <pre
            key={`code-${key++}`}
            className="overflow-x-auto rounded-xl border border-border bg-surface/70 p-4 font-mono text-xs text-foreground"
          >
            <code>{code.join("\n")}</code>
          </pre>,
        );
        code = null;
      }
      continue;
    }
    if (code !== null) {
      code.push(raw);
      continue;
    }

    const heading = /^(#{1,6})\s+(.*)$/.exec(line);
    if (heading) {
      flushParagraph();
      flushList();
      const level = (heading[1] ?? "").length;
      const text = heading[2] ?? "";
      const cls =
        level <= 1
          ? "font-display text-xl font-semibold text-foreground"
          : level === 2
            ? "font-display text-lg font-semibold text-foreground"
            : "font-medium text-foreground";
      blocks.push(
        <p key={`h-${key++}`} className={`mt-2 ${cls}`}>
          {inline(text, `h-${key}`)}
        </p>,
      );
      continue;
    }

    const bullet = /^\s*([-*+]|\d+\.)\s+(.*)$/.exec(line);
    if (bullet) {
      flushParagraph();
      list.push(bullet[2] ?? "");
      continue;
    }

    if (line.trim() === "") {
      flushParagraph();
      flushList();
      continue;
    }

    if (/^\s*([-*_]\s*){3,}$/.test(line)) {
      flushParagraph();
      flushList();
      blocks.push(<hr key={`hr-${key++}`} className="border-border/60" />);
      continue;
    }

    paragraph.push(line.trim());
  }

  flushParagraph();
  flushList();
  if (code !== null && code.length > 0) {
    blocks.push(
      <pre
        key={`code-${key++}`}
        className="overflow-x-auto rounded-xl border border-border bg-surface/70 p-4 font-mono text-xs text-foreground"
      >
        <code>{code.join("\n")}</code>
      </pre>,
    );
  }

  return <div className="grid gap-3">{blocks.map((b, i) => <Fragment key={i}>{b}</Fragment>)}</div>;
}
