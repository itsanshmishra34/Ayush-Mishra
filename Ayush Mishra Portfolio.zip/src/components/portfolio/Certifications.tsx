import { Award } from "lucide-react";
import { certifications } from "@/data/certifications";
import { Section } from "./Section";
import { Reveal } from "./Reveal";

export function Certifications() {
  return (
    <Section id="certifications" eyebrow="05b / Certifications" title="Certifications">
      <ul className="grid gap-4 sm:grid-cols-3">
        {certifications.map((cert, i) => (
          <Reveal as="li" key={cert.name} delay={i * 70}>
            <div className="flex h-full items-center gap-4 rounded-2xl border border-border bg-surface/60 p-5 transition-colors hover:border-accent/40">
              <span className="inline-flex size-10 shrink-0 items-center justify-center rounded-xl bg-accent/10 text-accent">
                <Award className="size-5" aria-hidden="true" />
              </span>
              <div>
                <p className="text-sm text-foreground">{cert.name}</p>
                {cert.issuer ? (
                  <p className="mt-1 font-mono text-[11px] uppercase tracking-[0.16em] text-muted-foreground">
                    {cert.issuer}
                    {cert.date ? ` · ${cert.date}` : ""}
                  </p>
                ) : null}
              </div>
            </div>
          </Reveal>
        ))}
      </ul>
    </Section>
  );
}
