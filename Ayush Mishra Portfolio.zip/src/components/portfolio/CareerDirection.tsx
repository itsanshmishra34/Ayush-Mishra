import { ArrowRight } from "lucide-react";
import { careerDirection } from "@/data/growth";
import { Section } from "./Section";
import { Reveal } from "./Reveal";

export function CareerDirection() {
  return (
    <Section
      id="direction"
      eyebrow="Direction"
      title="Where I'm Heading"
      subtitle={careerDirection.statement}
    >
      <Reveal>
        <ol className="flex flex-col items-stretch gap-3 md:flex-row md:items-center">
          {careerDirection.steps.map((step, i) => (
            <li key={step} className="flex items-center gap-3 md:flex-1">
              <div className="flex-1 rounded-xl border border-border bg-surface/60 px-4 py-4 text-center">
                <span className="block font-mono text-[0.65rem] tracking-[0.22em] text-accent">
                  {String(i + 1).padStart(2, "0")}
                </span>
                <span className="mt-2 block font-display text-sm font-semibold uppercase tracking-wide text-foreground">
                  {step}
                </span>
              </div>
              {i < careerDirection.steps.length - 1 ? (
                <ArrowRight
                  className="size-4 shrink-0 rotate-90 text-muted-foreground md:rotate-0"
                  aria-hidden="true"
                />
              ) : null}
            </li>
          ))}
        </ol>
      </Reveal>
    </Section>
  );
}
