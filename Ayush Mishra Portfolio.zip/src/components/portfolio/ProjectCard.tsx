import type { Project } from "@/data/projects";
import { ProjectVisual } from "./ProjectVisual";
import { ProjectLinks } from "./ProjectLinks";
import { StatusBadge } from "./StatusBadge";

type Props = {
  project: Project;
  onOpen: (project: Project) => void;
  featured?: boolean;
};

export function ProjectCard({ project, onOpen, featured = false }: Props) {
  return (
    <article
      className={
        "group flex flex-col overflow-hidden rounded-3xl border border-border bg-surface/50 transition-all duration-300 hover:-translate-y-1 hover:border-accent/40 hover:shadow-[0_24px_60px_-30px_hsl(var(--accent)/0.45)]" +
        (featured ? " lg:grid lg:grid-cols-2 lg:items-stretch" : "")
      }
    >
      <ProjectVisual
        project={project}
        priority={featured}
        className={
          "rounded-none border-0 border-b border-border/70 " +
          (featured ? "aspect-[4/3] lg:aspect-auto lg:border-b-0 lg:border-r" : "aspect-[16/10]")
        }
      />

      <div className="flex flex-1 flex-col p-6 sm:p-8">
        <div className="flex flex-wrap items-center gap-3">
          <p className="font-mono text-xs uppercase tracking-[0.22em] text-accent">
            {project.category}
          </p>
          <span className="font-mono text-xs text-muted-foreground">{project.year}</span>
          <StatusBadge status={project.status} />
        </div>

        <h3 className="mt-4 font-display text-2xl font-semibold tracking-tight text-foreground sm:text-3xl">
          {project.title}
        </h3>
        <p className="mt-3 text-base leading-relaxed text-muted-foreground">
          {project.shortDescription}
        </p>

        <ul className="mt-6 flex flex-wrap gap-2">
          {project.technologies.map((tech) => (
            <li
              key={tech}
              className="rounded-full border border-accent/25 bg-accent/10 px-3 py-1 font-mono text-xs text-accent"
            >
              {tech}
            </li>
          ))}
        </ul>

        <div className="mt-8 pt-2">
          <ProjectLinks project={project} onDetails={() => onOpen(project)} />
        </div>
      </div>
    </article>
  );
}
