import { Binary, Code2, Database, GitBranch, Globe, ScanEye } from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { skillGroups } from "@/data/portfolio";
import { Section } from "./Section";
import { Reveal } from "./Reveal";

const icons: Record<string, LucideIcon> = {
  Code2,
  Binary,
  Database,
  ScanEye,
  Globe,
  GitBranch,
};

export function Skills() {
  return (
    <Section
      id="skills"
      eyebrow="02 / Tech Stack"
      title="Tech Stack"
      subtitle="Tools and technologies I work with."
    >
      <ul className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {skillGroups.map((group, i) => {
          const Icon = icons[group.icon] ?? Code2;
          return (
            <Reveal as="li" key={group.category} delay={i * 60}>
              <div className="group relative h-full overflow-hidden rounded-2xl border border-border bg-surface/60 p-6 transition-all duration-300 hover:-translate-y-1 hover:border-accent/50 hover:bg-surface-elevated">
                <span
                  aria-hidden="true"
                  className="absolute inset-x-0 -top-px h-px bg-gradient-to-r from-transparent via-accent to-transparent opacity-0 transition-opacity duration-300 group-hover:opacity-100"
                />
                <span className="inline-flex size-10 items-center justify-center rounded-xl bg-accent/10 text-accent">
                  <Icon className="size-5" aria-hidden="true" />
                </span>
                <h3 className="mt-4 font-mono text-xs uppercase tracking-[0.22em] text-muted-foreground">
                  {group.category}
                </h3>
                <ul className="mt-3 flex flex-wrap gap-2">
                  {group.items.map((item) => (
                    <li
                      key={item}
                      className="rounded-lg border border-border/70 bg-background/50 px-3 py-1.5 text-sm text-foreground transition-colors group-hover:border-accent/30"
                    >
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            </Reveal>
          );
        })}
      </ul>
    </Section>
  );
}
