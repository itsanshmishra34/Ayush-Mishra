import { ArrowUpRight, Hammer } from "lucide-react";
import { sortedBuildLog, type BuildLogCategory } from "@/data/buildLog";
import { Section } from "./Section";
import { Reveal } from "./Reveal";
import { cn } from "@/lib/utils";

const CATEGORY_STYLES: Record<BuildLogCategory, string> = {
  Building: "border-accent/40 text-accent",
  Learning: "border-border text-muted-foreground",
  Project: "border-accent/30 text-foreground",
  Achievement: "border-accent/40 text-accent",
};

function formatDate(date: string): string {
  const parsed = new Date(date);
  if (Number.isNaN(parsed.getTime())) return date;
  return parsed.toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}

export function BuildLog() {
  const entries = sortedBuildLog();

  return (
    <Section
      id="buildlog"
      eyebrow="06 / Log"
      title="Build Log"
      subtitle="A running record of what I'm building, learning and shipping."
    >
      {entries.length === 0 ? (
        <Reveal>
          <div className="flex flex-col items-start gap-4 rounded-2xl border border-dashed border-border bg-surface/40 p-8">
            <span className="inline-flex size-11 items-center justify-center rounded-xl bg-accent/10 text-accent">
              <Hammer className="size-5" aria-hidden="true" />
            </span>
            <p className="max-w-xl text-sm leading-relaxed text-muted-foreground">
              The build log is live but empty for now. Entries are added as new work ships — no
              placeholder activity is shown here.
            </p>
          </div>
        </Reveal>
      ) : (
        <ol className="relative grid gap-4 border-l border-border/70 pl-5 sm:pl-7">
          {entries.map((entry, i) => (
            <Reveal as="li" key={entry.id} delay={i * 70}>
              <span
                aria-hidden="true"
                className="absolute -left-[5px] mt-6 size-2.5 rounded-full border border-accent/50 bg-background"
              />
              <article className="rounded-2xl border border-border bg-surface/60 p-6 transition-colors hover:border-accent/40">
                <div className="flex flex-wrap items-center gap-3">
                  <span
                    className={cn(
                      "rounded-full border px-3 py-1 font-mono text-[10px] uppercase tracking-[0.18em]",
                      CATEGORY_STYLES[entry.category],
                    )}
                  >
                    {entry.category}
                  </span>
                  <time
                    dateTime={entry.date}
                    className="font-mono text-[11px] uppercase tracking-[0.16em] text-muted-foreground"
                  >
                    {formatDate(entry.date)}
                  </time>
                </div>
                <h3 className="mt-3 font-display text-lg font-semibold text-foreground">
                  {entry.title}
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                  {entry.description}
                </p>
                {entry.technologies && entry.technologies.length > 0 ? (
                  <ul className="mt-4 flex flex-wrap gap-2">
                    {entry.technologies.map((tech) => (
                      <li
                        key={tech}
                        className="rounded-full border border-border bg-background/60 px-3 py-1 font-mono text-[11px] text-muted-foreground"
                      >
                        {tech}
                      </li>
                    ))}
                  </ul>
                ) : null}
                {entry.link ? (
                  <a
                    href={entry.link.url}
                    target="_blank"
                    rel="noreferrer noopener"
                    className="mt-4 inline-flex items-center gap-1 text-sm text-foreground transition-colors hover:text-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                  >
                    {entry.link.label}
                    <ArrowUpRight className="size-3.5" aria-hidden="true" />
                  </a>
                ) : null}
              </article>
            </Reveal>
          ))}
        </ol>
      )}
    </Section>
  );
}
