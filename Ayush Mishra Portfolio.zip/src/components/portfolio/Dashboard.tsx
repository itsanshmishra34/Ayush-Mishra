import { useState, type ReactNode } from "react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import {
  Compass,
  Hammer,
  TrendingUp,
  Sparkles,
  GraduationCap,
  DoorOpen,
  type LucideIcon,
} from "lucide-react";
import { dashboard, isEmpty, isIntegrationActive } from "@/data/dashboard";
import { fetchGithubStats, fetchLeetcodeStats } from "@/lib/dashboard-stats.functions";
import { LEETCODE_USERNAME, fetchLeetcodeProfile } from "@/lib/leetcode";
import { useDashboardIntegrations } from "@/lib/dashboard-overrides";
import { cn } from "@/lib/utils";
import { Section } from "./Section";
import { Reveal } from "./Reveal";
import { DashboardCardDialog, EmptyState } from "./DashboardCardDialog";
import { DashboardSettings } from "./DashboardSettings";

type CardKey =
  | "focus"
  | "building"
  | "problemSolving"
  | "interests"
  | "education"
  | "openTo";

function CardShell({
  icon: Icon,
  label,
  onOpen,
  children,
  className,
}: {
  icon: LucideIcon;
  label: string;
  onOpen: () => void;
  children: ReactNode;
  className?: string;
}) {
  return (
    <button
      type="button"
      onClick={onOpen}
      aria-label={`View details: ${label}`}
      className={cn(
        "group h-full w-full cursor-pointer rounded-2xl border border-border bg-surface/60 p-6 text-left transition-all duration-300 hover:-translate-y-1 hover:border-accent/50 hover:accent-glow focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent focus-visible:ring-offset-2 focus-visible:ring-offset-background",
        className,
      )}
    >
      <span className="flex items-center gap-2.5">
        <span className="inline-flex size-8 items-center justify-center rounded-lg bg-accent/10 text-accent transition-colors duration-300 group-hover:bg-accent/15">
          <Icon className="size-4" aria-hidden="true" />
        </span>
        <span className="font-mono text-[11px] uppercase tracking-[0.22em] text-muted-foreground">
          {label}
        </span>
      </span>
      <span className="mt-5 block">{children}</span>
    </button>
  );
}

function Chip({ children }: { children: ReactNode }) {
  return (
    <span className="inline-flex items-center rounded-full border border-border bg-background/60 px-3 py-1 text-xs font-medium text-foreground transition-colors duration-200 group-hover:border-accent/30">
      {children}
    </span>
  );
}

function Bullets({ items }: { items: readonly string[] }) {
  return (
    <ul className="space-y-1.5">
      {items.map((item) => (
        <li key={item} className="flex items-center gap-2 text-sm text-muted-foreground">
          <span aria-hidden="true" className="size-1 rounded-full bg-accent" />
          {item}
        </li>
      ))}
    </ul>
  );
}

function Stat({
  label,
  value,
  suffix,
}: {
  label: string;
  value: number;
  suffix?: string;
}) {
  return (
    <div>
      <dt className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
        {label}
      </dt>
      <dd className="mt-1 font-display text-3xl font-semibold text-accent">
        {value}
        {suffix ? (
          <span className="ml-1 text-xs font-normal text-muted-foreground">{suffix}</span>
        ) : null}
      </dd>
    </div>
  );
}

const NOT_CONFIGURED = "Not configured yet — this will populate once the data is added.";

export function Dashboard() {
  const [openCard, setOpenCard] = useState<CardKey | null>(null);
  const { problemSolving } = dashboard;
  // Static defaults merged with any settings-panel overrides (live updates).
  const { integrations } = useDashboardIntegrations();

  const githubFn = useServerFn(fetchGithubStats);
  const leetcodeFn = useServerFn(fetchLeetcodeStats);

  const githubActive = isIntegrationActive(integrations.github);
  const leetcodeActive = isIntegrationActive(integrations.leetcode);

  const githubQuery = useQuery({
    queryKey: ["github-stats", integrations.github.username],
    queryFn: () => githubFn({ data: { username: integrations.github.username as string } }),
    enabled: githubActive,
    staleTime: 1000 * 60 * 30,
    retry: false,
  });

  const leetcodeQuery = useQuery({
    queryKey: ["leetcode-stats", integrations.leetcode.username],
    queryFn: () => leetcodeFn({ data: { username: integrations.leetcode.username as string } }),
    enabled: leetcodeActive,
    staleTime: 1000 * 60 * 30,
    retry: false,
  });

  // Public LeetCode profile (no credentials) — real values or nothing.
  const profileFn = useServerFn(fetchLeetcodeProfile);
  const leetcodeProfileQuery = useQuery({
    queryKey: ["leetcode-profile", LEETCODE_USERNAME],
    queryFn: () => profileFn({ data: { username: LEETCODE_USERNAME } }),
    staleTime: 1000 * 60 * 30,
    retry: 1,
  });

  const live = leetcodeActive && !leetcodeQuery.data?.error ? leetcodeQuery.data : null;
  const publicLc = leetcodeProfileQuery.data?.error ? null : leetcodeProfileQuery.data;
  const solved = live?.totalSolved ?? publicLc?.totalSolved ?? problemSolving.leetcodeSolved;
  const easy = publicLc?.easy ?? null;
  const medium = publicLc?.medium ?? null;
  const hard = publicLc?.hard ?? null;
  const streak = live?.currentStreak ?? problemSolving.currentStreak;
  const hasStats = solved !== null || streak !== null;
  const statsLoading = leetcodeQuery.isLoading || leetcodeProfileQuery.isLoading;

  const github = githubActive && !githubQuery.data?.error ? githubQuery.data : null;

  return (
    <Section
      id="snapshot"
      eyebrow="03 / Snapshot"
      title="Engineering Snapshot"
      subtitle="A quick look at what I'm building, learning, and practicing. Select any card for details."
    >
      <div className="mb-4 flex justify-end">
        <DashboardSettings />
      </div>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        <Reveal delay={0}>
          <CardShell icon={Compass} label="Current Focus" onOpen={() => setOpenCard("focus")}>
            {isEmpty(dashboard.currentFocus) ? (
              <span className="text-sm text-muted-foreground">{NOT_CONFIGURED}</span>
            ) : (
              <span className="flex flex-wrap gap-2">
                {dashboard.currentFocus.map((item) => (
                  <Chip key={item}>{item}</Chip>
                ))}
              </span>
            )}
          </CardShell>
        </Reveal>

        <Reveal delay={70}>
          <CardShell icon={Hammer} label="Currently Building" onOpen={() => setOpenCard("building")}>
            {isEmpty(dashboard.currentlyBuilding) ? (
              <span className="text-sm text-muted-foreground">{NOT_CONFIGURED}</span>
            ) : (
              <span className="block space-y-3">
                {dashboard.currentlyBuilding.map((item) => (
                  <span key={item.name} className="block">
                    <span className="block font-display text-base font-semibold text-foreground">
                      {item.name}
                    </span>
                    <span className="mt-0.5 block text-sm text-muted-foreground">
                      {item.detail}
                    </span>
                  </span>
                ))}
              </span>
            )}
          </CardShell>
        </Reveal>

        <Reveal delay={140}>
          <CardShell
            icon={TrendingUp}
            label="Problem Solving"
            onOpen={() => setOpenCard("problemSolving")}
          >
            {statsLoading ? (
              <span className="text-sm text-muted-foreground">Loading LeetCode stats…</span>
            ) : hasStats ? (
              <dl className="flex flex-wrap gap-x-8 gap-y-4">
                {solved !== null ? <Stat label="Problems Solved" value={solved} /> : null}
                {easy !== null ? <Stat label="Easy" value={easy} /> : null}
                {medium !== null ? <Stat label="Medium" value={medium} /> : null}
                {hard !== null ? <Stat label="Hard" value={hard} /> : null}
                {streak !== null ? (
                  <Stat label="Current Streak" value={streak} suffix={problemSolving.streakUnit} />
                ) : null}
              </dl>
            ) : (
              <span className="block space-y-2">
                <span className="block h-1.5 w-full overflow-hidden rounded-full bg-border/60">
                  <span className="block h-full w-1/4 rounded-full bg-accent/40" />
                </span>
                <span className="block text-sm text-muted-foreground">
                  Live LeetCode statistics are currently unavailable.
                </span>
              </span>
            )}
          </CardShell>
        </Reveal>

        <Reveal delay={210}>
          <CardShell
            icon={Sparkles}
            label="Technical Interests"
            onOpen={() => setOpenCard("interests")}
          >
            {isEmpty(dashboard.technicalInterests) ? (
              <span className="text-sm text-muted-foreground">{NOT_CONFIGURED}</span>
            ) : (
              <Bullets items={dashboard.technicalInterests} />
            )}
          </CardShell>
        </Reveal>

        <Reveal delay={280}>
          <CardShell icon={GraduationCap} label="Education" onOpen={() => setOpenCard("education")}>
            {isEmpty(dashboard.education) ? (
              <span className="text-sm text-muted-foreground">{NOT_CONFIGURED}</span>
            ) : (
              <>
                <span className="block font-display text-lg font-semibold text-foreground">
                  {dashboard.education.degree}
                </span>
                <span className="mt-1 block text-sm text-muted-foreground">
                  {dashboard.education.institution}
                </span>
                <span className="mt-3 block font-mono text-xs uppercase tracking-[0.22em] text-accent">
                  {dashboard.education.period}
                </span>
              </>
            )}
          </CardShell>
        </Reveal>

        <Reveal delay={350}>
          <CardShell icon={DoorOpen} label="Open To" onOpen={() => setOpenCard("openTo")}>
            {isEmpty(dashboard.openTo) ? (
              <span className="text-sm text-muted-foreground">{NOT_CONFIGURED}</span>
            ) : (
              <Bullets items={dashboard.openTo} />
            )}
          </CardShell>
        </Reveal>
      </div>

      {/* ---------------- Modals ---------------- */}

      <DashboardCardDialog
        open={openCard === "focus"}
        onOpenChange={(o) => setOpenCard(o ? "focus" : null)}
        icon={Compass}
        label="Current Focus"
        description="The languages and areas I'm actively studying and practicing right now."
      >
        {isEmpty(dashboard.currentFocus) ? (
          <EmptyState>{NOT_CONFIGURED}</EmptyState>
        ) : (
          <div className="flex flex-wrap gap-2">
            {dashboard.currentFocus.map((item) => (
              <Chip key={item}>{item}</Chip>
            ))}
          </div>
        )}
      </DashboardCardDialog>

      <DashboardCardDialog
        open={openCard === "building"}
        onOpenChange={(o) => setOpenCard(o ? "building" : null)}
        icon={Hammer}
        label="Currently Building"
        description="Projects in active development."
      >
        {isEmpty(dashboard.currentlyBuilding) ? (
          <EmptyState>{NOT_CONFIGURED}</EmptyState>
        ) : (
          <ul className="space-y-4">
            {dashboard.currentlyBuilding.map((item) => (
              <li key={item.name} className="rounded-xl border border-border bg-background/50 p-4">
                <p className="font-display text-base font-semibold text-foreground">{item.name}</p>
                {isEmpty(item.detail) ? null : (
                  <p className="mt-1 text-sm text-muted-foreground">{item.detail}</p>
                )}
              </li>
            ))}
          </ul>
        )}
      </DashboardCardDialog>

      <DashboardCardDialog
        open={openCard === "problemSolving"}
        onOpenChange={(o) => setOpenCard(o ? "problemSolving" : null)}
        icon={TrendingUp}
        label="Problem Solving"
        description="Practice stats. Shown only when they are real — from a configured integration or set manually."
      >
        {hasStats ? (
          <dl className="grid grid-cols-2 gap-4">
            {solved !== null ? <Stat label="Total Solved" value={solved} /> : null}
            {streak !== null ? (
              <Stat label="Current Streak" value={streak} suffix={problemSolving.streakUnit} />
            ) : null}
            {live?.easy != null ? <Stat label="Easy" value={live.easy} /> : null}
            {live?.medium != null ? <Stat label="Medium" value={live.medium} /> : null}
            {live?.hard != null ? <Stat label="Hard" value={live.hard} /> : null}
          </dl>
        ) : (
          <EmptyState>
            LeetCode stats aren't configured yet. Enable the LeetCode integration in{" "}
            <code className="rounded bg-background/70 px-1.5 py-0.5 font-mono text-xs text-accent">
              src/data/dashboard.ts
            </code>{" "}
            or set the numbers manually — nothing is ever estimated.
          </EmptyState>
        )}

        {leetcodeActive && leetcodeQuery.data?.error ? (
          <EmptyState>
            Live LeetCode data is unavailable right now ({leetcodeQuery.data.error}). Showing
            manual values instead.
          </EmptyState>
        ) : null}

        <div className="border-t border-border pt-4">
          <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
            GitHub Activity
          </p>
          {githubQuery.isLoading ? (
            <p className="mt-3 text-sm text-muted-foreground">Loading GitHub stats…</p>
          ) : github ? (
            <div className="mt-3 space-y-3">
              <dl className="flex gap-8">
                {github.publicRepos !== null ? (
                  <Stat label="Public Repos" value={github.publicRepos} />
                ) : null}
                {github.followers !== null ? (
                  <Stat label="Followers" value={github.followers} />
                ) : null}
              </dl>
              {github.topLanguages.length > 0 ? (
                <div className="flex flex-wrap gap-2">
                  {github.topLanguages.map((language) => (
                    <Chip key={language}>{language}</Chip>
                  ))}
                </div>
              ) : null}
            </div>
          ) : (
            <div className="mt-3">
              <EmptyState>
                {githubActive
                  ? `Live GitHub data is unavailable right now${
                      githubQuery.data?.error ? ` (${githubQuery.data.error})` : ""
                    }.`
                  : "GitHub integration is off — the dashboard stays fully manual until it's enabled."}
              </EmptyState>
            </div>
          )}
        </div>
      </DashboardCardDialog>

      <DashboardCardDialog
        open={openCard === "interests"}
        onOpenChange={(o) => setOpenCard(o ? "interests" : null)}
        icon={Sparkles}
        label="Technical Interests"
        description="Domains I want to go deeper in as an engineer."
      >
        {isEmpty(dashboard.technicalInterests) ? (
          <EmptyState>{NOT_CONFIGURED}</EmptyState>
        ) : (
          <Bullets items={dashboard.technicalInterests} />
        )}
      </DashboardCardDialog>

      <DashboardCardDialog
        open={openCard === "education"}
        onOpenChange={(o) => setOpenCard(o ? "education" : null)}
        icon={GraduationCap}
        label="Education"
        description="Current degree programme."
      >
        {isEmpty(dashboard.education) ? (
          <EmptyState>{NOT_CONFIGURED}</EmptyState>
        ) : (
          <div className="rounded-xl border border-border bg-background/50 p-4">
            <p className="font-display text-lg font-semibold text-foreground">
              {dashboard.education.degree}
            </p>
            <p className="mt-1 text-sm text-muted-foreground">{dashboard.education.institution}</p>
            <p className="mt-3 font-mono text-xs uppercase tracking-[0.22em] text-accent">
              {dashboard.education.period}
            </p>
          </div>
        )}
      </DashboardCardDialog>

      <DashboardCardDialog
        open={openCard === "openTo"}
        onOpenChange={(o) => setOpenCard(o ? "openTo" : null)}
        icon={DoorOpen}
        label="Open To"
        description="What I'm currently available for."
      >
        {isEmpty(dashboard.openTo) ? (
          <EmptyState>{NOT_CONFIGURED}</EmptyState>
        ) : (
          <Bullets items={dashboard.openTo} />
        )}
      </DashboardCardDialog>
    </Section>
  );
}
