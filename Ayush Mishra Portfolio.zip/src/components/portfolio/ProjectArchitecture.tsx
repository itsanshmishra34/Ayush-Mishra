import { useState } from "react";
import {
  ArrowDownRight,
  Camera,
  Cpu,
  Info,
  LogIn,
  ScanFace,
  ClipboardCheck,
  Workflow,
  type LucideIcon,
} from "lucide-react";
import type { ArchitectureStep, ProjectArchitecture as Architecture } from "@/data/projects";
import { cn } from "@/lib/utils";

/** Icon keys usable from `architecture.steps[].icon` in src/data/projects.ts */
const ARCHITECTURE_ICONS: Record<string, LucideIcon> = {
  input: LogIn,
  camera: Camera,
  cv: Cpu,
  face: ScanFace,
  logic: Workflow,
  record: ClipboardCheck,
};

function iconFor(step: ArchitectureStep): LucideIcon {
  return (step.icon && ARCHITECTURE_ICONS[step.icon]) || ArrowDownRight;
}

function Connector({ active, index }: { active: boolean; index: number }) {
  return (
    <div
      aria-hidden="true"
      className="relative flex shrink-0 items-center justify-center self-stretch py-1 md:w-8 md:self-center md:py-0"
    >
      {/* vertical rail (mobile) */}
      <span className="relative block h-6 w-px overflow-hidden bg-border md:hidden">
        <span
          className={cn(
            "absolute inset-x-0 top-0 block bg-accent transition-[height] duration-500 ease-out motion-reduce:transition-none",
            active ? "h-full" : "h-0",
          )}
        />
      </span>
      {/* horizontal rail (desktop) */}
      <span className="relative hidden h-px w-full overflow-hidden bg-border md:block">
        <span
          className={cn(
            "absolute inset-y-0 left-0 block bg-accent transition-[width] duration-500 ease-out motion-reduce:transition-none",
            active ? "w-full" : "w-0",
          )}
          style={{ transitionDelay: active ? `${index * 40}ms` : "0ms" }}
        />
      </span>
    </div>
  );
}

export function ProjectArchitecture({
  architecture,
  className,
}: {
  architecture: Architecture;
  className?: string;
}) {
  const steps = architecture.steps ?? [];
  const [activeId, setActiveId] = useState<string | null>(steps[0]?.id ?? null);

  if (steps.length === 0) return null;

  const activeIndex = steps.findIndex((s) => s.id === activeId);
  const active = activeIndex >= 0 ? steps[activeIndex] : null;

  return (
    <section className={cn("min-w-0 space-y-4", className)} aria-label="Project architecture">
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <h4 className="font-mono text-xs uppercase tracking-[0.22em] text-muted-foreground">
          {architecture.title ?? "Project Architecture"}
        </h4>
        <span className="font-mono text-[10px] uppercase tracking-[0.18em] text-accent">
          Conceptual
        </span>
      </div>

      <div className="rounded-2xl border border-border bg-background/50 p-4 sm:p-5">
        {/* Flow */}
        <div className="min-w-0 md:-mx-1 md:overflow-x-auto md:px-1 md:pb-2">
        <ol className="flex flex-col items-stretch md:w-full md:flex-row md:items-center">
          {steps.map((step, index) => {
            const Icon = iconFor(step);
            const isActive = step.id === activeId;
            const isBefore = activeIndex >= 0 && index < activeIndex;
            return (
              <li
                key={step.id}
                className="flex min-w-0 shrink-0 flex-col items-stretch md:flex-1 md:shrink md:flex-row md:items-center"
              >
                <div className="group/stage relative min-w-0 md:w-full">
                <button
                  type="button"
                  onClick={() => setActiveId(step.id)}
                  aria-pressed={isActive}
                  aria-describedby={`arch-tip-${step.id}`}
                  className={cn(
                    "group flex min-w-0 items-center gap-3 rounded-xl border px-3.5 py-3 text-left transition-all duration-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent focus-visible:ring-offset-2 focus-visible:ring-offset-background motion-reduce:transition-none md:w-full md:min-w-0 md:flex-col md:items-start md:gap-2.5",
                    isActive
                      ? "border-accent/60 bg-accent/10 text-foreground accent-glow"
                      : isBefore
                        ? "border-accent/25 bg-surface/60 text-foreground hover:border-accent/50"
                        : "border-border bg-surface/50 text-muted-foreground hover:border-accent/40 hover:text-foreground",
                  )}
                >
                  <span
                    className={cn(
                      "inline-flex size-8 shrink-0 items-center justify-center rounded-lg transition-colors duration-300 motion-reduce:transition-none",
                      isActive ? "bg-accent/20 text-accent" : "bg-accent/10 text-accent/80",
                    )}
                  >
                    <Icon className="size-4" aria-hidden="true" />
                  </span>
                  <span className="min-w-0">
                    {step.kind ? (
                      <span className="block font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
                        {step.kind}
                      </span>
                    ) : null}
                    <span className="block text-sm font-medium leading-snug">{step.label}</span>
                  </span>
                </button>

                {/* Hover / focus tooltip — conceptual role only, straight from the data. */}
                <span
                  role="tooltip"
                  id={`arch-tip-${step.id}`}
                  className="pointer-events-none absolute bottom-full left-0 z-20 mb-2 hidden w-64 max-w-[80vw] rounded-lg border border-border bg-surface p-3 text-xs leading-relaxed text-muted-foreground opacity-0 shadow-lg transition-opacity duration-200 group-hover/stage:opacity-100 group-focus-within/stage:opacity-100 motion-reduce:transition-none md:block"
                >
                  <span className="block font-mono text-[10px] uppercase tracking-[0.18em] text-accent">
                    Conceptual role
                  </span>
                  <span className="mt-1 block">{step.description}</span>
                </span>
                </div>

                {index < steps.length - 1 ? (
                  <Connector active={index < Math.max(activeIndex, 0)} index={index} />
                ) : null}
              </li>
            );
          })}
        </ol>
        </div>

        {/* Detail panel */}
        {active ? (
          <div
            key={active.id}
            className="mt-5 rounded-xl border border-border bg-surface/60 p-4 duration-300 animate-in fade-in slide-in-from-bottom-1 motion-reduce:animate-none"
          >
            <p className="font-display text-base font-semibold text-foreground">{active.label}</p>
            <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">
              {active.description}
            </p>
            {active.technologies && active.technologies.length > 0 ? (
              <ul className="mt-3 flex flex-wrap gap-2">
                {active.technologies.map((tech) => (
                  <li
                    key={tech}
                    className="rounded-full border border-accent/25 bg-accent/10 px-2.5 py-0.5 font-mono text-[11px] text-accent"
                  >
                    {tech}
                  </li>
                ))}
              </ul>
            ) : (
              <p className="mt-3 font-mono text-[11px] uppercase tracking-[0.18em] text-muted-foreground">
                No specific technology listed for this stage
              </p>
            )}
          </div>
        ) : null}

        {architecture.note ? (
          <p className="mt-4 flex gap-2 text-xs leading-relaxed text-muted-foreground">
            <Info className="mt-0.5 size-3.5 shrink-0 text-accent" aria-hidden="true" />
            {architecture.note}
          </p>
        ) : null}
      </div>
    </section>
  );
}
