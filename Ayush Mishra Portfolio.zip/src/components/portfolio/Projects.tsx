import { useEffect, useMemo, useState } from "react";
import {
  matchesFilter,
  projectCategories,
  projects as allProjects,
  type Project,
  type ProjectFilter,
} from "@/data/projects";
import { Section } from "./Section";
import { Reveal } from "./Reveal";
import { ProjectCard } from "./ProjectCard";
import { ProjectDialog } from "./ProjectDialog";
import { ProjectCaseStudy } from "./ProjectCaseStudy";

const filters: ProjectFilter[] = ["All", ...projectCategories];

export function Projects() {
  const [filter, setFilter] = useState<ProjectFilter>("All");
  const [active, setActive] = useState<Project | null>(null);

  // Deep links: #case/<slug>/<section> opens the matching case study.
  useEffect(() => {
    const openFromHash = () => {
      const match = /^#case\/([^/]+)/.exec(window.location.hash);
      if (!match) return;
      const project = allProjects.find((p) => p.slug === match[1] && p.caseStudy);
      if (project) setActive(project);
    };
    openFromHash();
    window.addEventListener("hashchange", openFromHash);
    return () => window.removeEventListener("hashchange", openFromHash);
  }, []);

  const visible = useMemo(
    () => allProjects.filter((project) => matchesFilter(project, filter)),
    [filter],
  );
  const featured = visible.filter((project) => project.featured);
  const others = visible.filter((project) => !project.featured);

  const availableFilters = filters.filter(
    (item) => item === "All" || allProjects.some((project) => matchesFilter(project, item)),
  );

  return (
    <Section
      id="projects"
      eyebrow="03 / Work"
      title="Projects"
      subtitle="Practical software I have built while learning."
    >
      {availableFilters.length > 2 ? (
        <Reveal>
          <div role="tablist" aria-label="Filter projects by category" className="mb-10 flex flex-wrap gap-2">
            {availableFilters.map((item) => (
              <button
                key={item}
                type="button"
                role="tab"
                aria-selected={filter === item}
                onClick={() => setFilter(item)}
                className={`rounded-full border px-4 py-2 font-mono text-xs uppercase tracking-[0.16em] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring ${
                  filter === item
                    ? "border-accent/50 bg-accent/10 text-accent"
                    : "border-border text-muted-foreground hover:border-accent/30 hover:text-foreground"
                }`}
              >
                {item}
              </button>
            ))}
          </div>
        </Reveal>
      ) : null}

      {featured.length > 0 ? (
        <div className="grid gap-8">
          <p className="font-mono text-xs uppercase tracking-[0.22em] text-muted-foreground">
            Featured
          </p>
          {featured.map((project) => (
            <Reveal key={project.slug}>
              <div key={`${filter}-${project.slug}`} className="animate-rise">
                <ProjectCard project={project} onOpen={setActive} featured />
              </div>
            </Reveal>
          ))}
        </div>
      ) : null}

      {others.length > 0 ? (
        <div className="mt-14 grid gap-8 sm:grid-cols-2">
          {others.map((project) => (
            <Reveal key={project.slug}>
              <div key={`${filter}-${project.slug}`} className="animate-rise h-full">
                <ProjectCard project={project} onOpen={setActive} />
              </div>
            </Reveal>
          ))}
        </div>
      ) : null}

      {visible.length === 0 ? (
        <p className="rounded-2xl border border-dashed border-border p-10 text-center text-muted-foreground">
          No projects in this category yet.
        </p>
      ) : null}

      <ProjectCaseStudy
        project={active && active.caseStudy ? active : null}
        open={active !== null && Boolean(active.caseStudy)}
        onClose={() => setActive(null)}
      />

      <ProjectDialog
        project={active && !active.caseStudy ? active : null}
        open={active !== null && !active.caseStudy}
        onOpenChange={(open) => {
          if (!open) setActive(null);
        }}
      />
    </Section>
  );
}
