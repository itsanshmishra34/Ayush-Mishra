import { useEffect, useRef } from "react";
import { createPortal } from "react-dom";
import { ExternalLink, X } from "lucide-react";

export type ProofTarget = {
  label: string;
  url: string;
  context: string;
};

/**
 * Lightweight in-page viewer for experience proof links.
 * Embeds the target when the source allows framing and always offers a
 * direct "Open original" fallback — the user never leaves the portfolio.
 */
export function ProofDialog({ target, onClose }: { target: ProofTarget | null; onClose: () => void }) {
  const dialogRef = useRef<HTMLDivElement | null>(null);
  const restoreRef = useRef<HTMLElement | null>(null);

  useEffect(() => {
    if (!target) return;
    restoreRef.current = document.activeElement as HTMLElement | null;
    const root = dialogRef.current;
    root?.querySelector<HTMLElement>("button, a")?.focus();

    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        e.stopPropagation();
        onClose();
        return;
      }
      if (e.key !== "Tab" || !root) return;
      const focusables = Array.from(
        root.querySelectorAll<HTMLElement>('a[href], button:not([disabled]), [tabindex]:not([tabindex="-1"])'),
      );
      if (focusables.length === 0) return;
      const first = focusables[0]!;
      const last = focusables[focusables.length - 1]!;
      const current = document.activeElement as HTMLElement | null;
      if (e.shiftKey && (current === first || !root.contains(current))) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && (current === last || !root.contains(current))) {
        e.preventDefault();
        first.focus();
      }
    };

    document.addEventListener("keydown", onKey, true);
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey, true);
      document.body.style.overflow = prevOverflow;
      restoreRef.current?.focus?.();
    };
  }, [target, onClose]);

  if (!target || typeof document === "undefined") return null;

  return createPortal(
    <div className="fixed inset-0 z-[70] flex items-center justify-center p-3 sm:p-6">
      <div
        aria-hidden="true"
        onClick={onClose}
        className="absolute inset-0 bg-background/85 backdrop-blur-sm"
      />
      <div
        ref={dialogRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby="proof-dialog-title"
        className="relative flex max-h-[88vh] w-full max-w-3xl flex-col overflow-hidden rounded-2xl border border-border bg-card shadow-2xl motion-safe:animate-rise"
      >
        <div className="flex items-start justify-between gap-4 border-b border-border px-4 py-4 sm:px-6">
          <div className="min-w-0">
            <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-accent">
              {target.context}
            </p>
            <h3 id="proof-dialog-title" className="mt-1 font-display text-lg text-foreground">
              {target.label}
            </h3>
            <p className="mt-1 truncate text-xs text-muted-foreground">{target.url}</p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close proof viewer"
            className="rounded-full border border-border p-2 text-muted-foreground transition-colors hover:border-accent/40 hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          >
            <X className="size-4" aria-hidden="true" />
          </button>
        </div>

        <div className="relative min-h-[45vh] flex-1 overflow-hidden bg-secondary/30">
          <p className="pointer-events-none absolute inset-x-0 top-1/2 -translate-y-1/2 px-6 text-center text-sm text-muted-foreground">
            If the preview stays blank, the source doesn't allow embedding — use “Open original”.
          </p>
          <iframe
            src={target.url}
            title={`${target.label} preview`}
            loading="lazy"
            referrerPolicy="no-referrer"
            sandbox="allow-scripts allow-same-origin allow-popups"
            className="relative h-[45vh] w-full sm:h-[55vh]"
          />
        </div>

        <div className="flex justify-end border-t border-border px-4 py-3 sm:px-6">
          <a
            href={target.url}
            target="_blank"
            rel="noreferrer noopener"
            className="inline-flex items-center gap-2 rounded-full border border-border px-4 py-2 text-xs text-foreground transition-colors hover:border-accent/40 hover:bg-secondary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          >
            Open original
            <ExternalLink className="size-3" aria-hidden="true" />
          </a>
        </div>
      </div>
    </div>,
    document.body,
  );
}
