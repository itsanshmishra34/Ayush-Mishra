import { GraduationCap } from "lucide-react";
import { education } from "@/data/education";
import { Section } from "./Section";
import { Reveal } from "./Reveal";

export function Education() {
  return (
    <Section id="education" eyebrow="05 / Education" title="Education">
      <div className="grid gap-5 lg:grid-cols-2">
        {education.map((item, i) => (
          <Reveal key={item.institution} delay={i * 90}>
            <article className="group relative h-full overflow-hidden rounded-2xl border border-border bg-surface/60 p-7 transition-all duration-300 hover:-translate-y-1 hover:border-accent/40">
              <span
                aria-hidden="true"
                className="pointer-events-none absolute -right-10 -top-10 size-32 rounded-full bg-accent/10 opacity-0 blur-2xl transition-opacity duration-500 group-hover:opacity-100"
              />
              <span className="inline-flex size-11 items-center justify-center rounded-xl bg-accent/10 text-accent">
                <GraduationCap className="size-5" aria-hidden="true" />
              </span>
              <h3 className="mt-5 font-display text-xl font-semibold text-foreground">
                {item.institution}
              </h3>
              <p className="mt-2 text-sm text-muted-foreground">{item.detail}</p>
              <p className="mt-4 font-mono text-xs uppercase tracking-[0.22em] text-accent">
                {item.period}
              </p>
            </article>
          </Reveal>
        ))}
      </div>
    </Section>
  );
}
