/**
 * Resume builder.
 *
 * Renders a recruiter-friendly, print-ready HTML resume straight from the
 * canonical portfolio data files — nothing is hardcoded or invented here.
 * Sections with no real data (e.g. an empty build log) are simply omitted.
 *
 * Usage:
 *   bun scripts/build-resume.ts [outputHtmlPath]
 * Then print that HTML to PDF (any browser: File → Print → Save as PDF)
 * and save it as public/resume.pdf.
 */

import { writeFileSync } from "node:fs";
import { profile } from "../src/data/portfolio";
import { skillGroups } from "../src/data/skills";
import { education } from "../src/data/education";
import { certifications } from "../src/data/certifications";
import { experience } from "../src/data/experience";
import { projects } from "../src/data/projects";
import { sortedBuildLog } from "../src/data/buildLog";

const out = process.argv[2] ?? "public/resume.html";

const esc = (s: string) =>
  s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

const section = (title: string, body: string) =>
  body.trim() ? `<section><h2>${esc(title)}</h2>${body}</section>` : "";

const educationHtml = education
  .map(
    (e) => `<div class="row">
      <div><strong>${esc(e.institution)}</strong><div class="muted">${esc(e.detail)}</div></div>
      <div class="date">${esc(e.period)}</div>
    </div>`,
  )
  .join("");

const experienceHtml = experience
  .map((e) => {
    const bullets = e.responsibilities.length
      ? `<ul>${e.responsibilities.map((r) => `<li>${esc(r)}</li>`).join("")}</ul>`
      : "";
    const desc = e.description ? `<div class="muted">${esc(e.description)}</div>` : "";
    return `<div class="row">
      <div><strong>${esc(e.role)}</strong> · ${esc(e.organization)}${desc}${bullets}</div>
      <div class="date">${esc(e.period)}</div>
    </div>`;
  })
  .join("");

const skillsHtml = `<ul class="skills">${skillGroups
  .map((g) => `<li><span class="cat">${esc(g.category)}</span>${esc(g.items.join(" · "))}</li>`)
  .join("")}</ul>`;

const projectsHtml = projects
  .map((p) => {
    const links = [p.githubUrl, p.liveUrl, p.projectUrl].filter(Boolean) as string[];
    const highlights = p.highlights?.length
      ? `<ul>${p.highlights.map((h) => `<li>${esc(h)}</li>`).join("")}</ul>`
      : "";
    return `<div class="row">
      <div>
        <strong>${esc(p.title)}</strong>
        <div class="muted">${esc(p.technologies.join(" · "))}</div>
        <p>${esc(p.shortDescription)}</p>
        ${highlights}
        ${links.length ? `<div class="muted">${links.map(esc).join(" · ")}</div>` : ""}
      </div>
      <div class="date">${esc(String(p.year))}</div>
    </div>`;
  })
  .join("");

const certificationsHtml = `<ul class="plain">${certifications
  .map(
    (c) =>
      `<li>${esc(c.name)}${c.issuer ? ` — ${esc(c.issuer)}` : ""}${c.date ? ` (${esc(c.date)})` : ""}</li>`,
  )
  .join("")}</ul>`;

const log = sortedBuildLog();
const buildLogHtml = log.length
  ? `<ul class="plain">${log
      .map(
        (b) =>
          `<li><strong>${esc(b.title)}</strong> — ${esc(b.description)} <span class="muted">(${esc(b.category)}, ${esc(b.date)})</span></li>`,
      )
      .join("")}</ul>`
  : "";

const html = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<title>${esc(profile.name)} — Resume</title>
<link rel="preconnect" href="https://fonts.googleapis.com" />
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
<link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600;700&family=DM+Sans:wght@400;500&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet" />
<style>
  @page { size: A4; margin: 13mm 14mm; }
  * { box-sizing: border-box; }
  :root { --accent: #0e8f92; --ink: #12161c; --muted: #59636f; --rule: #dfe4ea; }
  body { font-family: "DM Sans", Arial, sans-serif; color: var(--ink); font-size: 10.2pt; line-height: 1.45; margin: 0; }
  header { border-bottom: 2px solid var(--accent); padding-bottom: 10px; margin-bottom: 14px; }
  h1 { font-family: "Space Grotesk", Arial, sans-serif; font-size: 23pt; font-weight: 600;
       text-transform: uppercase; letter-spacing: -0.015em; margin: 0 0 3px; }
  .headline { font-size: 10.5pt; color: var(--muted); margin: 0 0 7px; }
  .contact { font-family: "JetBrains Mono", monospace; font-size: 8.6pt; color: var(--muted); }
  .contact span:not(:last-child)::after { content: "  ·  "; color: var(--accent); }
  h2 { font-family: "JetBrains Mono", monospace; font-size: 8.4pt; font-weight: 500;
       text-transform: uppercase; letter-spacing: 0.22em; color: var(--accent);
       border-bottom: 1px solid var(--rule); padding-bottom: 4px; margin: 15px 0 9px; }
  .row { display: flex; justify-content: space-between; gap: 16px; margin-bottom: 9px; break-inside: avoid; }
  .row strong { font-family: "Space Grotesk", Arial, sans-serif; font-weight: 600; }
  .date { font-family: "JetBrains Mono", monospace; font-size: 8.4pt; color: var(--muted); white-space: nowrap; }
  .muted { color: var(--muted); font-size: 9.2pt; }
  p { margin: 3px 0; }
  ul { margin: 4px 0 0; padding-left: 15px; }
  li { margin-bottom: 2px; }
  li::marker { color: var(--accent); }
  ul.plain { list-style: none; padding-left: 0; }
  ul.skills { list-style: none; padding-left: 0; }
  ul.skills li { margin-bottom: 4px; }
  .cat { display: inline-block; min-width: 150px; font-weight: 600; color: var(--ink);
         font-family: "Space Grotesk", Arial, sans-serif; }
  a { color: inherit; text-decoration: none; }
</style>

</head>
<body>
  <header>
    <h1>${esc(profile.name)}</h1>
    <p class="headline">${esc(profile.headline)}</p>
    <div class="contact">
      <span>${esc(profile.location)}</span>
      <span>${esc(profile.email)}</span>
      <span>${esc(profile.phone)}</span>
      <span>${esc(profile.linkedin)}</span>
    </div>
  </header>

  ${section("Summary", `<p>${esc(profile.aboutStatement)}</p><p>${esc(profile.aboutParagraphs[0])}</p>`)}
  ${section("Education", educationHtml)}
  ${section("Technical Skills", skillsHtml)}
  ${section("Certifications", certificationsHtml)}
  ${section("Experience & Leadership", experienceHtml)}
  ${section("Projects", projectsHtml)}
  ${section("Build Log", buildLogHtml)}
</body>
</html>
`;

writeFileSync(out, html);
console.log(`Resume HTML written to ${out}`);
